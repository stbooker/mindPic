<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1500089153592" ID="ID_690904695" MODIFIED="1500089156486" TEXT="Git">
<node CREATED="1500089161109" ID="ID_1588851666" MODIFIED="1500089178182" POSITION="right" TEXT="&#x642d;&#x5efa;&#x6b65;&#x9aa4;">
<node CREATED="1500089181900" ID="ID_1749069177" MODIFIED="1500091195613">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <font color="rgb(63, 63, 63)" face="microsoft yahei" size="3"><b>1&#12289;&#27880;&#20876;&#65292;github&#32593;&#22336;</b>&#65306;</font><a href="https://github.com/" target="_blank" style="color: rgb(79, 161, 219); text-decoration: none; font-family: microsoft yahei; font-size: 15px; font-style: normal; font-weight: normal; letter-spacing: normal; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; background-color: rgb(255, 255, 255)"><font color="rgb(79, 161, 219)" face="microsoft yahei" size="3">https://github.com/</font></a><font color="rgb(63, 63, 63)" face="microsoft yahei" size="3">&#160;&#65307; </font>
    </p>
    <p>
      <font color="rgb(63, 63, 63)" face="microsoft yahei"><b>2&#12289;&#23433;&#35013;github&#23458;&#25143;&#31471;</b>&#65292;https://git-for-windows.github.io/ </font>
    </p>
    <p>
      <font color="rgb(63, 63, 63)" face="microsoft yahei"><b>3&#12289;&#37197;&#32622;&#36523;&#20221;</b>&#65306;</font>
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;3.1.&#20351;&#29992;git config&#21629;&#20196;&#37197;&#32622;&#33258;&#24049;&#30340;&#36134;&#21495; &#37038;&#31665;
    </p>
    <p>
      git config --global user.name &quot;stbooker&quot;
    </p>
    <p>
      git config --global user.email &quot;350459885@qq.com&quot;
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;3.2.&#37197;&#32622;&#25104;&#21151;&#21518;&#36890;&#36807;&#30456;&#21516;&#30340;&#21629;&#20196;&#26597;&#30475;
    </p>
    <p>
      git config --global user.name
    </p>
    <p>
      git config --global user.email
    </p>
    <p>
      
    </p>
    <p>
      <b>4&#12289;<font color="rgb(63, 63, 63)" face="microsoft yahei">&#24314;&#31435;github&#39033;&#30446;&#160;</font></b><font color="rgb(63, 63, 63)" face="microsoft yahei">&#160;&#160;&#160;&#160; </font>
    </p>
    <p>
      <font color="rgb(63, 63, 63)" face="microsoft yahei">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;4.1 &#36755;&#20837;git init </font>
    </p>
    <p>
      <font color="rgb(63, 63, 63)" face="microsoft yahei">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;4.2 git init&#25191;&#34892;&#25104;&#21151;&#21518;&#65292;git bash&#20250;&#26174;&#31034;&#160;Initialized empty Git repository in &#8230;..&#30340;&#23383;&#26679;&#65292;&#23601;&#34920;&#31034;&#21021;&#22987;&#21270;&#25104;&#21151;&#20102;&#12290;</font>
    </p>
    <p>
      
    </p>
    <p>
      <font color="rgb(63, 63, 63)" face="microsoft yahei"><b>5&#12289;&#23558;github&#39033;&#30446;&#24211;&#19979;&#36733;&#21040;&#26412;&#22320;&#160;&#160;&#160;</b>&#160;&#160;&#160; </font>
    </p>
    <p>
      <font color="rgb(63, 63, 63)" face="microsoft yahei">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#22312;&#24037;&#31243;&#30446;&#24405;&#19979;&#21491;&#38190;&#35843;&#20986;git bash,&#36755;&#20837;&#160;git clone &#39033;&#30446;&#22320;&#22336;&#160;(&#22312;&#32593;&#31449;&#39033;&#30446;code&#19979;&#26597;&#30475;)&#160;&#160;&#160;&#160;&#160;&#160;&#160;<br align="left" style="letter-spacing: normal; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; background-color: rgb(255, 255, 255)" /><b>6&#12289;&#25552;&#20132;&#26412;&#22320;&#20195;&#30721;&#21040;github </b></font>
    </p>
    <p>
      <font color="rgb(63, 63, 63)" face="microsoft yahei">git add .&#160;&#160;&#160;//&#28155;&#21152;&#26412;&#22320;&#25152;&#26377;&#25991;&#20214;&#160;</font>
    </p>
    <p>
      <font color="rgb(63, 63, 63)" face="microsoft yahei">git commit -m&#160;&#160;&quot;First commit&quot; </font>
    </p>
    <p>
      <font color="rgb(63, 63, 63)" face="microsoft yahei">git push origin master&#160;&#160;//&#23558;&#20195;&#30721;&#25552;&#20132;&#21040;&#36828;&#31243;&#26381;&#21153;&#22120;</font>
    </p>
    <p style="margin-top: 0px; margin-right: 0px; margin-bottom: 0; margin-left: 0px; color: rgb(63, 63, 63); font-family: microsoft yahei; font-size: 15px; font-style: normal; font-weight: normal; letter-spacing: normal; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; background-color: rgb(255, 255, 255)">
      <font size="3">&#22914;&#26524;&#21482;&#25552;&#20132;&#26576;&#19968;&#20010;&#25991;&#20214;&#22841;&#65292;&#27604;&#22914;&#21482;&#25552;&#20132;src&#25991;&#20214;&#22841;&#65292;&#21487;&#20197;&#36825;&#26679; </font>
    </p>
    <p style="margin-top: 0px; margin-right: 0px; margin-bottom: 0; margin-left: 0px; color: rgb(63, 63, 63); font-family: microsoft yahei; font-size: 15px; font-style: normal; font-weight: normal; letter-spacing: normal; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; background-color: rgb(255, 255, 255)">
      <font size="3">git add src</font>
    </p>
  </body>
</html>
</richcontent>
<arrowlink DESTINATION="ID_1749069177" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_550419265" STARTARROW="None" STARTINCLINATION="0;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_1749069177" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_550419265" SOURCE="ID_1749069177" STARTARROW="None" STARTINCLINATION="0;0;"/>
</node>
</node>
<node CREATED="1500093707508" ID="ID_1905506831" MODIFIED="1500093713078" POSITION="left" TEXT="&#x51b2;&#x7a81;&#x89e3;&#x51b3;">
<node CREATED="1500093736627" ID="ID_39899334" MODIFIED="1500093947051">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="&#x5b8b;&#x4f53;" size="3"><b>2&#20010;&#35299;&#20915;&#21150;&#27861;: </b></font>
    </p>
    <p>
      
    </p>
    <p>
      <font face="&#x5b8b;&#x4f53;" size="3"><b>1.&#20445;&#30041;&#20320;&#26412;&#22320;&#30340;&#20462;&#25913; </b></font>
    </p>
    <p>
      <font face="&#x5b8b;&#x4f53;" size="3">git merge --abort </font>
    </p>
    <p>
      <font face="&#x5b8b;&#x4f53;" size="3">git reset --merge </font>
    </p>
    <p>
      <font face="&#x5b8b;&#x4f53;" size="3">&#21512;&#24182;&#21518;&#35760;&#24471;&#19968;&#23450;&#35201;&#25552;&#20132;&#36825;&#20010;&#26412;&#22320;&#30340;&#21512;&#24182; </font>
    </p>
    <p>
      <font face="&#x5b8b;&#x4f53;" size="3">&#28982;&#21518;&#22312;&#33719;&#21462;&#32447;&#19978;&#20179;&#24211; </font>
    </p>
    <p>
      <font face="&#x5b8b;&#x4f53;" size="3">git pull origin master </font>
    </p>
    <p>
      
    </p>
    <p>
      <font face="&#x5b8b;&#x4f53;" size="3"><b>2.down&#19979;&#32447;&#19978;&#20195;&#30721;&#29256;&#26412;,&#25243;&#24323;&#26412;&#22320;&#30340;&#20462;&#25913;</b>&#160; </font>
    </p>
    <p>
      <font face="&#x5b8b;&#x4f53;" size="3">&#19981;&#24314;&#35758;&#36825;&#26679;&#20570;,&#20294;&#26159;&#22914;&#26524;&#20320;&#26412;&#22320;&#20462;&#25913;&#19981;&#22823;,&#25110;&#32773;&#33258;&#24049;&#26377;&#19968;&#20221;&#22791;&#20221;&#30041;&#23384;,&#21487;&#20197;&#30452;&#25509;&#29992;&#32447;&#19978;&#26368;&#26032;&#29256;&#26412;&#35206;&#30422;&#21040;&#26412;&#22320; </font>
    </p>
    <p>
      <font face="&#x5b8b;&#x4f53;" size="3">git fetch --all </font>
    </p>
    <p>
      <font face="&#x5b8b;&#x4f53;" size="3">git reset --hard origin/master </font>
    </p>
    <p>
      <font face="&#x5b8b;&#x4f53;" size="3">git fetch </font>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</map>
