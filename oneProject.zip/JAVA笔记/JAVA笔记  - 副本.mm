<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1491228128917" ID="ID_1130997487" MODIFIED="1491266530706" TEXT="JAVA">
<node CREATED="1491228186174" FOLDED="true" ID="ID_396459200" MODIFIED="1491285013908" POSITION="right" TEXT="JNDI">
<node CREATED="1491228269089" FOLDED="true" ID="ID_1018188376" MODIFIED="1491234716013" TEXT="&#x5173;&#x952e;&#x5b57;&#xff1a;&#x547d;&#x540d;&#x4e0e;&#x76ee;&#x5f55;&#x63a5;&#x53e3;&#xff08;Java Naming and Directory Interface&#xff09;;">
<node CREATED="1491234706223" ID="ID_432809146" MODIFIED="1491234713434">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      
    </p>
    <p>
      SUN&#20844;&#21496;&#25552;&#20379;&#30340;&#19968;&#31181;&#26631;&#20934;&#30340;Java&#21629;&#21517;&#31995;&#32479;&#25509;&#21475;&#65292;JNDI&#25552;&#20379;&#32479;&#19968;&#30340;&#23458;&#25143;&#31471;API&#65292;&#36890;&#36807;&#19981;&#21516;&#30340;&#35775;&#38382;&#25552;&#20379;&#32773;&#25509;&#21475;JNDI&#26381;&#21153;&#20379;&#24212;&#25509;&#21475;(SPI)&#30340;&#23454;&#29616;&#65292;&#30001;&#31649;&#29702;&#32773;&#23558;JNDI API&#26144;&#23556;&#20026;&#29305;&#23450;&#30340;&#21629;&#21517;&#26381;&#21153;&#21644;&#30446;&#24405;&#31995;&#32479;&#65292;&#20351;&#24471;Java&#24212;&#29992;&#31243;&#24207;&#21487;&#20197;&#21644;&#36825;&#20123;&#21629;&#21517;&#26381;&#21153;&#21644;&#30446;&#24405;&#26381;&#21153;&#20043;&#38388;&#36827;&#34892;&#20132;&#20114;&#12290;
    </p>
    <p>
      &#21629;&#21517;&#65306;&#19968;&#20010;&#20540;&#21644;&#21478;&#19968;&#20010;&#20540;&#30340;&#26144;&#23556;;
    </p>
    <p>
      &#30446;&#24405;&#65306;&#30446;&#24405;&#26381;&#21153;,&#20174;&#35745;&#31639;&#26426;&#35282;&#24230;&#29702;&#35299;&#20026;&#22312;&#20114;&#32852;&#32593;&#19978;&#26377;&#30528;&#21508;&#31181;&#21508;&#26679;&#30340;&#36164;&#28304;&#21644;&#20027;&#26426;,&#20294;&#26159;&#36825;&#20123;&#20869;&#23481;&#37117;&#26159;&#25955;&#33853;&#22312;&#20114;&#32852;&#32593;&#20013;,&#20026;&#20102;&#35775;&#38382;&#36825;&#20123;&#25955;&#33853;&#30340;&#36164;&#28304;&#24182;&#33719;&#24471;&#30456;&#24212;&#30340;&#26381;&#21153;,&#23601;&#38656;&#35201;&#29992;&#21040;&#30446;&#24405;&#26381;&#21153;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491228472115" FOLDED="true" ID="ID_1551508955" MODIFIED="1491234718496">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#29702;&#35299;&#25991;&#31456;1
    </p>
    <p>
      
    </p>
  </body>
</html></richcontent>
<node CREATED="1491230469188" FOLDED="true" ID="ID_1025208827" MODIFIED="1491234709999">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#29702;&#35299;&#25991;&#31456;&#65306;http://sishuok.com/forum/blogPost/list/1186.html&#160;
    </p>
    <p>
      &#20851;&#38190;&#23383;:DNS&#19982;IP&#26144;&#23556;&#12289;&#36164;&#28304;&#21644;&#20027;&#26426;&#12289;&#30005;&#35805;&#31807;
    </p>
  </body>
</html></richcontent>
<node CREATED="1491230483126" ID="ID_530012507" MODIFIED="1491230599092">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      <strong style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; line-height: 1.5em; font-size: 14px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="14px">JNDI &#26159;&#20160;&#20040;</font></strong>
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      JNDI&#26159; Java &#21629;&#21517;&#19982;&#30446;&#24405;&#25509;&#21475;&#65288;Java Naming and Directory Interface&#65289;&#65292;&#22312;J2EE&#35268;&#33539;&#20013;&#26159;&#37325;&#35201;&#30340;&#35268;&#33539;&#20043;&#19968;&#65292;&#19981;&#23569;&#19987;&#23478;&#35748;&#20026;&#65292;&#27809;&#26377;&#36879;&#24443;&#29702;&#35299;JNDI&#30340;&#24847;&#20041;&#21644;&#20316;&#29992;&#65292;&#23601;&#27809;&#26377;&#30495;&#27491;&#25484;&#25569;J2EE&#29305;&#21035;&#26159;EJB&#30340;&#30693;&#35782;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      <strong style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; line-height: 1.5em; font-size: 14px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="14px">&#37027;&#20040;&#65292;JNDI&#21040;&#24213;&#36215;&#20160;&#20040;&#20316;&#29992;&#65311;</font></strong>
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#35201;&#20102;&#35299;JNDI&#30340;&#20316;&#29992;&#65292;&#25105;&#20204;&#21487;&#20197;&#20174;&#8220;&#22914;&#26524;&#19981;&#29992;JNDI&#25105;&#20204;&#24590;&#26679;&#20570;&#65311;&#29992;&#20102;JNDI&#21518;&#25105;&#20204;&#21448;&#23558;&#24590;&#26679;&#20570;&#65311;&#8221;&#36825;&#20010;&#38382;&#39064;&#26469;&#25506;&#35752;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      <strong style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; line-height: 1.5em; font-size: 14px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="14px">&#27809;&#26377;JNDI&#30340;&#20570;&#27861;&#65306;</font></strong>
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#31243;&#24207;&#21592;&#24320;&#21457;&#26102;&#65292;&#30693;&#36947;&#35201;&#24320;&#21457;&#35775;&#38382;MySQL&#25968;&#25454;&#24211;&#30340;&#24212;&#29992;&#65292;&#20110;&#26159;&#23558;&#19968;&#20010;&#23545; MySQL JDBC &#39537;&#21160;&#31243;&#24207;&#31867;&#30340;&#24341;&#29992;&#36827;&#34892;&#20102;&#32534;&#30721;&#65292;&#24182;&#36890;&#36807;&#20351;&#29992;&#36866;&#24403;&#30340; JDBC URL &#36830;&#25509;&#21040;&#25968;&#25454;&#24211;&#12290;<font size="14px"><br style="padding-right: 0px; padding-left: 0px; line-height: 1.5em; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; margin-left: 0px; padding-top: 0px; margin-right: 0px" /></font>&#23601;&#20687;&#20197;&#19979;&#20195;&#30721;&#36825;&#26679;&#65306;
    </p>
    <ol class="dp-j" style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; text-align: -webkit-left; margin-right: 0px; list-style: none; margin-bottom: 0px; font-size: 12px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">Connection&#160;conn=</font></span><font size="12px"><span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">null</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">; &#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">try</font></span><font size="12px"><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;{ &#160;</span></font>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">Class.forName(</font></span><font size="12px"><span class="string" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&quot;com.mysql.jdbc.Driver&quot;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">, &#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">true</font></span><font size="12px"><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">,&#160;Thread.currentThread().getContextClassLoader()); &#160;</span></font>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">conn=DriverManager.getConnection(</font></span><font size="12px"><span class="string" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&quot;jdbc:mysql://MyDBServer?user=qingfeng&amp;password=mingyue&quot;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">); &#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="comment" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">/*&#160;&#20351;&#29992;conn&#24182;&#36827;&#34892;SQL&#25805;&#20316;&#160;*/</font></span><font size="12px"><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">...... &#160;</font></span>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">conn.close(); &#160;</font></span>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">}&#160;&#160;&#160;</font></span>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">catch</font></span><font size="12px"><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">(Exception&#160;e)&#160;{ &#160;</span></font>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">e.printStackTrace(); &#160;</font></span>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">}&#160;&#160;&#160;</font></span>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">finally</font></span><font size="12px"><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;{ &#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">if</font></span><font size="12px"><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">(conn!=</span><span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">null</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">)&#160;{ &#160;</span></font>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">try</font></span><font size="12px"><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;{ &#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">conn.close(); &#160;</font></span>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">}&#160;</font></span><font size="12px"><span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">catch</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">(SQLException&#160;e)&#160;{} &#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">} &#160;</font></span>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">}&#160;</font></span>
      </li>
    </ol>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#36825;&#26159;&#20256;&#32479;&#30340;&#20570;&#27861;&#65292;&#20063;&#26159;&#20197;&#21069;&#38750;Java&#31243;&#24207;&#21592;&#65288;&#22914;Delphi&#12289;VB&#31561;&#65289;&#24120;&#35265;&#30340;&#20570;&#27861;&#12290;&#36825;&#31181;&#20570;&#27861;&#19968;&#33324;&#22312;&#23567;&#35268;&#27169;&#30340;&#24320;&#21457;&#36807;&#31243;&#20013;&#19981;&#20250;&#20135;&#29983;&#38382;&#39064;&#65292;&#21482;&#35201;&#31243;&#24207;&#21592;&#29087;&#24713;Java&#35821;&#35328;&#12289;&#20102;&#35299;JDBC&#25216;&#26415;&#21644;MySQL&#65292;&#21487;&#20197;&#24456;&#24555;&#24320;&#21457;&#20986;&#30456;&#24212;&#30340;&#24212;&#29992;&#31243;&#24207;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      <strong style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; line-height: 1.5em; font-size: 14px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="14px">&#27809;&#26377;JNDI&#30340;&#20570;&#27861;&#23384;&#22312;&#30340;&#38382;&#39064;&#65306;</font></strong>
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      1&#12289;&#25968;&#25454;&#24211;&#26381;&#21153;&#22120;&#21517;&#31216;MyDBServer &#12289;&#29992;&#25143;&#21517;&#21644;&#21475;&#20196;&#37117;&#21487;&#33021;&#38656;&#35201;&#25913;&#21464;&#65292;&#30001;&#27492;&#24341;&#21457;JDBC URL&#38656;&#35201;&#20462;&#25913;&#65307;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      2&#12289;&#25968;&#25454;&#24211;&#21487;&#33021;&#25913;&#29992;&#21035;&#30340;&#20135;&#21697;&#65292;&#22914;&#25913;&#29992;DB2&#25110;&#32773;Oracle&#65292;&#24341;&#21457;JDBC&#39537;&#21160;&#31243;&#24207;&#21253;&#21644;&#31867;&#21517;&#38656;&#35201;&#20462;&#25913;&#65307;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      3&#12289;&#38543;&#30528;&#23454;&#38469;&#20351;&#29992;&#32456;&#31471;&#30340;&#22686;&#21152;&#65292;&#21407;&#37197;&#32622;&#30340;&#36830;&#25509;&#27744;&#21442;&#25968;&#21487;&#33021;&#38656;&#35201;&#35843;&#25972;&#65307;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      4&#12289;......
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      <strong style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; line-height: 1.5em; font-size: 14px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="14px">&#35299;&#20915;&#21150;&#27861;&#65306;</font></strong>
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#31243;&#24207;&#21592;&#24212;&#35813;&#19981;&#38656;&#35201;&#20851;&#24515;&#8220;&#20855;&#20307;&#30340;&#25968;&#25454;&#24211;&#21518;&#21488;&#26159;&#20160;&#20040;&#65311;JDBC&#39537;&#21160;&#31243;&#24207;&#26159;&#20160;&#20040;&#65311;JDBC URL&#26684;&#24335;&#26159;&#20160;&#20040;&#65311;&#35775;&#38382;&#25968;&#25454;&#24211;&#30340;&#29992;&#25143;&#21517;&#21644;&#21475;&#20196;&#26159;&#20160;&#20040;&#65311;&#8221;&#31561;&#31561;&#36825;&#20123;&#38382;&#39064;&#65292;&#31243;&#24207;&#21592;&#32534;&#20889;&#30340;&#31243;&#24207;&#24212;&#35813;&#27809;&#26377;&#23545; JDBC &#39537;&#21160;&#31243;&#24207;&#30340;&#24341;&#29992;&#65292;&#27809;&#26377;&#26381;&#21153;&#22120;&#21517;&#31216;&#65292;&#27809;&#26377;&#29992;&#25143;&#21517;&#31216;&#25110;&#21475;&#20196; &#8212;&#8212; &#29978;&#33267;&#27809;&#26377;&#25968;&#25454;&#24211;&#27744;&#25110;&#36830;&#25509;&#31649;&#29702;&#12290;&#32780;&#26159;&#25226;&#36825;&#20123;&#38382;&#39064;&#20132;&#32473;J2EE&#23481;&#22120;&#26469;&#37197;&#32622;&#21644;&#31649;&#29702;&#65292;&#31243;&#24207;&#21592;&#21482;&#38656;&#35201;&#23545;&#36825;&#20123;&#37197;&#32622;&#21644;&#31649;&#29702;&#36827;&#34892;&#24341;&#29992;&#21363;&#21487;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#30001;&#27492;&#65292;&#23601;&#26377;&#20102;JNDI&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      <strong style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; line-height: 1.5em; font-size: 14px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="14px">&#29992;&#20102;JNDI&#20043;&#21518;&#30340;&#20570;&#27861;&#65306;</font></strong>
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#39318;&#20808;&#65292;&#22312;&#22312;J2EE&#23481;&#22120;&#20013;&#37197;&#32622;JNDI&#21442;&#25968;&#65292;&#23450;&#20041;&#19968;&#20010;&#25968;&#25454;&#28304;&#65292;&#20063;&#23601;&#26159;JDBC&#24341;&#29992;&#21442;&#25968;&#65292;&#32473;&#36825;&#20010;&#25968;&#25454;&#28304;&#35774;&#32622;&#19968;&#20010;&#21517;&#31216;&#65307;&#28982;&#21518;&#65292;&#22312;&#31243;&#24207;&#20013;&#65292;&#36890;&#36807;&#25968;&#25454;&#28304;&#21517;&#31216;&#24341;&#29992;&#25968;&#25454;&#28304;&#20174;&#32780;&#35775;&#38382;&#21518;&#21488;&#25968;&#25454;&#24211;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      <strong style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; line-height: 1.5em; font-size: 14px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="14px">&#20855;&#20307;&#25805;&#20316;&#22914;&#19979;&#65288;&#20197;JBoss&#20026;&#20363;&#65289;&#65306;</font></strong>
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      1&#12289;&#37197;&#32622;&#25968;&#25454;&#28304;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#22312;JBoss&#30340; D:/jboss420GA/docs/examples/jca &#25991;&#20214;&#22841;&#19979;&#38754;&#65292;&#26377;&#24456;&#22810;&#19981;&#21516;&#25968;&#25454;&#24211;&#24341;&#29992;&#30340;&#25968;&#25454;&#28304;&#23450;&#20041;&#27169;&#26495;&#12290;&#23558;&#20854;&#20013;&#30340; mysql-ds.xml &#25991;&#20214;Copy&#21040;&#20320;&#20351;&#29992;&#30340;&#26381;&#21153;&#22120;&#19979;&#65292;&#22914; D:/jboss420GA/server/default/deploy&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#20462;&#25913; mysql-ds.xml &#25991;&#20214;&#30340;&#20869;&#23481;&#65292;&#20351;&#20043;&#33021;&#36890;&#36807;JDBC&#27491;&#30830;&#35775;&#38382;&#20320;&#30340;MySQL&#25968;&#25454;&#24211;&#65292;&#22914;&#19979;&#65306;
    </p>
    <ol class="dp-xml" style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; text-align: -webkit-left; margin-right: 0px; list-style: none; margin-bottom: 0px; font-size: 12px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">&lt;?</font></span><font size="12px"><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">xml</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span><span class="attribute" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">version</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">=</span><span class="attribute-value" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&quot;1.0&quot;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span><span class="attribute" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">encoding</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">=</span><span class="attribute-value" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&quot;UTF-8&quot;</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">?&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">&lt;</font></span><font size="12px"><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">datasources</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">&lt;</font></span><font size="12px"><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">local-tx-datasource</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">&lt;</font></span><font size="12px"><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">jndi-name</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">MySqlDS</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&lt;/</span><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">jndi-name</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">&lt;</font></span><font size="12px"><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">connection-url</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">jdbc:mysql://localhost:3306/lw</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&lt;/</span><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">connection-url</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">&lt;</font></span><font size="12px"><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">driver-class</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">com.mysql.jdbc.Driver</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&lt;/</span><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">driver-class</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">&lt;</font></span><font size="12px"><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">user-name</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">root</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&lt;/</span><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">user-name</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">&lt;</font></span><font size="12px"><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">password</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">rootpassword</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&lt;/</span><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">password</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">&lt;</font></span><font size="12px"><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">exception-sorter-class-name</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">org.jboss.resource.adapter.jdbc.vendor.MySQLExceptionSorter</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&lt;/</span><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">exception-sorter-class-name</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">&lt;</font></span><font size="12px"><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">metadata</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">&lt;</font></span><font size="12px"><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">type-mapping</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">mySQL</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&lt;/</span><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">type-mapping</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">&lt;/</font></span><font size="12px"><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">metadata</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">&lt;/</font></span><font size="12px"><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">local-tx-datasource</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">&lt;/</font></span><font size="12px"><span class="tag-name" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">datasources</span><span class="tag" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&gt;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
    </ol>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#36825;&#37324;&#65292;&#23450;&#20041;&#20102;&#19968;&#20010;&#21517;&#20026;MySqlDS&#30340;&#25968;&#25454;&#28304;&#65292;&#20854;&#21442;&#25968;&#21253;&#25324;JDBC&#30340;URL&#65292;&#39537;&#21160;&#31867;&#21517;&#65292;&#29992;&#25143;&#21517;&#21450;&#23494;&#30721;&#31561;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      2&#12289;&#22312;&#31243;&#24207;&#20013;&#24341;&#29992;&#25968;&#25454;&#28304;&#65306;
    </p>
    <ol class="dp-j" style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; text-align: -webkit-left; margin-right: 0px; list-style: none; margin-bottom: 0px; font-size: 12px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">Connection&#160;conn=</font></span><font size="12px"><span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">null</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">; &#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">try</font></span><font size="12px"><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;{ &#160;</span></font>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">Context&#160;ctx=</font></span><font size="12px"><span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">new</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;InitialContext(); &#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">Object&#160;datasourceRef=ctx.lookup(</font></span><font size="12px"><span class="string" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&quot;java:MySqlDS&quot;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">);&#160;</span><span class="comment" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">//&#24341;&#29992;&#25968;&#25454;&#28304;</span><span class="Apple-converted-space">&#160;</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">DataSource&#160;ds=(Datasource)datasourceRef; &#160;</font></span>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">conn=ds.getConnection(); &#160;</font></span>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="comment" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">/*&#160;&#20351;&#29992;conn&#36827;&#34892;&#25968;&#25454;&#24211;SQL&#25805;&#20316;&#160;*/</font></span><font size="12px"><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">...... &#160;</font></span>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">c.close(); &#160;</font></span>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">}&#160;&#160;&#160;</font></span>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">catch</font></span><font size="12px"><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">(Exception&#160;e)&#160;{ &#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">e.printStackTrace(); &#160;</font></span>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">}&#160;&#160;&#160;</font></span>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">finally</font></span><font size="12px"><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;{ &#160;</span></font>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">if</font></span><font size="12px"><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">(conn!=</span><span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">null</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">)&#160;{ &#160;</span></font>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">try</font></span><font size="12px"><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">&#160;{ &#160;</span></font>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">conn.close(); &#160;</font></span>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">}&#160;</font></span><font size="12px"><span class="keyword" style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">catch</span><span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px">(SQLException&#160;e)&#160;{&#160;} &#160;</span></font>
      </li>
      <li class="alt" style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">} &#160;</font></span>
      </li>
      <li style="padding-right: 0px; padding-left: 0px; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; font-size: 12px; margin-left: 0px; padding-top: 0px; margin-right: 0px">
        <span style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; font-size: 12px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="12px">}&#160;</font></span>
      </li>
    </ol>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#30452;&#25509;&#20351;&#29992;JDBC&#25110;&#32773;&#36890;&#36807;JNDI&#24341;&#29992;&#25968;&#25454;&#28304;&#30340;&#32534;&#31243;&#20195;&#30721;&#37327;&#30456;&#24046;&#26080;&#20960;&#65292;&#20294;&#26159;&#29616;&#22312;&#30340;&#31243;&#24207;&#21487;&#20197;&#19981;&#29992;&#20851;&#24515;&#20855;&#20307;JDBC&#21442;&#25968;&#20102;&#12290;<font size="14px"><br style="padding-right: 0px; padding-left: 0px; line-height: 1.5em; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; margin-left: 0px; padding-top: 0px; margin-right: 0px" /></font>&#22312;&#31995;&#32479;&#37096;&#32626;&#21518;&#65292;&#22914;&#26524;&#25968;&#25454;&#24211;&#30340;&#30456;&#20851;&#21442;&#25968;&#21464;&#26356;&#65292;&#21482;&#38656;&#35201;&#37325;&#26032;&#37197;&#32622; mysql-ds.xml &#20462;&#25913;&#20854;&#20013;&#30340;JDBC&#21442;&#25968;&#65292;&#21482;&#35201;&#20445;&#35777;&#25968;&#25454;&#28304;&#30340;&#21517;&#31216;&#19981;&#21464;&#65292;&#37027;&#20040;&#31243;&#24207;&#28304;&#20195;&#30721;&#23601;&#26080;&#38656;&#20462;&#25913;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#30001;&#27492;&#21487;&#35265;&#65292;JNDI&#36991;&#20813;&#20102;&#31243;&#24207;&#19982;&#25968;&#25454;&#24211;&#20043;&#38388;&#30340;&#32039;&#32806;&#21512;&#65292;&#20351;&#24212;&#29992;&#26356;&#21152;&#26131;&#20110;&#37197;&#32622;&#12289;&#26131;&#20110;&#37096;&#32626;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      JNDI&#30340;&#25193;&#23637;&#65306;JNDI&#22312;&#28385;&#36275;&#20102;&#25968;&#25454;&#28304;&#37197;&#32622;&#30340;&#35201;&#27714;&#30340;&#22522;&#30784;&#19978;&#65292;&#36824;&#36827;&#19968;&#27493;&#25193;&#20805;&#20102;&#20316;&#29992;&#65306;&#25152;&#26377;&#19982;&#31995;&#32479;&#22806;&#37096;&#30340;&#36164;&#28304;&#30340;&#24341;&#29992;&#65292;&#37117;&#21487;&#20197;&#36890;&#36807;JNDI&#23450;&#20041;&#21644;&#24341;&#29992;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#25152;&#20197;&#65292;&#22312;J2EE&#35268;&#33539;&#20013;&#65292;J2EE &#20013;&#30340;&#36164;&#28304;&#24182;&#19981;&#23616;&#38480;&#20110; JDBC &#25968;&#25454;&#28304;&#12290;&#24341;&#29992;&#30340;&#31867;&#22411;&#26377;&#24456;&#22810;&#65292;&#20854;&#20013;&#21253;&#25324;&#36164;&#28304;&#24341;&#29992;&#65288;&#24050;&#32463;&#35752;&#35770;&#36807;&#65289;&#12289;&#29615;&#22659;&#23454;&#20307;&#21644; EJB &#24341;&#29992;&#12290;&#29305;&#21035;&#26159; EJB &#24341;&#29992;&#65292;&#23427;&#26292;&#38706;&#20102; JNDI &#22312; J2EE &#20013;&#30340;&#21478;&#22806;&#19968;&#39033;&#20851;&#38190;&#35282;&#33394;&#65306;&#26597;&#25214;&#20854;&#20182;&#24212;&#29992;&#31243;&#24207;&#32452;&#20214;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      EJB &#30340; JNDI &#24341;&#29992;&#38750;&#24120;&#31867;&#20284;&#20110; JDBC &#36164;&#28304;&#30340;&#24341;&#29992;&#12290;&#22312;&#26381;&#21153;&#36235;&#20110;&#36716;&#25442;&#30340;&#29615;&#22659;&#20013;&#65292;&#36825;&#26159;&#19968;&#31181;&#24456;&#26377;&#25928;&#30340;&#26041;&#27861;&#12290;&#21487;&#20197;&#23545;&#24212;&#29992;&#31243;&#24207;&#26550;&#26500;&#20013;&#25152;&#24471;&#21040;&#30340;&#25152;&#26377;&#32452;&#20214;&#36827;&#34892;&#36825;&#31867;&#37197;&#32622;&#31649;&#29702;&#65292;&#20174; EJB &#32452;&#20214;&#21040; JMS &#38431;&#21015;&#21644;&#20027;&#39064;&#65292;&#20877;&#21040;&#31616;&#21333;&#37197;&#32622;&#23383;&#31526;&#20018;&#25110;&#20854;&#20182;&#23545;&#35937;&#65292;&#36825;&#21487;&#20197;&#38477;&#20302;&#38543;&#26102;&#38388;&#30340;&#25512;&#31227;&#26381;&#21153;&#21464;&#26356;&#25152;&#20135;&#29983;&#30340;&#32500;&#25252;&#25104;&#26412;&#65292;&#21516;&#26102;&#36824;&#21487;&#20197;&#31616;&#21270;&#37096;&#32626;&#65292;&#20943;&#23569;&#38598;&#25104;&#24037;&#20316;&#12290; &#22806;&#37096;&#36164;&#28304;&#8221;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      <strong style="margin-top: 0px; padding-left: 0px; padding-bottom: 0px; padding-top: 0px; margin-right: 0px; line-height: 1.5em; font-size: 14px; margin-bottom: 0px; margin-left: 0px; padding-right: 0px"><font size="14px">&#24635; &#32467;&#65306;</font></strong>
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      J2EE &#35268;&#33539;&#35201;&#27714;&#25152;&#26377; J2EE &#23481;&#22120;&#37117;&#35201;&#25552;&#20379; JNDI &#35268;&#33539;&#30340;&#23454;&#29616;&#12290;JNDI &#22312; J2EE &#20013;&#30340;&#35282;&#33394;&#23601;&#26159;&#8220;&#20132;&#25442;&#26426;&#8221; &#8212;&#8212; J2EE &#32452;&#20214;&#22312;&#36816;&#34892;&#26102;&#38388;&#25509;&#22320;&#26597;&#25214;&#20854;&#20182;&#32452;&#20214;&#12289;&#36164;&#28304;&#25110;&#26381;&#21153;&#30340;&#36890;&#29992;&#26426;&#21046;&#12290;&#22312;&#22810;&#25968;&#24773;&#20917;&#19979;&#65292;&#25552;&#20379; JNDI &#20379;&#24212;&#32773;&#30340;&#23481;&#22120;&#21487;&#20197;&#20805;&#24403;&#26377;&#38480;&#30340;&#25968;&#25454;&#23384;&#20648;&#65292;&#36825;&#26679;&#31649;&#29702;&#21592;&#23601;&#21487;&#20197;&#35774;&#32622;&#24212;&#29992;&#31243;&#24207;&#30340;&#25191;&#34892;&#23646;&#24615;&#65292;&#24182;&#35753;&#20854;&#20182;&#24212;&#29992;&#31243;&#24207;&#24341;&#29992;&#36825;&#20123;&#23646;&#24615;&#65288;Java &#31649;&#29702;&#25193;&#23637;&#65288;Java Management Extensions&#65292;JMX&#65289;&#20063;&#21487;&#20197;&#29992;&#20316;&#36825;&#20010;&#30446;&#30340;&#65289;&#12290;JNDI &#22312; J2EE &#24212;&#29992;&#31243;&#24207;&#20013;&#30340;&#20027;&#35201;&#35282;&#33394;&#23601;&#26159;&#25552;&#20379;&#38388;&#25509;&#23618;&#65292;&#36825;&#26679;&#32452;&#20214;&#23601;&#21487;&#20197;&#21457;&#29616;&#25152;&#38656;&#35201;&#30340;&#36164;&#28304;&#65292;&#32780;&#19981;&#29992;&#20102;&#35299;&#36825;&#20123;&#38388;&#25509;&#24615;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#22312; J2EE &#20013;&#65292;JNDI &#26159;&#25226; J2EE &#24212;&#29992;&#31243;&#24207;&#21512;&#22312;&#19968;&#36215;&#30340;&#31896;&#21512;&#21058;&#65292;JNDI &#25552;&#20379;&#30340;&#38388;&#25509;&#23547;&#22336;&#20801;&#35768;&#36328;&#20225;&#19994;&#20132;&#20184;&#21487;&#20280;&#32553;&#30340;&#12289;&#21151;&#33021;&#24378;&#22823;&#19988;&#24456;&#28789;&#27963;&#30340;&#24212;&#29992;&#31243;&#24207;&#12290;&#36825;&#26159; J2EE &#30340;&#25215;&#35834;&#65292;&#32780;&#19988;&#32463;&#36807;&#19968;&#20123;&#35745;&#21010;&#21644;&#39044;&#20808;&#32771;&#34385;&#65292;&#36825;&#20010;&#25215;&#35834;&#26159;&#23436;&#20840;&#21487;&#20197;&#23454;&#29616;&#30340;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#26368;&#36817;&#19968;&#30452;&#22312;&#23545;J2EE&#30340;&#31508;&#35760;&#36827;&#34892;&#25972;&#29702;&#21644;&#22797;&#20064;,&#34429;&#28982;J2EE&#35270;&#39057;&#26159;&#30475;&#36807;&#19968;&#36941;&#20102;,&#20294;&#26159;&#24403;&#25105;&#30475;&#33258;&#24049;&#20570;&#30340;&#31508;&#35760;&#30340;&#26102;&#20505;&#38476;&#29983;&#31243;&#24230;&#36824;&#26159;&#24456;&#22823;,&#32780;&#30495;&#27491;&#30340;&#23545;&#26576;&#20010;&#27010;&#24565;&#26377;&#25152;&#35748;&#35782;&#30340;&#26102;&#20505;&#26159;&#23558;&#31508;&#35760;&#21644;&#20197;&#21069;&#30475;&#36807;&#30340;&#35270;&#39057;&#21360;&#35937;&#36827;&#34892;&#25705;&#25830;,J2EE&#20027;&#35201;&#35762;&#35299;&#30340;&#20869;&#23481;&#26159;&#21508;&#20010;&#35268;&#33539;,&#20877;&#28165;&#26970;&#19968;&#20123;&#23601;&#26159;&#21508;&#20010;&#27010;&#24565;,&#29616;&#38454;&#27573;&#30340;&#30446;&#26631;&#24182;&#19981;&#26159;&#25484;&#25569;J2EE,&#32780;&#26159;&#23545;J2EE&#36827;&#34892;&#36718;&#24275;&#21644;&#27010;&#24565;&#19978;&#30340;&#20102;&#35299;&#21644;&#35748;&#35782;,&#21040;&#19979;&#19968;&#27493;DRP&#39033;&#30446;&#20013;&#20877;&#28145;&#23618;&#27425;&#30340;&#23545;&#21508;&#20010;&#35268;&#33539;&#36827;&#34892;&#25705;&#25830;&#21644;&#35748;&#35782;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      JNDI,&#32763;&#35793;&#20026;Java&#21629;&#21517;&#21644;&#30446;&#24405;&#32467;&#26500;(JavaNaming And Directory Interface)&#23448;&#26041;&#23545;&#20854;&#35299;&#37322;&#20026;JNDI&#26159;&#19968;&#32452;&#22312;Java&#24212;&#29992;&#20013;&#35775;&#38382;&#21629;&#21517;&#21644;&#30446;&#24405;&#26381;&#21153;&#30340;API(ApplicationProgramming Interface)&#35828;&#26126;&#24456;&#31934;&#28860;,&#20294;&#26159;&#27604;&#36739;&#25277;&#35937;&#12290;<font size="14px"><br style="padding-right: 0px; padding-left: 0px; line-height: 1.5em; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; margin-left: 0px; padding-top: 0px; margin-right: 0px" /><br style="padding-right: 0px; padding-left: 0px; line-height: 1.5em; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; margin-left: 0px; padding-top: 0px; margin-right: 0px" /></font>&#19978;&#38754;&#30340;&#35299;&#37322;&#20013;&#25552;&#39640;&#20102;&#21629;&#21517;&#26381;&#21153;&#21644;&#30446;&#24405;&#26381;&#21153;&#20004;&#20010;&#27010;&#24565;.&#20808;&#35201;&#20102;&#35299;JNDI&#23601;&#24517;&#39035;&#30693;&#36947;,&#21629;&#21517;&#26381;&#21153;&#21644;&#30446;&#24405;&#26381;&#21153;&#26159;&#20570;&#20160;&#20040;&#29992;&#30340;&#12290;<font size="14px"><br style="padding-right: 0px; padding-left: 0px; line-height: 1.5em; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; margin-left: 0px; padding-top: 0px; margin-right: 0px" /><br style="padding-right: 0px; padding-left: 0px; line-height: 1.5em; margin-top: 0px; margin-bottom: 0px; padding-bottom: 0px; margin-left: 0px; padding-top: 0px; margin-right: 0px" /></font>&#23398;&#20064;&#26032;&#30340;&#27010;&#24565;&#21644;&#30693;&#35782;&#65292;&#27604;&#36739;&#26377;&#25928;&#30340;&#26041;&#24335;&#26159;&#36890;&#36807;&#21644;&#20197;&#21069;&#25152;&#23398;&#36807;&#30340;&#20869;&#23481;&#36827;&#34892;&#32852;&#31995;&#65292;&#27604;&#36739;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#20851;&#20110;&#21629;&#21517;&#26381;&#21153;,&#20854;&#23454;&#25105;&#20204;&#24456;&#22810;&#26102;&#20505;&#37117;&#22312;&#29992;&#23427;,&#20294;&#26159;&#24182;&#19981;&#30693;&#36947;&#23427;&#26159;&#23427;,&#27604;&#36739;&#20856;&#22411;&#30340;&#26159;&#22495;&#21517;&#26381;&#21153;&#22120;DNS(Domain Naming Service),&#22823;&#23545;&#20154;&#23545;DNS&#36824;&#26159;&#27604;&#36739;&#20102;&#35299;&#30340;,&#23427;&#26159;&#23558;&#22495;&#21517;&#26144;&#23556;&#21040;IP&#22320;&#22336;&#30340;&#26381;&#21153;.&#27604;&#22914;&#30334;&#24230;&#30340;&#22495;&#21517;<a style="text-decoration: none; margin-top: 0px; padding-left: 0px; padding-bottom: 0px; color: rgb(0, 94, 167); padding-top: 0px; margin-right: 0px; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; margin-left: 0px; padding-right: 0px" href="http://developer.51cto.com/art/201112/www.baidu.com"><font size="14px" color="rgb(0, 94, 167)">www.baidu.com</font></a>&#25152;&#26144;&#23556;&#30340;IP&#22320;&#22336;&#26159;<a style="text-decoration: none; margin-top: 0px; padding-left: 0px; padding-bottom: 0px; color: rgb(0, 94, 167); padding-top: 0px; margin-right: 0px; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; margin-left: 0px; padding-right: 0px" href="http://202.108.22.5/"><font size="14px" color="rgb(0, 94, 167)">http://202.108.22.5/</font></a>,&#20320;&#22312;&#27983;&#35272;&#22120;&#20013;&#36755;&#20837;&#20004;&#20010;&#20869;&#23481;&#26159;&#21040;&#30340;&#21516;&#19968;&#20010;&#39029;&#38754;.&#29992;&#21629;&#21517;&#26381;&#21153;&#22120;&#30340;&#21407;&#22240;&#26159;&#22240;&#20026;&#25105;&#20204;&#35760;&#24518;baidu&#36825;&#20960;&#20010;&#26377;&#24847;&#20041;&#30340;&#23383;&#27597;&#35201;&#27604;&#35760;202.108.22.5&#26356;&#23481;&#26131;&#35760;&#24518;,&#20294;&#22914;&#26524;&#31449;&#21040;&#35745;&#31639;&#26426;&#30340;&#35282;&#24230;&#19978;,&#23427;&#26356;&#21916;&#27426;&#22788;&#29702;&#36825;&#20123;&#25968;&#23383;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#20174;&#25105;&#20204;&#29983;&#27963;&#20013;&#25214;&#30340;&#35805;&#36824;&#26377;&#24456;&#22810;&#31867;&#20284;&#30340;&#20363;&#23376;,&#27604;&#22914;&#35828;&#20320;&#30340;&#36523;&#20221;&#35777;&#21495;&#21644;&#20320;&#30340;&#21517;&#23383;&#21487;&#20197;&quot;&#29702;&#35299;&quot;&#25104;&#19968;&#31181;&#21629;&#21517;&#26381;&#21153;,&#20320;&#30340;&#23398;&#21495;&#21644;&#22995;&#21517;&#20063;&#21487;&#20197;&quot;&#35299;&#37322;&quot;&#20026;&#19968;&#31181;&#21629;&#21517;&#26381;&#21153;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#21487;&#20197;&#30475;&#20986;&#21629;&#21517;&#26381;&#21153;&#30340;&#29305;&#28857;:&#19968;&#20010;&#20540;&#21644;&#21478;&#19968;&#20010;&#20540;&#30340;&#26144;&#23556;,&#23558;&#25105;&#20204;&#20154;&#31867;&#26356;&#23481;&#26131;&#35748;&#35782;&#30340;&#20540;&#21516;&#35745;&#31639;&#26426;&#26356;&#23481;&#26131;&#35748;&#35782;&#30340;&#20540;&#36827;&#34892;&#19968;&#19968;&#26144;&#23556;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#21040;&#29616;&#22312;&#24212;&#35813;&#23545;&#21629;&#21517;&#26381;&#21153;&#26377;&#25152;&#29702;&#35299;&#21543;?
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#33267;&#20110;&#30446;&#24405;&#26381;&#21153;,&#20174;&#35745;&#31639;&#26426;&#35282;&#24230;&#29702;&#35299;&#20026;&#22312;&#20114;&#32852;&#32593;&#19978;&#26377;&#30528;&#21508;&#31181;&#21508;&#26679;&#30340;&#36164;&#28304;&#21644;&#20027;&#26426;,&#20294;&#26159;&#36825;&#20123;&#20869;&#23481;&#37117;&#26159;&#25955;&#33853;&#22312;&#20114;&#32852;&#32593;&#20013;,&#20026;&#20102;&#35775;&#38382;&#36825;&#20123;&#25955;&#33853;&#30340;&#36164;&#28304;&#24182;&#33719;&#24471;&#30456;&#24212;&#30340;&#26381;&#21153;,&#23601;&#38656;&#35201;&#29992;&#21040;&#30446;&#24405;&#26381;&#21153;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; text-indent: 0px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      <a style="text-decoration: none; margin-top: 0px; padding-left: 0px; padding-bottom: 0px; color: rgb(0, 94, 167); padding-top: 0px; margin-right: 0px; line-height: 1.5em; margin-bottom: 0px; font-size: 14px; margin-left: 0px; padding-right: 0px" target="_blank" href="http://images.51cto.com/files/uploadimg/20111231/1547420.png"><font size="14px" color="rgb(0, 94, 167)"><img border="0" width="435" height="406" style="padding-right: 0px; margin-bottom: 0px; border-top-style: none; border-left-style: none; padding-top: 0px; border-left-width: 0px; border-right-style: none; border-top-width: 0px; line-height: 1.5em; padding-bottom: 0px; margin-top: 0px; margin-left: 0px; padding-left: 0px; border-bottom-style: none; border-right-width: 0px; border-bottom-width: 0px; margin-right: 0px" src="http://images.51cto.com/files/uploadimg/20111231/1547420.png" class="fit-image" alt="" />
      </font></a>
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; text-indent: 0px; margin-bottom: 0px; font-size: 14px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#20174;&#25105;&#20204;&#26085;&#24120;&#29983;&#27963;&#20013;&#21435;&#29702;&#35299;&#30446;&#24405;&#26381;&#21153;&#30340;&#27010;&#24565;&#21487;&#20197;&#20174;&#30005;&#35805;&#31807;&#35828;&#36215;,&#30005;&#35805;&#31807;&#26412;&#36523;&#23601;&#26159;&#19968;&#20010;&#27604;&#36739;&#20856;&#22411;&#30340;&#30446;&#24405;&#26381;&#21153;,&#22914;&#26524;&#20320;&#35201;&#25214;&#21040;&#26576;&#20010;&#20154;&#30340;&#30005;&#35805;&#21495;&#30721;,&#20320;&#38656;&#35201;&#20174;&#30005;&#35805;&#31807;&#37324;&#25214;&#21040;&#36825;&#20010;&#20154;&#30340;&#21517;&#31216;,&#28982;&#21518;&#20877;&#30475;&#20854;&#30005;&#35805;&#21495;&#30721;&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; text-indent: 0px; margin-bottom: 0px; font-size: 14px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      <a style="padding-right: 0px; margin-bottom: 0px; text-decoration: none; padding-top: 0px; line-height: 1.5em; padding-bottom: 0px; margin-top: 0px; font-size: 14px; margin-left: 0px; padding-left: 0px; color: rgb(0, 94, 167); margin-right: 0px" target="_blank" href="http://images.51cto.com/files/uploadimg/20111231/1547421.png"><font size="14px" color="rgb(0, 94, 167)"><img border="0" width="386" height="523" style="padding-right: 0px; margin-bottom: 0px; border-top-style: none; border-left-style: none; padding-top: 0px; border-left-width: 0px; border-right-style: none; border-top-width: 0px; line-height: 1.5em; padding-bottom: 0px; margin-top: 0px; margin-left: 0px; padding-left: 0px; border-bottom-style: none; border-right-width: 0px; border-bottom-width: 0px; margin-right: 0px" src="http://images.51cto.com/files/uploadimg/20111231/1547421.png" class="fit-image" alt="" />
      </font></a>&#160;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; text-indent: 0px; margin-bottom: 0px; font-size: 14px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#29702;&#35299;&#20102;&#21629;&#21517;&#26381;&#21153;&#21644;&#30446;&#24405;&#26381;&#21153;&#20877;&#22238;&#36807;&#22836;&#26469;&#30475;JDNI,&#23427;&#26159;&#19968;&#20010;&#20026;Java&#24212;&#29992;&#31243;&#24207;&#25552;&#20379;&#21629;&#21517;&#26381;&#21153;&#30340;&#24212;&#29992;&#31243;&#24207;&#25509;&#21475;,&#20026;&#25105;&#20204;&#25552;&#20379;&#20102;&#26597;&#25214;&#21644;&#35775;&#38382;&#21508;&#31181;&#21629;&#21517;&#21644;&#30446;&#24405;&#26381;&#21153;&#30340;&#36890;&#29992;&#32479;&#19968;&#30340;&#25509;&#21475;.&#36890;&#36807;JNDI&#32479;&#19968;&#25509;&#21475;&#25105;&#20204;&#21487;&#20197;&#26469;&#35775;&#38382;&#21508;&#31181;&#19981;&#21516;&#31867;&#22411;&#30340;&#26381;&#21153;.&#22914;&#19979;&#22270;&#25152;&#31034;,&#25105;&#20204;&#21487;&#20197;&#36890;&#36807;JNDI API&#26469;&#35775;&#38382;&#21018;&#25165;&#35848;&#21040;&#30340;DNS&#12290;
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; text-indent: 0px; margin-bottom: 0px; font-size: 14px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      <a style="padding-right: 0px; margin-bottom: 0px; text-decoration: none; padding-top: 0px; line-height: 1.5em; padding-bottom: 0px; margin-top: 0px; font-size: 14px; margin-left: 0px; padding-left: 0px; color: rgb(0, 94, 167); margin-right: 0px" target="_blank" href="http://images.51cto.com/files/uploadimg/20111231/1547422.png"><font size="14px" color="rgb(0, 94, 167)"><img border="0" width="498" height="514" style="padding-right: 0px; margin-bottom: 0px; border-top-style: none; border-left-style: none; padding-top: 0px; border-left-width: 0px; border-right-style: none; border-top-width: 0px; line-height: 1.5em; padding-bottom: 0px; margin-top: 0px; margin-left: 0px; padding-left: 0px; border-bottom-style: none; border-right-width: 0px; border-bottom-width: 0px; margin-right: 0px" src="http://images.51cto.com/files/uploadimg/20111231/1547422.png" class="fit-image" alt="" />
      </font></a>
    </p>
    <p style="font-style: normal; margin-top: 0px; padding-left: 0px; word-spacing: 0px; letter-spacing: normal; padding-bottom: 0px; color: rgb(0, 0, 0); font-family: verdana, arial, helvetica, sans-serif; padding-top: 0px; margin-right: 0px; text-align: -webkit-left; line-height: 1.5em; text-indent: 0px; margin-bottom: 0px; font-size: 14px; text-transform: none; white-space: normal; margin-left: 0px; font-weight: normal; padding-right: 0px">
      &#33267;&#27492;&#24050;&#32463;&#23545;JNDI&#26377;&#20102;&#19968;&#20010;&#21021;&#27493;&#35748;&#35782;,&#22914;&#26524;&#24819;&#35201;&#36827;&#19968;&#27493;&#20102;&#35299;JNDI,&#24182;&#23545;&#20351;&#29992;JDNI&#32473;&#25105;&#20204;&#24102;&#26469;&#21738;&#20123;&#20415;&#21033;&#20043;&#22788;,&#25105;&#25512;&#33616;&#20004;&#31687;&#20851;&#20110;JDNI&#30340;&#25991;&#31456;,&#20889;&#30340;&#38750;&#24120;&#30340;&#22909;,&#20004;&#31687;&#25991;&#31456;&#20174;&#8220;&#22914;&#26524;&#19981;&#29992;JNDI&#25105;&#20204;&#24590;&#26679;&#20570;&#65311;&#29992;&#20102;JNDI&#21518;&#25105;&#20204;&#21448;&#23558;&#24590;&#26679;&#20570;&#65311;&#8221;&#36825;&#20010;&#35282;&#24230;&#26469;&#21152;&#28145;&#23545;JNDI&#30340;&#35748;&#35782;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1491231360641" FOLDED="true" ID="ID_682361861" MODIFIED="1491231535343" TEXT="&#x7406;&#x89e3;&#x6587;&#x7ae0;2 ">
<node CREATED="1491231386216" FOLDED="true" ID="ID_23059463" MODIFIED="1491231526089">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20851;&#38190;&#23383;&#65306;JNDI,J2EE,Java&#65292;&#21629;&#21517;&#21644;&#30446;&#24405;&#25509;&#21475;&#65292;Java Naming and Directory Interface
    </p>
    <div style="font-style: normal; background-color: rgb(255, 255, 255); word-spacing: 0px; letter-spacing: normal; color: rgb(0, 0, 0); font-family: Verdana, Lucida Grande, Arial, Helvetica, sans-serif; text-align: start; font-size: 12px; text-indent: 0px; white-space: normal; text-transform: none; font-weight: normal">
      <strong><font size="3" face="&#x65b0;&#x5b8b;&#x4f53;">&#160;&#160;&#160;&#160;&#160;&#160; </font><font size="2" face="&#x65b0;&#x5b8b;&#x4f53;">http://www.cnblogs.com/chinafine/archive/2010/06/16/1759246.html </font><font size="3" face="&#x65b0;&#x5b8b;&#x4f53;">&#20026;&#20160;&#20040;&#20250;&#26377;jndi</font></strong>
    </div>
    <div style="font-style: normal; background-color: rgb(255, 255, 255); word-spacing: 0px; letter-spacing: normal; color: rgb(0, 0, 0); font-family: Verdana, Lucida Grande, Arial, Helvetica, sans-serif; text-align: start; font-size: 12px; text-indent: 0px; text-transform: none; white-space: normal; font-weight: normal">
      <font size="3" face="&#x65b0;&#x5b8b;&#x4f53;">&#160;&#160;&#160;&#160;jndi&#35806;&#29983;&#30340;&#29702;&#30001;&#20284;&#20046;&#24456;&#31616;&#21333;&#12290;&#38543;&#30528;&#20998;&#24067;&#24335;&#24212;&#29992;&#30340;&#21457;&#23637;&#65292;&#36828;&#31243;&#35775;&#38382;&#23545;&#35937;&#35775;&#38382;&#25104;&#20026;&#24120;&#29992;&#30340;&#26041;&#27861;&#12290;&#34429;&#28982;&#35828;&#36890;&#36807; Socket&#31561;&#32534;&#31243;&#25163;&#27573;&#20173;&#28982;&#21487;&#23454;&#29616;&#36828;&#31243;&#36890;&#20449;&#65292;&#20294;&#25353;&#29031;&#27169;&#24335;&#30340;&#29702;&#35770;&#26469;&#35828;&#65292;&#20173;&#26159;&#26377;&#20854;&#23616;&#38480;&#24615;&#30340;&#12290;RMI&#25216;&#26415;&#65292;RMI-IIOP&#25216;&#26415;&#30340;&#20135;&#29983;&#65292;&#20351;&#36828;&#31243;&#23545;&#35937;&#30340;&#26597;&#25214;&#25104;&#20026;&#20102;&#25216;&#26415;&#28966;&#28857;&#12290;JNDI&#25216;&#26415;&#23601;&#24212;&#36816;&#32780;&#29983;&#12290;JNDI&#25216;&#26415;&#20135;&#29983;&#21518;&#65292;&#23601;&#21487;&#26041;&#20415;&#30340;&#26597;&#25214;&#36828;&#31243;&#25110;&#26159;&#26412;&#22320;&#23545;&#35937;&#12290;</font>
    </div>
  </body>
</html></richcontent>
<arrowlink DESTINATION="ID_23059463" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_465065450" STARTARROW="None" STARTINCLINATION="0;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_23059463" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_465065450" SOURCE="ID_23059463" STARTARROW="None" STARTINCLINATION="0;0;"/>
<node CREATED="1491231496910" ID="ID_1304702479" MODIFIED="1491231523969">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p style="font-style: normal; margin-top: 10px; background-color: rgb(255, 255, 255); word-spacing: 0px; letter-spacing: normal; color: rgb(0, 0, 0); font-family: Verdana, Lucida Grande, Arial, Helvetica, sans-serif; margin-right: 0; text-align: start; text-indent: 0px; font-size: 12px; margin-bottom: 10px; text-transform: none; white-space: normal; font-weight: normal; margin-left: 0">
      <strong><span style="font-size: small"><font size="2">&#20851;&#38190;&#23383;&#65306;JNDI,J2EE,Java&#65292;&#21629;&#21517;&#21644;&#30446;&#24405;&#25509;&#21475;&#65292;Java Naming and Directory Interface</font></span></strong>
    </p>
    <div class="blog_content" style="font-style: normal; background-color: rgb(255, 255, 255); word-spacing: 0px; letter-spacing: normal; color: rgb(0, 0, 0); font-family: Verdana, Lucida Grande, Arial, Helvetica, sans-serif; text-align: start; font-size: 12px; text-indent: 0px; text-transform: none; white-space: normal; font-weight: normal">
      <div>
        <p style="text-indent: 0px; margin-top: 10px; margin-bottom: 10px; margin-left: 0; margin-right: 0">
          <strong><span style="font-size: small"><font size="2">&#25688;&#35201;:</font></span></strong>
        </p>
      </div>
      <blockquote style="margin-top: 0px; padding-left: 4px; background-image: null; padding-bottom: 4px; background-attachment: scroll; padding-top: 4px; margin-right: 0px; background-position: null; margin-bottom: 0px; background-repeat: repeat; margin-left: 0px; padding-right: 4px">
        <div>
          <span style="font-size: small"><font size="2">&#26412;&#25991;&#35814;&#32454;&#20171;&#32461;&#20102;JNDI&#30340;&#26550;&#26500;&#19982;&#23454;&#29616;,JNDI&#30340;&#24037;&#20316;&#21407;&#29702;&#65292;&#24182;&#32473;&#20986;&#20102;&#20855;&#20307;&#20195;&#30721;&#65292;&#24110;&#21161;&#35835;&#32773;&#26356;&#29702;&#35299;J2EE&#20027;&#35201;&#24120;&#29992;&#25216;&#26415;---JNDI.&#26412;&#25991;&#20026;&#31995;&#21015;&#25991;&#31456;&#30340;&#31532;&#19968;&#31687;&#65292;&#20854;&#23427;&#30456;&#20851;&#25991;&#31456;&#20250;&#22312;&#36817;&#26399;&#25512;&#20986;&#12290;</font></span>
        </div>
      </blockquote>
      <div>
        <span style="font-size: small"><font size="2">&#160;</font></span>
      </div>
      <div>
        <strong><span style="font-size: small"><font size="2">&#21517;&#35789;&#35299;&#37322;</font></span></strong>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#160;&#160;&#160;&#160;jndi&#26159;Java &#21629;&#21517;&#21644;&#30446;&#24405;&#25509;&#21475;&#65288;Java Naming and Directory Interface&#65292;JNDI&#65289;&#30340;&#31616;&#31216;.&#20174;&#19968;&#24320;&#22987;&#23601;&#19968;&#30452;&#26159; Java 2 &#24179;&#21488;&#20225;&#19994;&#29256;&#65288;JEE&#65289;&#30340;&#26680;&#24515;&#25216;&#26415;&#20043;&#19968;&#12290;&#22312;JMS&#65292;JMail,JDBC,EJB&#31561;&#25216;&#26415;&#20013;&#65292;&#23601;&#22823;&#37327;&#24212;&#29992;&#30340;&#36825;&#31181;&#25216;&#26415;&#12290;</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#160;&#160;&#160;&#160;</font></span>
      </div>
      <div>
        <strong><span style="font-size: small"><font size="2">&#20026;&#20160;&#20040;&#20250;&#26377;jndi</font></span></strong>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#160;&#160;&#160;&#160;jndi&#35806;&#29983;&#30340;&#29702;&#30001;&#20284;&#20046;&#24456;&#31616;&#21333;&#12290;&#38543;&#30528;&#20998;&#24067;&#24335;&#24212;&#29992;&#30340;&#21457;&#23637;&#65292;&#36828;&#31243;&#35775;&#38382;&#23545;&#35937;&#35775;&#38382;&#25104;&#20026;&#24120;&#29992;&#30340;&#26041;&#27861;&#12290;&#34429;&#28982;&#35828;&#36890;&#36807; Socket&#31561;&#32534;&#31243;&#25163;&#27573;&#20173;&#28982;&#21487;&#23454;&#29616;&#36828;&#31243;&#36890;&#20449;&#65292;&#20294;&#25353;&#29031;&#27169;&#24335;&#30340;&#29702;&#35770;&#26469;&#35828;&#65292;&#20173;&#26159;&#26377;&#20854;&#23616;&#38480;&#24615;&#30340;&#12290;RMI&#25216;&#26415;&#65292;RMI-IIOP&#25216;&#26415;&#30340;&#20135;&#29983;&#65292;&#20351;&#36828;&#31243;&#23545;&#35937;&#30340;&#26597;&#25214;&#25104;&#20026;&#20102;&#25216;&#26415;&#28966;&#28857;&#12290;JNDI&#25216;&#26415;&#23601;&#24212;&#36816;&#32780;&#29983;&#12290;JNDI&#25216;&#26415;&#20135;&#29983;&#21518;&#65292;&#23601;&#21487;&#26041;&#20415;&#30340;&#26597;&#25214;&#36828;&#31243;&#25110;&#26159;&#26412;&#22320;&#23545;&#35937;&#12290;</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#160;</font></span>
      </div>
      <div>
        <div>
          <strong><span style="font-size: small"><font size="2">JNDI&#30340;&#26550;&#26500;&#19982;&#23454;&#29616;</font></span></strong>
        </div>
        <div>
          
        </div>
        <div>
          <span style="font-size: small"><font size="2"><img border="0" width="575" height="359" style="border-right-style: none; border-left-width: 0px; border-bottom-style: none; border-top-width: 0px; border-bottom-width: 0px; border-right-width: 0px; border-top-style: none; border-left-style: none" src="http://images.cnblogs.com/cnblogs_com/chinafine/760854_1.jpg" alt="" />
          &#160;&#160;&#160;&#160;<br />JNDI&#30340;&#26550;&#26500;&#19982;JDBC&#30340;&#26550;&#26500;&#38750;&#24120;&#31867;&#20284;.JNDI&#26550;&#26500;&#25552;&#20379;&#20102;&#19968;&#32452;&#26631;&#20934;&#21629;&#21517;&#31995;&#32479;&#30340;API,&#36825;&#20123;API&#22312;JDK1.3&#20043;&#21069;&#26159;&#20316;&#20026;&#19968;&#20010;&#21333;&#29420;&#30340;&#25193;&#23637;&#21253;jndi.jar(</font></span><span style="font-size: small"><a style="text-decoration: none; color: rgb(29, 88, 209)" target="_blank" href="http://java.sun.com/products/jndi/downloads/index.html"><font size="2" color="#108ac6">&#36890;&#36807;&#36825;&#20010;&#22320;&#22336;&#19979;&#36733;</font></a></span><span style="font-size: small"><font size="2">),&#36825;&#20010;&#22522;&#30784;API&#26500;&#24314;&#22312;&#19982;SPI&#20043;&#19978;&#12290;&#36825;&#20010;API&#25552;&#20379;&#22914;&#19979;&#20116;&#20010;&#21253;</font></span>
        </div>
        <ul style="padding-left: 0px; margin-left: 30px">
          <li style="list-style-type: disc">
            <span style="font-size: small"><a style="text-decoration: none; color: rgb(29, 88, 209)" target="_blank" href="http://java.sun.com/products/jndi/tutorial/getStarted/overview/naming.html"><font size="2" color="#108ac6">javax.naming</font></a></span>
          </li>
          <li style="list-style-type: disc">
            <span style="font-size: small"><a style="text-decoration: none; color: rgb(29, 88, 209)" target="_blank" href="http://java.sun.com/products/jndi/tutorial/getStarted/overview/directory.html"><font size="2" color="#108ac6">javax.naming.directory</font></a></span>
          </li>
          <li style="list-style-type: disc">
            <span style="font-size: small"><a style="text-decoration: none; color: rgb(29, 88, 209)" target="_blank" href="http://java.sun.com/products/jndi/tutorial/getStarted/overview/event.html"><font size="2" color="#108ac6">javax.naming.event</font></a></span>
          </li>
          <li style="list-style-type: disc">
            <span style="font-size: small"><a style="text-decoration: none; color: rgb(29, 88, 209)" target="_blank" href="http://java.sun.com/products/jndi/tutorial/getStarted/overview/ldap.html"><font size="2" color="#108ac6">javax.naming.ldap</font></a></span>
          </li>
          <li style="list-style-type: disc">
            <span style="font-size: small"><a style="text-decoration: none; color: rgb(29, 88, 209)" target="_blank" href="http://java.sun.com/products/jndi/tutorial/getStarted/overview/provider.html"><font size="2" color="#108ac6">javax.naming.spi</font></a></span>
          </li>
        </ul>
        <div>
          <span style="font-size: small"><font size="2">&#22312;&#24212;&#29992;&#31243;&#24207;&#20013;,&#25105;&#20204;&#23454;&#38469;&#19978;&#21482;&#20351;&#21040;&#29992;&#20197;&#19978;&#20960;&#20010;&#21253;&#30340;&#20013;&#31867;.&#20855;&#20307;&#35843;&#29992;&#31867;&#21450;&#36890;&#20449;&#36807;&#31243;&#23545;&#29992;&#25143;&#26469;&#35828;&#26159;&#36879;&#26126;&#30340;.</font></span>
        </div>
        <div>
          <span><font size="2">JNDI API&#25552;&#20379;&#20102;&#35775;&#38382;&#19981;&#21516;JNDI&#26381;&#21153;&#30340;&#19968;&#20010;&#26631;&#20934;&#30340;&#32479;&#19968;&#30340;&#23454;&#29616;,&#20854;&#20855;&#20307;&#23454;&#29616;&#21487;&#30001;&#19981;&#21516;&#30340;</font></span><font size="2"><span class="Apple-converted-space">&#160;</span><span>Service Provider&#26469;&#23436;&#25104;&#12290;&#21069;&#38754;&#35762;&#30340;&#20026;&#31532;&#19968;&#23618;JNDI API&#23618;.</span></font>
        </div>
        <div>
          <span style="font-size: small"><font size="2">&#160;</font></span>
        </div>
        <div>
          <span style="font-size: small"><font size="2">&#26368;&#19979;&#23618;&#20026;JNDI SPI API&#21450;&#20854;&#20855;&#20307;&#23454;&#29616;&#12290;</font></span>
        </div>
        <div>
          <span style="font-size: small"><font size="2">&#160;</font></span>
        </div>
        <div>
          <p style="text-indent: 0px; margin-bottom: 10px; margin-top: 10px; margin-left: 0; margin-right: 0">
            <span style="font-size: small"><font size="2">&#22270;&#20013;&#25152;&#21015;&#30340;&#19968;&#20123;SPI&#21487;&#20174;</font></span><span style="font-size: small"><a style="text-decoration: none; color: rgb(29, 88, 209)" target="_blank" href="http://java.sun.com/products/jndi/downloads/index.html"><font size="2" color="#108ac6">http://java.sun.com/products/jndi/downloads/index.html</font></a></span><span style="font-size: small"><font size="2">&#19979;&#36733;.</font></span>
          </p>
          <p style="text-indent: 0px; margin-bottom: 10px; margin-top: 10px; margin-left: 0; margin-right: 0">
            <span style="font-size: small"><font size="2">&#160;</font></span>
          </p>
        </div>
        <div>
          <span lang="EN-US"><font size="2"><br />
          <img border="0" width="230" height="206" style="border-right-style: none; border-left-width: 0px; border-bottom-style: none; border-top-width: 0px; border-bottom-width: 0px; border-right-width: 0px; border-top-style: none; border-left-style: none" src="http://images.cnblogs.com/cnblogs_com/chinafine/760854_2.gif" alt="" />
          &#23427;</font></span><font size="2"><span>&#21253;&#25324;&#20102;&#20960;&#20010;&#22686;&#24378;&#21644;&#19979;&#38754;&#30340;&#21629;&#21517;/&#30446;&#24405;&#26381;&#21153;&#25552;&#20379;&#32773;&#65306;</span></font>
        </div>
        <ul style="padding-left: 0px; margin-left: 30px">
          <li style="list-style-type: disc">
            <span style="font-size: small"><font size="2">LDAP(Lightweight Directory Access Protocol)&#26381;&#21153;&#25552;&#20379;&#32773;</font></span>
          </li>
          <li style="list-style-type: disc">
            <span style="font-size: small"><font size="2">CORBA COS&#65288;Common Object Request Broker Architecture Common Object Services&#65289;&#21629;&#21517;&#26381;&#21153;&#25552;&#20379;&#32773;&#160;</font></span>
          </li>
          <li style="list-style-type: disc">
            <span style="font-size: small"><font size="2">RMI(Java Remote Method Invocation)&#27880;&#20876;&#26381;&#21153;&#25552;&#20379;&#32773;</font></span>
          </li>
          <li style="list-style-type: disc">
            <span style="font-size: small"><font size="2">DNS(Domain Name System)&#26381;&#21153;&#25552;&#20379;&#32773;.</font></span>
          </li>
          <li style="list-style-type: disc">
            <span style="font-size: small"><font size="2">FSSP(File System Service Provider)&#25991;&#20214;&#31995;&#32479;&#26381;&#21153;&#25552;&#20379;&#32773;</font></span>
          </li>
          <li style="list-style-type: disc">
            <span style="font-size: small"><font size="2">&#20854;&#23427;&#26381;&#21153;&#25552;&#20379;&#32773;</font></span>
          </li>
        </ul>
        <div>
          <span style="font-size: small"><font size="2">&#160;</font></span>
        </div>
        <div>
          <span style="font-size: small"><font size="2">&#20013;&#38388;&#23618;&#20026;&#21629;&#21517;&#31649;&#29702;&#23618;&#12290;&#20854;&#21151;&#33021;&#24212;&#35813;&#30001;JNDI SPI&#26469;&#23436;&#25104;&#12290;&#19978;&#23618;&#20026;JNDI API,&#36825;&#20010;API&#21253;&#22312;Java 2 SDK 1.3&#21450;&#20197;&#19978;&#30340;&#29256;&#26412;&#20013;&#24050;&#32463;&#21253;&#25324;&#12290;</font></span>
        </div>
        <div>
          <span style="font-size: small"><font size="2">&#160;</font></span>
        </div>
        <div>
          <span style="font-size: small"><font size="2">&#21069;&#38754;&#35762;&#35299;&#30340;&#21482;&#26159;&#20316;&#20026;&#24212;&#29992;&#31243;&#24207;&#23458;&#25143;&#31471;&#30340;&#26550;&#26500;&#23454;&#29616;,&#20854;&#26381;&#21153;&#31471;&#26159;&#30001;SPI&#23545;&#24212;&#30340;&#20844;&#21496;/&#21378;&#21830;&#26469;&#23454;&#29616;&#30340;,&#25105;&#20204;&#21482;&#38656;&#23558;&#26381;&#21153;&#31471;&#30340;&#30456;&#20851;&#21442;&#25968;&#20256;&#32473;JNDI API&#23601;&#21487;&#20197;&#20102;,&#20855;&#20307;&#35843;&#29992;&#36807;&#31243;&#30001;SPI&#26469;&#23436;&#25104;.</font></span>
        </div>
        <div>
          <span style="font-size: small"><font size="2">&#160;</font></span>
        </div>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#160;</font></span>
      </div>
      <div>
        <span style="font-size: small"><strong><font size="2">JNDI&#24037;&#20316;&#21407;&#29702;</font></strong></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#160;</font></span>
      </div>
      <div>
        <p style="text-indent: 0px; margin-bottom: 10px; margin-top: 10px; margin-left: 0; margin-right: 0">
          <span style="font-size: small"><font size="2">&#19979;&#38754;&#36890;&#36807;&#19968;&#20010;&#31034;&#20363;&#31243;&#24207;&#26469;&#35828;&#26126;JNDI&#24037;&#20316;&#21407;&#29702;(&#20195;&#30721;&#20026;&#33258;&#35299;&#37322;).</font></span>
        </p>
        <pre style="margin-bottom: 0px; margin-top: 0px; font-size: 1em; white-space: pre-wrap; margin-left: 22px; margin-right: 0px"><span style="color: rgb(0, 128, 0)"><font face="Courier New" size="2" color="rgb(0, 128, 0)"><code><em>/*
    * Created on 2005-3-4
    *
    * To change the template for this generated file go to
    * Window&amp;gt;Preferences&amp;gt;Java&amp;gt;Code Generation&amp;gt;Code and Comments
    */
    </em></code></font></span><code><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">package </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">com</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">sily</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">jndi</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">import </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">java</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">io</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">FileInputStream</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">import </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">java</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">util</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">Properties</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">import </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">javax</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">naming</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">Context</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">import </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">javax</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">naming</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">InitialContext</font></span><span style="color: rgb(0, 0, 255); font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><span style="color: rgb(58, 110, 165)"><font face="Courier New" size="2" color="rgb(58, 110, 165)">/**
    * @author shizy
    *
    * To change the template for this generated type comment go to
    * Window&amp;gt;Preferences&amp;gt;Java&amp;gt;Code Generation&amp;gt;Code and Comments
    */
    </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">public class </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">TestJbossJNDI </font></span><span style="color: rgb(0, 0, 255); font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">{
    </font></strong></span><span style="color: rgb(58, 110, 165)"><font face="Courier New" size="2" color="rgb(58, 110, 165)">/**
    *
    */
    </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">public </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">TestJbossJNDI</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">() {
    </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">super</font></span><span style="color: rgb(0, 0, 255); font-size: small"><font face="Courier New" size="2" color="rgb(0, 0, 255)">();
    </font></span></strong><span style="color: rgb(0, 128, 0); font-size: small"><font face="Courier New" size="2" color="rgb(0, 128, 0)"><em>// TODO Auto-generated constructor stub
    </em></font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">}
    </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">public static void </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">main</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">String</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">[] </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">args</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">) { </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">try </font></span><span style="color: rgb(0, 0, 255)"><font face="Courier New" size="2" color="rgb(0, 0, 255)">{
    </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">Properties env </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">= </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">new </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">Properties</font></span><span style="color: rgb(0, 0, 255); font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">();
    </font></strong></span><span style="color: rgb(0, 128, 0)"><font face="Courier New" size="2" color="rgb(0, 128, 0)"><em>//&#36733;&#20837;jboss&#30340;SPI&#30456;&#20851;&#21442;&#25968;,&#21253;&#25324;&#21021;&#22987;&#19978;&#19979;&#25991;&#24037;&#21378;&#65292;&#26381;&#21153;URL&#65292;&#31561;&#31561;
    </em></font></span><span style="font-size: small"><font face="Courier New" size="2">env</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">load</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">new </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">FileInputStream</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;jbossJndi.properties&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">));
    </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">env</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">list</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">System</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">out</font></span><span style="color: rgb(0, 0, 255); font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="color: rgb(0, 128, 0)"><font face="Courier New" size="2" color="rgb(0, 128, 0)"><em>//&#36890;&#36807;JNDI api &#21021;&#22987;&#21270;&#19978;&#19979;&#25991;
    </em></font></span><span style="font-size: small"><font face="Courier New" size="2">InitialContext ctx </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">= </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">new </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">javax</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">naming</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">InitialContext</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">env</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">System</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">out</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">println</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;Got context&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="color: rgb(0, 128, 0)"><font face="Courier New" size="2" color="rgb(0, 128, 0)"><em>//create a subContext
    </em></font></span><span style="font-size: small"><font face="Courier New" size="2">ctx</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">createSubcontext</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;/sylilzy&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">ctx</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">createSubcontext</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;sylilzy/sily&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="color: rgb(0, 128, 0)"><font face="Courier New" size="2" color="rgb(0, 128, 0)"><em>//rebind a object
    </em></font></span><span style="font-size: small"><font face="Courier New" size="2">ctx</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">rebind</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;sylilzy/sily/a&quot;<strong>, </strong>&quot;I am sily a!&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">ctx</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">rebind</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;sylilzy/sily/b&quot;<strong>, </strong>&quot;I am sily b!&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="color: rgb(0, 128, 0)"><font face="Courier New" size="2" color="rgb(0, 128, 0)"><em>//lookup context
    </em></font></span><span style="font-size: small"><font face="Courier New" size="2">Context ctx1</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">=(</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">Context</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">)</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">ctx</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">lookup</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;sylilzy&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">Context ctx2</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">=(</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">Context</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">)</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">ctx1</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">lookup</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;/sylilzy/sily&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">ctx2</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">bind</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;/sylilzy/g&quot;<strong>, </strong>&quot;this is g&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="color: rgb(0, 128, 0)"><font face="Courier New" size="2" color="rgb(0, 128, 0)"><em>//lookup binded object
    </em></font></span><span style="font-size: small"><font face="Courier New" size="2">Object o</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">o</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">=</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">ctx1</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">lookup</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;sily/a&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">System</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">out</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">println</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;get object from jndi:&quot;<strong>+</strong></font></span><span style="font-size: small"><font face="Courier New" size="2">o</font></span><span style="color: rgb(0, 0, 255); font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="color: rgb(0, 128, 0)"><font face="Courier New" size="2" color="rgb(0, 128, 0)"><em>//rename the object
    </em></font></span><span style="font-size: small"><font face="Courier New" size="2">ctx2</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">rename</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;/sylilzy/g&quot;<strong>, </strong>&quot;g1&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">o</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">=</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">ctx2</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">lookup</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;g1&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">System</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">out</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">println</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;get object from jndi:&quot;<strong>+</strong></font></span><span style="font-size: small"><font face="Courier New" size="2">o</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">);
    } </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">catch </font></span><span style="color: rgb(0, 0, 255)"><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></span></strong><span style="font-size: small"><font face="Courier New" size="2">Exception e</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">) {
    </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">e</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">printStackTrace</font></span><span style="color: rgb(0, 0, 255); font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">();
    }
    }
    }</font></strong></span></code><span style="font-size: small"><font size="2">&#32467;&#26524;&#36755;&#20986;&#22914;&#19979;:</font></span></pre>
      </div>
      <div>
        <span style="font-size: small"><font size="2">-- listing properties --<br />java.naming.factory.initial=org.jnp.interfaces.NamingContextFactory<br />java.naming.provider.url=jnp://localhost:1099<br />java.naming.factory.url.pkgs=org.jboss.naming:org.jnp.interfaces<br />Got context<br />get object from jndi:I am sily a!<br />get object from jndi:this is g</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#160;</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#31243;&#24207;&#20013;</font></span><span style="color: rgb(0, 0, 255); font-family: Courier New"><font face="Courier New" size="2" color="rgb(0, 0, 255)">jbossJndi.properties&#25991;&#20214;&#30340;&#20869;&#23481;&#20026;:</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">java.naming.factory.initial=org.jnp.interfaces.NamingContextFactory<br />java.naming.factory.url.pkgs=org.jboss.naming:org.jnp.interfaces<br />java.naming.provider.url=jnp://localhost:1099</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#160;</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#27880;&#24847;:&#35201;&#27491;&#30830;&#36816;&#34892;&#31034;&#20363;&#31243;&#24207;,&#35831;&#21551;&#21160;jboss,&#24182;&#23558;jboss&#30340;jbossall-client.jar&#25991;&#20214;&#25918;&#20837;classpath&#20013;&#12290;</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#160;</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#19978;&#36848;&#31034;&#20363;&#31243;&#24207;&#22312;jboss&#26381;&#21153;&#22120;&#30340;jndi&#26641;&#19978;&#24314;&#31435;&#20102;&#20960;&#20010;&#19978;&#19979;&#25991;,&#24182;bind&#20102;&#20960;&#23545;&#35937;,&#22823;&#23478;&#21487;&#36890;&#36807;&#38468;&#24405;&#20013;&#30340;&#20195;&#30721;&#25110;&#20854;&#23427;&#24037;&#20855;&#26597;&#30475;</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#26597;&#30475;&#32467;&#26524;&#20026;&#65306;</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">-----------------------------<br />/sylilzy/sily<br />-----------------------------<br />/sylilzy/sily/b:I am sily b!<br />/sylilzy/sily/a:I am sily a!<br />/sylilzy/sily/g1:this is g<br />-----------------------------<br />-----------------------------</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#160;</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#19978;&#36848;&#31243;&#24207;&#20013;&#65292;&#25105;&#20204;&#30340;&#20195;&#30721;&#21482;&#28041;&#21450;&#21040;&#20102;jndi API&#65292;&#20854;&#23427;&#32454;&#33410;&#22914;&#21021;&#22987;&#21270;jboss jndi&#30340;&#21021;&#22987;&#19978;&#19979;&#25991;&#65292;&#24314;&#31435;&#32593;&#32476;&#36830;&#25509;&#65292;&#19982;&#26381;&#21153;&#22120;&#36890;&#20449;&#65292;&#23545;&#25105;&#20204;&#26469;&#35828;&#37117;&#26159;&#36879;&#26126;&#30340;&#65292;&#21478;&#22806;&#65292;&#25105;&#20204;&#23558;jboss jndi&#30340;spi&#21253;&#20013;&#30340;&#31867;&#21517;&#20316;&#20026;&#21442;&#25968;&#20256;&#20837;&#20102;&#31243;&#24207;&#20013;,&#35201;&#35775;&#38382;&#19968;&#20010;&#36828;&#31243;&#23545;&#35937;&#65292;&#25105;&#20204;&#25152;&#20570;&#30340;&#23601;&#36825;&#20040;&#22810;&#12290;</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#160;</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#19979;&#38754;&#65292;&#20877;&#25552;&#20379;&#19968;&#20010;&#20363;&#23376;&#65292;&#19982;&#19978;&#20363;&#19981;&#21516;&#65292;&#25105;&#20204;&#19981;&#38656;&#35201; jboss,&#25105;&#20204;&#20351;&#29992;sun&#30340;FSSP(File System Service Provider)&#25991;&#20214;&#31995;&#32479;&#26381;&#21153;&#25552;&#20379;&#32773;.&#27880;&#24847;&#22312;&#36825;&#20010;&#20363;&#23376;&#20013;&#35201;&#20351;&#29992;&#21040;&#21069;&#38754;&#25152;&#35828;&#30340;File System Service Provider for the Java Naming and Directory Interface<sup>TM</sup></font></span><font size="2"><span class="Apple-converted-space">&#160;</span></font><span style="font-size: small"><font size="small">(JNDI)&#30456;&#20851;&#31867;&#65288;</font></span><span style="font-size: small"><a style="text-decoration: none; color: rgb(29, 88, 209)" target="_blank" href="http://java.sun.com/products/jndi/downloads/index.html"><font size="2" color="#108ac6">&#19979;&#36733;</font></a></span><span><font size="2">&#65289;&#12290;</font></span>
      </div>
      <pre style="margin-bottom: 0px; margin-top: 0px; font-size: 1em; white-space: pre-wrap; margin-left: 22px; margin-right: 0px"><span style="color: rgb(0, 128, 0)"><font face="Courier new" size="2" color="rgb(0, 128, 0)"><code><em>/*
    * Created on 2005-3-1
    *
    * To change the template for this generated file go to
    * Window&amp;gt;Preferences&amp;gt;Java&amp;gt;Code Generation&amp;gt;Code and Comments
    */
    </em></code></font></span><code><span style="color: rgb(255, 0, 0)"><strong><font face="Courier new" size="2" color="rgb(255, 0, 0)">package </font></strong></span><span style="font-size: small"><font face="Courier new" size="2">com</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">sily</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">jndi</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier new" size="2" color="rgb(255, 0, 0)">import </font></span></strong><span style="font-size: small"><font face="Courier new" size="2">java</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">io</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">FileInputStream</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier new" size="2" color="rgb(255, 0, 0)">import </font></span></strong><span style="font-size: small"><font face="Courier new" size="2">java</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">util</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">Properties</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier new" size="2" color="rgb(255, 0, 0)">import </font></span></strong><span style="font-size: small"><font face="Courier new" size="2">javax</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">naming</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.*;
    </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier new" size="2" color="rgb(255, 0, 0)">import </font></span></strong><span style="font-size: small"><font face="Courier new" size="2">javax</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">naming</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">Context</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier new" size="2" color="rgb(255, 0, 0)">import </font></span></strong><span style="font-size: small"><font face="Courier new" size="2">javax</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">naming</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">InitialContext</font></span><span style="color: rgb(0, 0, 255); font-size: small"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><span style="color: rgb(58, 110, 165)"><font face="Courier new" size="2" color="rgb(58, 110, 165)">/**
    * @author shizy
    *
    * To change the template for this generated type comment go to
    * Window&amp;gt;Preferences&amp;gt;Java&amp;gt;Code Generation&amp;gt;Code and Comments
    */
    </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier new" size="2" color="rgb(255, 0, 0)">public class </font></strong></span><span style="font-size: small"><font face="Courier new" size="2">JndiTest1 </font></span><span style="color: rgb(0, 0, 255); font-size: small"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">{
    </font></strong></span><span style="color: rgb(58, 110, 165)"><font face="Courier new" size="2" color="rgb(58, 110, 165)">/**
    *
    */
    </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier new" size="2" color="rgb(255, 0, 0)">public </font></strong></span><span style="font-size: small"><font face="Courier new" size="2">JndiTest1</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">() {
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier new" size="2" color="rgb(255, 0, 0)">super</font></strong></span><strong><span style="color: rgb(0, 0, 255)"><font face="Courier new" size="2" color="rgb(0, 0, 255)">();
    </font></span></strong><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(0, 128, 0)"><font face="Courier new" size="2" color="rgb(0, 128, 0)"><em>// TODO Auto-generated constructor stub
    </em></font></span><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)"> </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">}
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)"> </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier new" size="2" color="rgb(255, 0, 0)">public static void </font></strong></span><span style="font-size: small"><font face="Courier new" size="2">main</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">(</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">String</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">[] </font></strong></span><span style="font-size: small"><font face="Courier new" size="2">args</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">) {
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier new" size="2" color="rgb(255, 0, 0)">try </font></strong></span><strong><span style="color: rgb(0, 0, 255)"><font face="Courier new" size="2" color="rgb(0, 0, 255)">{
    </font></span></strong><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)">   </font></span><span style="font-size: small"><font face="Courier new" size="2">Properties env </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">= </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier new" size="2" color="rgb(255, 0, 0)">new </font></span></strong><span style="font-size: small"><font face="Courier new" size="2">Properties</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">();
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)">   </font></span><span style="font-size: small"><font face="Courier new" size="2">env</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">load</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">(</font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier new" size="2" color="rgb(255, 0, 0)">new </font></span></strong><span style="font-size: small"><font face="Courier new" size="2">FileInputStream</font></span><span style="font-size: small"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">&quot;fileSystemService.properties&quot;</font></span><span style="font-size: small"><strong><font face="Courier new" size="small" color="rgb(0, 0, 255)">));
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)">   </font></span><span style="font-size: small"><font face="Courier new" size="2">env</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">put</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">(</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">Context</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">PROVIDER_URL</font></span><span style="font-size: small"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">, </font></strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">&quot;file:///c:/&quot;</font></span><span style="font-size: small"><strong><font face="Courier new" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)">   </font></span><span style="font-size: small"><font face="Courier new" size="2">Context ctx </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">= </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier new" size="2" color="rgb(255, 0, 0)">new </font></span></strong><span style="font-size: small"><font face="Courier new" size="2">InitialContext</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">(</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">env</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)">   </font></span><span style="font-size: small"><font face="Courier new" size="2">ctx</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">createSubcontext</font></span><span style="font-size: small"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">&quot;sylilzy&quot;</font></span><span style="font-size: small"><strong><font face="Courier new" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="font-size: small"><font face="Courier new" size="2" color="rgb(0, 0, 0)">    </font></span><span style="font-size: small"><font face="Courier new" size="2">NamingEnumeration list </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">= </font></strong></span><span style="font-size: small"><font face="Courier new" size="2">ctx</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">list</font></span><span style="font-size: small"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">&quot;/&quot;</font></span><span style="font-size: small"><strong><font face="Courier new" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)">   </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier new" size="2" color="rgb(255, 0, 0)">while </font></strong></span><strong><span style="color: rgb(0, 0, 255)"><font face="Courier new" size="2" color="rgb(0, 0, 255)">(</font></span></strong><span style="font-size: small"><font face="Courier new" size="2">list</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">hasMore</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">()) {
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)">    </font></span><span style="font-size: small"><font face="Courier new" size="2">NameClassPair nc </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">= (</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">NameClassPair</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">) </font></strong></span><span style="font-size: small"><font face="Courier new" size="2">list</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">next</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">();
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)">    </font></span><span style="font-size: small"><font face="Courier new" size="2">System</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">out</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">println</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">(</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">nc</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)">   </font></span><span style="color: rgb(0, 0, 255); font-size: small"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">}
    </font></strong></span><span style="font-size: small"><font face="Courier new" size="2" color="rgb(0, 0, 0)">    </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">}
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier new" size="2" color="rgb(255, 0, 0)">catch </font></strong></span><strong><span style="color: rgb(0, 0, 255)"><font face="Courier new" size="2" color="rgb(0, 0, 255)">(</font></span></strong><span style="font-size: small"><font face="Courier new" size="2">Exception e</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">) {
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)">   </font></span><span style="font-size: small"><font face="Courier new" size="2">e</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier new" size="2">printStackTrace</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">();
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">}
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier new" size="2" color="rgb(0, 0, 0)"> </font></span><span style="color: rgb(0, 0, 255); font-size: small"><strong><font face="Courier new" size="2" color="rgb(0, 0, 255)">}
    }</font></strong></span>
<span style="font-size: small"><font size="2">    </font></span></code></pre>
      <div>
        <span style="font-size: small"><font size="2">&#160;</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#19978;&#20363;&#20013;fileSystemService.properties&#25991;&#20214;&#30340;&#20869;&#23481;&#20026;&#65306;java.naming.factory.initial=com.sun.jndi.fscontext.RefFSContextFactory</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#160;</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#36825;&#20010;&#20363;&#23376;&#36739;&#31616;&#21333;&#65292;&#36816;&#34892;&#21518;&#65292;&#23427;&#20250;&#21015;&#20986;C:\&#19979;&#25152;&#26377;&#30340;&#25991;&#20214;&#21644;&#30446;&#24405;&#65292;&#21478;&#22806;&#20320;&#20250;&#21457;&#29616;&#26377;&#19968;&#20010;&#26032;&#30446;&#24405;&#34987;&#21019;&#24314;&#20102;.&#26412;&#20363;&#19981;&#21516;&#20110;&#19978;&#20363;&#65292;&#23427;&#24182;&#19981;&#38656;&#35201;&#26381;&#21153;&#31471;&#65292;&#22240;&#20026;&#23427;&#35775;&#38382;&#30340;&#26159;&#25991;&#20214;&#31995;&#32479;.&#26377;&#20851;&#24110;&#21161;&#21487;&#26597;&#38405;&#21253;&#20869;&#30340;&#30456;&#20851;&#25991;&#26723;&#12290;</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#160;</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#36890;&#36807;&#23545;&#27604;&#36825;&#20004;&#20010;&#20363;&#23376;&#65292;&#24212;&#35813;JNDI&#30340;&#24037;&#20316;&#21407;&#29702;&#26377;&#20102;&#19968;&#20010;&#22823;&#33268;&#30340;&#20102;&#35299;&#12290;</font></span>
      </div>
      <pre style="margin-bottom: 0px; margin-top: 0px; font-size: 1em; white-space: pre-wrap; margin-left: 22px; margin-right: 0px"><span style="font-size: small"><strong><font size="2">&#24635;&#32467;&#65306;</font></strong></span></pre>
      <div>
        <span style="font-size: small"><font size="2">jndi&#25216;&#26415;&#20307;&#29616;&#20102;&#20998;&#24067;&#24335;&#24212;&#29992;&#30340;&#20248;&#28857;&#65292;&#21516;&#36827;&#23427;&#30340; &#20135;&#29983;&#20063;&#20026;&#20998;&#24067;&#24335;&#23545;&#35937;&#25552;&#20379;&#20102;&#32479;&#19968;&#30340;&#35775;&#38382;&#25509;&#21475;&#12290;&#30001;&#20110;&#31687;&#24133;&#25152;&#38480;&#65292;&#23545;&#30446;&#24405;&#30340;&#25805;&#20316;&#26412;&#25991;&#26410;&#20316;&#20171;&#32461;&#65292;&#20854;&#23427;&#20869;&#23481;&#23558;&#22312;&#25509;&#19979;&#26469;&#30340;&#31995;&#21015;&#20013;&#35752;&#35770;&#12290;&#35201;&#23545;JNDI&#25216;&#26415;&#20316;&#20840;&#38754;&#30340;&#20102;&#35299;&#65292;&#35831; &#21442;&#38405;&#21442;&#32771;&#36164;&#26009;.&#35201;&#23545;&#20110;JNDI&#25216;&#26415;&#28145;&#20837;&#23398;&#20064;&#65292;&#20173;&#26377;&#35768;&#22810;&#22320;&#26041;&#20540;&#24471;&#36827;&#19968;&#27493;&#20102;&#35299;&#65292;&#20363;&#22914;EJB&#23481;&#22120;&#25152;&#20351;&#29992;&#30340;JNDI&#25152;&#25552;&#20379;&#30340;&#23545;&#35937;&#23601;&#26377; Local&#21644;Remote&#20043;&#20998;&#65292;&#23545;&#20110;Local Object,&#23545;&#20110;&#19981;&#21516;&#30340;JVM&#26159;&#19981;&#21487;&#35775;&#38382;&#30340;&#65307;&#23545;&#20110;&#36828;&#31243;&#23545;&#35937;&#30340;&#35775;&#38382;&#65292;&#36824;&#28041;&#21450;&#21040;Java&#23433;&#20840;&#26426;&#21046;&#12290;</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#160;</font></span>
      </div>
      <div>
        <span style="font-size: small"><strong><font size="2">&#38468;&#24405;:</font></strong></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">&#26597;&#30475;jboss jndi&#20869;&#23481;&#30340;&#20195;&#30721;:</font></span>
      </div>
      <div>
        <span style="font-size: small"><font size="2">//----------------------------------------</font></span>
      </div>
      <div>
        <pre style="margin-bottom: 0px; margin-top: 0px; font-size: 1em; white-space: pre-wrap; margin-left: 22px; margin-right: 0px"><span style="color: rgb(0, 128, 0)"><font face="Courier New" size="2" color="rgb(0, 128, 0)"><code><em>/*
    * Created on 2005-3-4
    *
    * To change the template for this generated file go to
    * Window&amp;gt;Preferences&amp;gt;Java&amp;gt;Code Generation&amp;gt;Code and Comments
    */
    </em></code></font></span><code><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">package </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">com</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">sily</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">jndi</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">import </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">java</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">io</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">FileInputStream</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">import </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">java</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">util</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">Properties</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">import </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">javax</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">naming</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.*;
    </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">import </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">javax</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">naming</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">Context</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">import </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">javax</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">naming</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">InitialContext</font></span><span style="color: rgb(0, 0, 255); font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><span style="color: rgb(58, 110, 165)"><font face="Courier New" size="2" color="rgb(58, 110, 165)">/**
    * @author shizy
    *
    * To change the template for this generated type comment go to
    * Window&amp;gt;Preferences&amp;gt;Java&amp;gt;Code Generation&amp;gt;Code and Comments
    */
    </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">public class </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">ListJbossJndi </font></span><span style="color: rgb(0, 0, 255); font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">{
    </font></strong></span><span style="color: rgb(58, 110, 165)"><font face="Courier New" size="2" color="rgb(58, 110, 165)">/**
    *
    */
    </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">public </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">ListJbossJndi</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">() {
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">super</font></strong></span><strong><span style="color: rgb(0, 0, 255)"><font face="Courier New" size="2" color="rgb(0, 0, 255)">();
    </font></span></strong><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(0, 128, 0)"><font face="Courier New" size="2" color="rgb(0, 128, 0)"><em>// TODO Auto-generated constructor stub
    </em></font></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)"> </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">}
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)"> </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">public static void </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">main</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">String</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">[] </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">args</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">) {
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">try </font></strong></span><strong><span style="color: rgb(0, 0, 255)"><font face="Courier New" size="2" color="rgb(0, 0, 255)">{
    </font></span></strong><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">   </font></span><span style="font-size: small"><font face="Courier New" size="2">Properties env </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">= </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">new </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">Properties</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">();
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">   </font></span><span style="font-size: small"><font face="Courier New" size="2">env</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">load</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">new </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">FileInputStream</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;jbossJndi.properties&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">));
    </font></strong></span><span style="color: rgb(0, 0, 0); font-size: small"><font face="Courier New" size="2" color="rgb(0, 0, 0)">   </font></span><span style="color: rgb(0, 128, 0)"><font face="Courier New" size="2" color="rgb(0, 128, 0)"><em>//env.list(System.out);
    </em></font></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">   </font></span><span style="font-size: small"><font face="Courier New" size="2">Context ctx </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">= </font></strong></span><strong><span style="color: rgb(255, 0, 0)"><font face="Courier New" size="2" color="rgb(255, 0, 0)">new </font></span></strong><span style="font-size: small"><font face="Courier New" size="2">InitialContext</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">env</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">   </font></span><span style="font-size: small"><font face="Courier New" size="2">listCtx</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">ctx</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">lookup</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;sylilzy&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">));
    </font></strong></span><span style="color: rgb(0, 0, 0); font-size: small"><font face="Courier New" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">}
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">catch </font></strong></span><strong><span style="color: rgb(0, 0, 255)"><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></span></strong><span style="font-size: small"><font face="Courier New" size="2">Exception e</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">) {
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">   </font></span><span style="font-size: small"><font face="Courier New" size="2">e</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">printStackTrace</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">();
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">}
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)"> </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">}
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)"> </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">static void </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">listCtx</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">Object o</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">){
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">if</font></strong></span><strong><span style="color: rgb(0, 0, 255)"><font face="Courier New" size="2" color="rgb(0, 0, 255)">(!(</font></span></strong><span style="font-size: small"><font face="Courier New" size="2">o </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">instanceof </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">Context</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">))</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">log</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;:&quot;<strong>+</strong></font></span><span style="font-size: small"><font face="Courier New" size="2">o</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">else </font></strong></span><strong><span style="color: rgb(0, 0, 255)"><font face="Courier New" size="2" color="rgb(0, 0, 255)">{
    </font></span></strong><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">   </font></span><span style="font-size: small"><font face="Courier New" size="2">log</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;\n-----------------------------&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">try </font></strong></span><strong><span style="color: rgb(0, 0, 255)"><font face="Courier New" size="2" color="rgb(0, 0, 255)">{
    </font></span></strong><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">   </font></span><span style="font-size: small"><font face="Courier New" size="2">Context ctx</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">=(</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">Context</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">)</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">o</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">;
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">   </font></span><span style="color: rgb(0, 128, 0)"><font face="Courier New" size="2" color="rgb(0, 128, 0)"><em>//log(ctx.getNameInNamespace()+&quot;/:&quot;);
    </em></font></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">   </font></span><span style="font-size: small"><font face="Courier New" size="2">NamingEnumeration list</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">=</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">ctx</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">listBindings</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">   </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">while</font></strong></span><strong><span style="color: rgb(0, 0, 255)"><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></span></strong><span style="font-size: small"><font face="Courier New" size="2">list</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">hasMore</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">()){
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">    </font></span><span style="font-size: small"><font face="Courier New" size="2">Binding bind</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">=(</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">Binding</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">)</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">list</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">next</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">();
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">    </font></span><span style="font-size: small"><font face="Courier New" size="2">log</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;\n/&quot;<strong>+</strong></font></span><span style="font-size: small"><font face="Courier New" size="2">ctx</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">getNameInNamespace</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">()+</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;/&quot;<strong>+</strong></font></span><span style="font-size: small"><font face="Courier New" size="2">bind</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">getName</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">());
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">    </font></span><span style="font-size: small"><font face="Courier New" size="2">listCtx</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">bind</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">getObject</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">());
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">   </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">}
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">   </font></span><span style="font-size: small"><font face="Courier New" size="2">log</font></span><span style="font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">&quot;\n-----------------------------&quot;</font></span><span style="font-size: small"><strong><font face="Courier New" size="small" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="color: rgb(0, 0, 0); font-size: small"><font face="Courier New" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">}
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">catch </font></strong></span><strong><span style="color: rgb(0, 0, 255)"><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></span></strong><span style="font-size: small"><font face="Courier New" size="2">NamingException e</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">) {
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">   </font></span><span style="color: rgb(0, 128, 0)"><font face="Courier New" size="2" color="rgb(0, 128, 0)"><em>// TODO Auto-generated catch block
    </em></font></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">   </font></span><span style="font-size: small"><font face="Courier New" size="2">e</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">printStackTrace</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">();
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">  </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">}
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)"> </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">}
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)"> </font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">}
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)"> </font></span><span style="color: rgb(255, 0, 0)"><strong><font face="Courier New" size="2" color="rgb(255, 0, 0)">static void </font></strong></span><span style="font-size: small"><font face="Courier New" size="2">log</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">Object o</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">){
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)">  </font></span><span style="font-size: small"><font face="Courier New" size="2">System</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">out</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">.</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">print</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">(</font></strong></span><span style="font-size: small"><font face="Courier New" size="2">o</font></span><span style="color: rgb(0, 0, 255)"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">);
    </font></strong></span><span style="color: rgb(0, 0, 0)"><font face="Courier New" size="2" color="rgb(0, 0, 0)"> </font></span><span style="color: rgb(0, 0, 255); font-size: small"><strong><font face="Courier New" size="2" color="rgb(0, 0, 255)">}
    }</font></strong></span></code></pre>
      </div>
    </div>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1491231592193" ID="ID_1871205044" MODIFIED="1491231656843">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="3">&#20316;&#29992;&#65306; </font>
    </p>
    <p>
      <font size="3">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font face="PingFang SC, Lantinghei SC, Microsoft YaHei, arial, &#x5b8b;&#x4f53;, sans-serif, tahoma" size="3" color="rgb(51, 51, 51)">1&#12289;&#21487;&#20197;&#19981;&#29992;&#26292;&#38706;&#25968;&#25454;&#24211;&#29992;&#25143;&#21517;&#12289;&#23494;&#30721;&#22312;&#20195;&#30721;&#37197;&#32622;&#20013;&#65288;&#23588;&#20854;&#23433;&#20840;&#24615;&#35201;&#27714;&#39640;&#30340;&#39033;&#30446;&#65289;<br align="start" style="width: 700px; margin-top: 15px; background-color: rgb(255, 255, 255); word-spacing: 0px; height: 0px; display: block; letter-spacing: normal; margin-right: 0px; text-indent: 0px; margin-bottom: 15px; text-transform: none; white-space: normal; margin-left: 0px" size="3" />&#160; &#160;&#160;&#160;&#160;&#160;2&#12289;&#26377;&#36328;&#24211;&#20107;&#21153;&#26102;&#20195;&#30721;&#22788;&#29702;&#26356;&#31616;&#21333;&#65288;&#29992;&#30340;&#26159;resin&#23481;&#22120;&#65289;<br align="start" style="width: 700px; margin-top: 15px; background-color: rgb(255, 255, 255); word-spacing: 0px; height: 0px; display: block; letter-spacing: normal; margin-right: 0px; text-indent: 0px; margin-bottom: 15px; text-transform: none; white-space: normal; margin-left: 0px" size="3" />&#160; &#160;&#160;&#160;&#160;&#160;3&#12289;&#25171;war&#21253;&#26102;&#19981;&#29992;&#21306;&#20998;&#27979;&#35797;&#29983;&#20135;&#37197;&#32622;&#65292;&#19981;&#29992;&#25285;&#24515;&#37197;&#32622;&#38169;&#25968;&#25454;&#24211; </font>
    </p>
    <p>
      <font face="PingFang SC, Lantinghei SC, Microsoft YaHei, arial, &#x5b8b;&#x4f53;, sans-serif, tahoma" size="3" color="rgb(51, 51, 51)">&#160;&#160;&#160;&#160;&#160;&#160;&#160;4&#12289;JNDI &#21482;&#26159;&#19968;&#31181;&#37197;&#32622;&#36164;&#28304;&#26041;&#24335;</font>
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1491233247906" ID="ID_98419269" MODIFIED="1491234530157">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      JNDI &#21482;&#26159;&#19968;&#31181;&#36164;&#28304;&#31649;&#29702;&#26041;&#24335;
    </p>
    <p>
      &#160;C3P0&#26159;&#25968;&#25454;&#28304;&#36830;&#25509;&#27744;&#30340;&#37197;&#32622;&#26041;&#24335;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491233241875" FOLDED="true" ID="ID_1625331112" MODIFIED="1491266536649" POSITION="right" TEXT="JDBC">
<node CREATED="1491234594981" ID="ID_929164924" MODIFIED="1491234606392" TEXT="&#xff08;Java Data Base Connectivity,java&#x6570;&#x636e;&#x5e93;&#x8fde;&#x63a5;&#xff09;&#x662f;&#x4e00;&#x79cd;&#x7528;&#x4e8e;&#x6267;&#x884c;SQL&#x8bed;&#x53e5;&#x7684;Java API&#xff0c;&#x53ef;&#x4ee5;&#x4e3a;&#x591a;&#x79cd;&#x5173;&#x7cfb;&#x6570;&#x636e;&#x5e93;&#x63d0;&#x4f9b;&#x7edf;&#x4e00;&#x8bbf;&#x95ee;&#xff0c;&#x5b83;&#x7531;&#x4e00;&#x7ec4;&#x7528;Java&#x8bed;&#x8a00;&#x7f16;&#x5199;&#x7684;&#x7c7b;&#x548c;&#x63a5;&#x53e3;&#x7ec4;&#x6210;&#x3002;JDBC&#x63d0;&#x4f9b;&#x4e86;&#x4e00;&#x79cd;&#x57fa;&#x51c6;&#xff0c;&#x636e;&#x6b64;&#x53ef;&#x4ee5;&#x6784;&#x5efa;&#x66f4;&#x9ad8;&#x7ea7;&#x7684;&#x5de5;&#x5177;&#x548c;&#x63a5;&#x53e3;&#xff0c;&#x4f7f;&#x6570;&#x636e;&#x5e93;&#x5f00;&#x53d1;&#x4eba;&#x5458;&#x80fd;&#x591f;&#x7f16;&#x5199;&#x6570;&#x636e;&#x5e93;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#xff0c;&#x540c;&#x65f6;&#xff0c;JDBC&#x4e5f;&#x662f;&#x4e2a;&#x5546;&#x6807;&#x540d;&#x3002;"/>
<node CREATED="1491234620800" FOLDED="true" ID="ID_74026500" MODIFIED="1491234683622" TEXT="&#x7528;&#x9014;&#xff1a;&#x7b80;&#x5355;&#x5730;&#x8bf4;&#xff0c;JDBC &#x53ef;&#x505a;&#x4e09;&#x4ef6;&#x4e8b;&#xff1a;&#x4e0e;&#x6570;&#x636e;&#x5e93;&#x5efa;&#x7acb;&#x8fde;&#x63a5;&#x3001;&#x53d1;&#x9001; &#x64cd;&#x4f5c;&#x6570;&#x636e;&#x5e93;&#x7684;&#x8bed;&#x53e5;&#x5e76;&#x5904;&#x7406;&#x7ed3;&#x679c;&#x3002;">
<node CREATED="1491234637175" ID="ID_1442010374" MODIFIED="1491234673852">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div class="para" style="font-style: normal; background-color: rgb(255, 255, 255); word-spacing: 0px; letter-spacing: normal; color: rgb(51, 51, 51); font-family: arial, &#x5b8b;&#x4f53;, sans-serif; text-align: start; line-height: 24px; text-indent: 0; margin-bottom: 15px; font-size: 14px; text-transform: none; white-space: normal; font-weight: normal" label-module="para">
      <font face="&#x5b8b;&#x4f53;" size="3">&#19979;&#21015;&#20195;&#30721;&#27573;&#32473;&#20986;&#20102;&#20197;&#19978;&#19977;&#27493;&#30340;&#22522;&#26412;&#31034;&#20363;&#65306; </font>
    </div>
    <div class="para" style="font-style: normal; background-color: rgb(255, 255, 255); word-spacing: 0px; letter-spacing: normal; color: rgb(51, 51, 51); font-family: arial, &#x5b8b;&#x4f53;, sans-serif; text-align: start; line-height: 24px; text-indent: 0; margin-bottom: 15px; font-size: 14px; text-transform: none; white-space: normal; font-weight: normal" label-module="para">
      <font face="&#x5b8b;&#x4f53;" size="3">Connection con = DriverManager.getConnection(&quot;jdbc:odbc:wombat&quot;,&quot;login&quot;, </font>
    </div>
    <div class="para" style="font-style: normal; background-color: rgb(255, 255, 255); word-spacing: 0px; letter-spacing: normal; color: rgb(51, 51, 51); font-family: arial, &#x5b8b;&#x4f53;, sans-serif; text-align: start; line-height: 24px; text-indent: 0; margin-bottom: 15px; font-size: 14px; text-transform: none; white-space: normal; font-weight: normal" label-module="para">
      <font face="&#x5b8b;&#x4f53;" size="3">&quot;password&quot;); </font>
    </div>
    <div class="para" style="font-style: normal; background-color: rgb(255, 255, 255); word-spacing: 0px; letter-spacing: normal; color: rgb(51, 51, 51); font-family: arial, &#x5b8b;&#x4f53;, sans-serif; text-align: start; line-height: 24px; text-indent: 0; margin-bottom: 15px; font-size: 14px; text-transform: none; white-space: normal; font-weight: normal" label-module="para">
      <font face="&#x5b8b;&#x4f53;" size="3">Statement stmt = con.createStatement(); </font>
    </div>
    <div class="para" style="font-style: normal; background-color: rgb(255, 255, 255); word-spacing: 0px; letter-spacing: normal; color: rgb(51, 51, 51); font-family: arial, &#x5b8b;&#x4f53;, sans-serif; text-align: start; line-height: 24px; text-indent: 0; margin-bottom: 15px; font-size: 14px; text-transform: none; white-space: normal; font-weight: normal" label-module="para">
      <font face="&#x5b8b;&#x4f53;" size="3">ResultSet rs = stmt.executeQuery(&quot;SELECT a, b, c FROM Table1&quot;); </font>
    </div>
    <div class="para" style="font-style: normal; background-color: rgb(255, 255, 255); word-spacing: 0px; letter-spacing: normal; color: rgb(51, 51, 51); font-family: arial, &#x5b8b;&#x4f53;, sans-serif; text-align: start; line-height: 24px; text-indent: 0; margin-bottom: 15px; font-size: 14px; text-transform: none; white-space: normal; font-weight: normal" label-module="para">
      <font face="&#x5b8b;&#x4f53;" size="3">while (rs.next()) { </font>
    </div>
    <div class="para" style="font-style: normal; background-color: rgb(255, 255, 255); word-spacing: 0px; letter-spacing: normal; color: rgb(51, 51, 51); font-family: arial, &#x5b8b;&#x4f53;, sans-serif; text-align: start; line-height: 24px; text-indent: 0; margin-bottom: 15px; font-size: 14px; text-transform: none; white-space: normal; font-weight: normal" label-module="para">
      <font face="&#x5b8b;&#x4f53;" size="3">int x = rs.getInt(&quot;a&quot;); </font>
    </div>
    <div class="para" style="font-style: normal; background-color: rgb(255, 255, 255); word-spacing: 0px; letter-spacing: normal; color: rgb(51, 51, 51); font-family: arial, &#x5b8b;&#x4f53;, sans-serif; text-align: start; line-height: 24px; text-indent: 0; margin-bottom: 15px; font-size: 14px; text-transform: none; white-space: normal; font-weight: normal" label-module="para">
      <font face="&#x5b8b;&#x4f53;" size="3">String s = rs.getString(&quot;b&quot;); </font>
    </div>
    <div class="para" style="font-style: normal; background-color: rgb(255, 255, 255); word-spacing: 0px; letter-spacing: normal; color: rgb(51, 51, 51); font-family: arial, &#x5b8b;&#x4f53;, sans-serif; text-align: start; line-height: 24px; text-indent: 0; margin-bottom: 15px; font-size: 14px; text-transform: none; white-space: normal; font-weight: normal" label-module="para">
      <font face="&#x5b8b;&#x4f53;" size="3">float f = rs.getFloat(&quot;c&quot;); </font>
    </div>
    <div class="para" style="font-style: normal; background-color: rgb(255, 255, 255); word-spacing: 0px; letter-spacing: normal; color: rgb(51, 51, 51); font-family: arial, &#x5b8b;&#x4f53;, sans-serif; text-align: start; line-height: 24px; text-indent: 0; margin-bottom: 15px; font-size: 14px; text-transform: none; white-space: normal; font-weight: normal" label-module="para">
      <font face="&#x5b8b;&#x4f53;" size="3">} </font>
    </div>
    <div class="para" style="font-style: normal; background-color: rgb(255, 255, 255); word-spacing: 0px; letter-spacing: normal; color: rgb(51, 51, 51); font-family: arial, &#x5b8b;&#x4f53;, sans-serif; text-align: start; line-height: 24px; text-indent: 0; margin-bottom: 15px; font-size: 14px; text-transform: none; white-space: normal; font-weight: normal" label-module="para">
      <font face="&#x5b8b;&#x4f53;" size="3">&#19978;&#36848;&#20195;&#30721;&#23545;&#22522;&#20110;JDBC&#30340;&#25968;&#25454;&#24211;&#35775;&#38382;&#20570;&#20102;&#32463;&#20856;&#30340;&#24635;&#32467;&#65292;&#24403;&#28982;&#65292;&#22312;&#26412;&#23567;&#33410;&#30340;&#21518;&#32493;&#37096;&#20998;&#20250;&#23545;&#23427;&#20570;&#35814;&#23613;&#30340;&#20998;&#26512;&#35762;&#35299;&#12290; </font>
    </div>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1491234774067" FOLDED="true" HGAP="103" ID="ID_1090727832" MODIFIED="1497020675434" POSITION="left" STYLE="fork" TEXT="JTA" VSHIFT="63">
<node CREATED="1491234779058" ID="ID_1076736745" MODIFIED="1491234788207" TEXT="JTA&#xff0c;&#x5373;Java Transaction API&#xff0c;JTA&#x5141;&#x8bb8;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x6267;&#x884c;&#x5206;&#x5e03;&#x5f0f;&#x4e8b;&#x52a1;&#x5904;&#x7406;&#x2014;&#x2014;&#x5728;&#x4e24;&#x4e2a;&#x6216;&#x591a;&#x4e2a;&#x7f51;&#x7edc;&#x8ba1;&#x7b97;&#x673a;&#x8d44;&#x6e90;&#x4e0a;&#x8bbf;&#x95ee;&#x5e76;&#x4e14;&#x66f4;&#x65b0;&#x6570;&#x636e;&#x3002;JDBC&#x9a71;&#x52a8;&#x7a0b;&#x5e8f;&#x7684;JTA&#x652f;&#x6301;&#x6781;&#x5927;&#x5730;&#x589e;&#x5f3a;&#x4e86;&#x6570;&#x636e;&#x8bbf;&#x95ee;&#x80fd;&#x529b;&#x3002;"/>
<node CREATED="1491234830949" ID="ID_1717434808" MODIFIED="1491234833303" TEXT="&#x6982;&#x8ff0;">
<node CREATED="1491234839246" FOLDED="true" ID="ID_147737669" MODIFIED="1491301959116" TEXT="JTA&#x548c;JTS">
<node CREATED="1491234930384" ID="ID_1653175786" MODIFIED="1491235018821">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div class="para" style="font-style: normal; background-color: rgb(255, 255, 255); word-spacing: 0px; letter-spacing: normal; color: rgb(51, 51, 51); font-family: arial, &#x5b8b;&#x4f53;, sans-serif; text-align: start; line-height: 24px; text-indent: 0; margin-bottom: 15px; font-size: 14px; text-transform: none; white-space: normal; font-weight: normal" label-module="para">
      <font size="3">Java</font><a style="text-decoration: none; color: rgb(19, 110, 194)" target="_blank" href="http://baike.baidu.com/item/%E4%BA%8B%E5%8A%A1"><font size="3" color="rgb(19, 110, 194)">&#20107;&#21153;</font></a><font size="3">API&#65288;JTA&#65306;Java Transaction API&#65289;&#21644;&#23427;&#30340;&#21516;&#32990;Java&#20107;&#21153;&#26381;&#21153;&#65288;JTS&#65306;Java Transaction Service&#65289;&#65292;&#20026;J2EE&#24179;&#21488;&#25552;&#20379;&#20102;</font><a style="text-decoration: none; color: rgb(19, 110, 194)" target="_blank" href="http://baike.baidu.com/item/%E5%88%86%E5%B8%83%E5%BC%8F%E4%BA%8B%E5%8A%A1"><font size="3" color="rgb(19, 110, 194)">&#20998;&#24067;&#24335;&#20107;&#21153;</font></a><font size="3">&#26381;&#21153;&#65288;distributed transaction&#65289;&#12290; &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#19968;&#20010;&#20998;&#24067;&#24335;&#20107;&#21153;&#65288;distributed transaction&#65289;&#21253;&#25324;&#19968;&#20010;&#20107;&#21153;&#31649;&#29702;&#22120;&#65288;transaction manager&#65289;&#21644;&#19968;&#20010;&#25110;&#22810;&#20010;</font><a style="text-decoration: none; color: rgb(19, 110, 194)" target="_blank" href="http://baike.baidu.com/item/%E8%B5%84%E6%BA%90%E7%AE%A1%E7%90%86%E5%99%A8"><font size="3" color="rgb(19, 110, 194)">&#36164;&#28304;&#31649;&#29702;&#22120;</font></a><font size="3">(resource manager&#65289;&#12290; &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#19968;&#20010;&#36164;&#28304;&#31649;&#29702;&#22120;&#65288;resource manager&#65289;&#26159;&#20219;&#24847;&#31867;&#22411;&#30340;&#25345;&#20037;&#21270;&#25968;&#25454;&#23384;&#20648;&#12290; &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#20107;&#21153;&#31649;&#29702;&#22120;&#65288;transaction manager&#65289;&#25215;&#25285;&#30528;&#25152;&#26377;&#20107;&#21153;&#21442;&#19982;&#21333;&#20803;&#32773;&#30340;&#30456;&#20114;&#36890;&#35759;&#30340;&#36131;&#20219;</font>
    </div>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#006699" CREATED="1491234950099" FOLDED="true" ID="ID_1355529364" MODIFIED="1491235244760" TEXT="JTA&#x4e0e;JDBC">
<font NAME="SansSerif" SIZE="10"/>
<node CREATED="1491234961648" ID="ID_1184652930" MODIFIED="1491234966127" TEXT="JTA&#x4e8b;&#x52a1;&#x6bd4;JDBC&#x4e8b;&#x52a1;&#x66f4;&#x5f3a;&#x5927;&#x3002;&#x4e00;&#x4e2a;JTA&#x4e8b;&#x52a1;&#x53ef;&#x4ee5;&#x6709;&#x591a;&#x4e2a;&#x53c2;&#x4e0e;&#x8005;&#xff0c;&#x800c;&#x4e00;&#x4e2a;JDBC&#x4e8b;&#x52a1;&#x5219;&#x88ab;&#x9650;&#x5b9a;&#x5728;&#x4e00;&#x4e2a;&#x5355;&#x4e00;&#x7684;&#x6570;&#x636e;&#x5e93;&#x8fde;&#x63a5;&#x3002;&#x4e0b;&#x5217;&#x4efb;&#x4e00;&#x4e2a;Java&#x5e73;&#x53f0;&#x7684;&#x7ec4;&#x4ef6;&#x90fd;&#x53ef;&#x4ee5;&#x53c2;&#x4e0e;&#x5230;&#x4e00;&#x4e2a;JTA&#x4e8b;&#x52a1;&#x4e2d;&#xff1a;JDBC&#x8fde;&#x63a5;&#x3001;JDO PersistenceManager &#x5bf9;&#x8c61;&#x3001;JMS &#x961f;&#x5217;&#x3001;JMS &#x4e3b;&#x9898;&#x3001;&#x4f01;&#x4e1a;JavaBeans&#xff08;EJB&#xff09;&#x3001;&#x4e00;&#x4e2a;&#x7528;J2EE Connector Architecture &#x89c4;&#x8303;&#x7f16;&#x8bd1;&#x7684;&#x8d44;&#x6e90;&#x5206;&#x914d;&#x5668;&#x3002;"/>
</node>
</node>
</node>
<node CREATED="1491266104820" ID="ID_1576615287" MODIFIED="1491537460620" POSITION="left" TEXT="&#x6846;&#x67b6;&#x7c7b;">
<arrowlink DESTINATION="ID_1576615287" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_428860889" STARTARROW="None" STARTINCLINATION="0;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_1576615287" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_428860889" SOURCE="ID_1576615287" STARTARROW="None" STARTINCLINATION="0;0;"/>
<node CREATED="1491266126915" FOLDED="true" ID="ID_518602576" MODIFIED="1497020676370" TEXT="Hibernate">
<node CREATED="1491266167469" FOLDED="true" ID="ID_1138445421" MODIFIED="1491305356300" TEXT="&#x914d;&#x7f6e;Hibernate&#x6b65;&#x9aa4;">
<node CREATED="1491266187124" ID="ID_982357567" MODIFIED="1491266196663" TEXT="1&#x3001;&#x7f3a;&#x7701;&#x540d;&#x79f0;&#x4e3a; hibernate.cfg.xml"/>
<node CREATED="1491266199449" ID="ID_1736193927" MODIFIED="1491266213088" TEXT="2&#x3001;&#x5b58;&#x653e;&#x5728;&#x5f53;&#x524d;classes&#x7684;&#x6839;&#x76ee;&#x5f55;&#x4e0b;&#xff0c;&#x5f00;&#x53d1;&#x7684;&#x65f6;&#x5019;&#x5728;src&#x6839;&#x4e0b;&#x5c31;&#x53ef;&#x4ee5;&#x4e86;"/>
<node CREATED="1491266368209" FOLDED="true" HGAP="45" ID="ID_4734759" MODIFIED="1491279453325" VSHIFT="-35">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      3&#65306;&#20027;&#35201;&#26377;&#22914;&#19979;&#22235;&#37096;&#20998;&#37197;&#32622; &#65306;
    </p>
    <p>
      &#65288;1&#65289;&#19982;DB&#30340;&#36830;&#25509;
    </p>
    <p>
      &#65288;2&#65289;&#21487;&#36873;&#37197;&#32622;
    </p>
    <p>
      &#65288;3&#65289;&#36164;&#28304;&#25991;&#20214;&#27880;&#20876;
    </p>
    <p>
      &#65288;4&#65289;&#20108;&#32423;&#32531;&#23384;
    </p>
    <p>
      4&#65306;&#37197;&#32622;&#30340;&#26102;&#20505;&#21487;&#20197;&#21040;Hibernate&#21457;&#34892;&#21253;&#37324;&#38754;&#25214;&#20010;hibernate.cfg.xml&#30340;&#20363;&#23376;&#65292;&#27604;&#22914;&#21487;&#20197;&#29992;
    </p>
    <p>
      &#8220;\project\hibernate-
    </p>
    <p>
      documentation\quickstart\tutorials\basic\src\test\resources&#8221;&#19979;&#38754;&#30340;
    </p>
    <p>
      hibernate.cfg.xml&#20316;&#20363;&#23376;
    </p>
  </body>
</html></richcontent>
<node CREATED="1491266397286" ID="ID_660768827" MODIFIED="1491266988671">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>ORACLE&#31034;&#20363;</b>&#65306;
    </p>
    <p>
      &lt;?xml version='1.0' encoding='utf-8'?&gt;
    </p>
    <p>
      &lt;!DOCTYPE hibernate-configuration PUBLIC
    </p>
    <p>
      &quot;-//Hibernate/Hibernate Configuration DTD 3.0//EN&quot;
    </p>
    <p>
      &quot;http://hibernate.sourceforge.net/hibernate-configuration-3.0.dtd&quot;&gt;
    </p>
    <p>
      &lt;hibernate-configuration&gt;
    </p>
    <p>
      &lt;session-factory&gt;
    </p>
    <p>
      &lt;property
    </p>
    <p>
      name=&quot;connection.driver_class&quot;&gt;oracle.jdbc.driver.OracleDriver&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;connection.url&quot;&gt;jdbc:oracle:thin:@localhost:1521:orcl&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;connection.username&quot;&gt;test&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;connection.password&quot;&gt;test&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;connection.pool_size&quot;&gt;2&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;dialect&quot;&gt;org.hibernate.dialect.OracleDialect&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;show_sql&quot;&gt;true&lt;/property&gt;
    </p>
    <p>
      &lt;mapping resource=&quot;cn/javass/h4/hello/UserModel.hbm.xml&quot;/&gt;
    </p>
    <p>
      &lt;!-- Student&#26159;&#37319;&#29992;&#30340;*.hmb.xml&#26041;&#24335;&#25554;&#20837;DB --&gt;
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&lt;mapping resource=&quot;com/southbook/www/hibernate/entity/student.hbm.xml&quot;/&gt;
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&lt;!-- Teacher&#26159;&#37319;&#29992;&#30340;&#27880;&#37322;&#26041;&#24335;&#25554;&#20837;DB&#30340;&#20851;&#38190;&#20043;&#22788; --&gt;
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&lt;mapping class=&quot;com.southbook.www.hibernate.entity.Teacher&quot;/&gt;
    </p>
    <p>
      &lt;/session-factory&gt;
    </p>
    <p>
      &lt;/hibernate-configuration&gt;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1491266747689" ID="ID_1333338157" MODIFIED="1491266996394">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Mysql&#37197;&#32622;&#65306;</b>
    </p>
    <p>
      &#160;&#160;&lt;property name=&quot;connection.driver_class&quot;&gt;com.mysql.jdbc.Driver&lt;/property&gt;
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&lt;property name=&quot;connection.url&quot;&gt;jdbc:mysql://localhost:3306/test&lt;/property&gt;
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&lt;property name=&quot;connection.username&quot;&gt;root&lt;/property&gt;
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&lt;property name=&quot;connection.password&quot;&gt;111111&lt;/property&gt;&#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&lt;!-- SQL dialect --&gt;
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&lt;property name=&quot;dialect&quot;&gt;org.hibernate.dialect.MySQLDialect&lt;/property&gt;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1491267015952" HGAP="14" ID="ID_883611519" MODIFIED="1491267166172" TEXT=" sqlserver&#x793a;&#x4f8b;&#xff1a;&#xa;&lt;!-- &#x8fde;&#x63a5;sqlserver2008&#x7684;&#x7c7b;&#x5e93;&#x6587;&#x4ef6; --&gt;&#xa;&lt;property name=&quot;connection.driver_class&quot;&gt;com.microsoft.sqlserver.jdbc.SQLServerDriver&lt;/property&gt; &#xa; &lt;property name=&quot;connection.url&quot;&gt;jdbc:sqlserver://localhost:1433;DatabaseName=hibernate&lt;/property&gt;&#xa;&lt;property name=&quot;dialect&quot;&gt;org.hibernate.dialect.SQLServerDialect&lt;/property&gt;" VSHIFT="-4">
<arrowlink DESTINATION="ID_883611519" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_516175758" STARTARROW="None" STARTINCLINATION="0;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_883611519" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_516175758" SOURCE="ID_883611519" STARTARROW="None" STARTINCLINATION="0;0;"/>
</node>
</node>
<node CREATED="1491267317805" HGAP="47" ID="ID_219210742" MODIFIED="1491273418919" TEXT="5&#x3001;&#x914d;&#x7f6e;&#x5b9e;&#x4f53;&#x7c7b;xxx.hbm.xml" VSHIFT="-64">
<node CREATED="1491273418919" FOLDED="true" ID="ID_747077061" MODIFIED="1491284969140" TEXT="1&#x3001;XML&#x914d;&#x7f6e;">
<node CREATED="1491267528186" HGAP="53" ID="ID_733329024" MODIFIED="1491273443902" VSHIFT="30">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &lt;?xml version=&quot;1.0&quot;?&gt;
    </p>
    <p>
      
    </p>
    <p>
      &lt;!DOCTYPE hibernate-mapping PUBLIC
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;-//Hibernate/Hibernate Mapping DTD 3.0//EN&quot;
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;http://hibernate.sourceforge.net/hibernate-mapping-3.0.dtd&quot;&gt;
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      &lt;hibernate-mapping package=&quot;com.southbook.www.hibernate.entity&quot;&gt;
    </p>
    <p>
      
    </p>
    <p>
      &lt;class name=&quot;Student&quot; table=&quot;tb_student&quot;&gt;
    </p>
    <p>
      
    </p>
    <p>
      &lt;id name=&quot;id&quot;&gt;
    </p>
    <p>
      &lt;!-- &#23383;&#27573;&#33258;&#22686; --&gt;
    </p>
    <p>
      &lt;generator class=&quot;native&quot; /&gt;
    </p>
    <p>
      &lt;/id&gt;
    </p>
    <p>
      
    </p>
    <p>
      &lt;property name=&quot;username&quot;&gt;&lt;/property&gt;
    </p>
    <p>
      
    </p>
    <p>
      &lt;!-- &lt;property name=&quot;age&quot;&gt;&lt;/property&gt; --&gt;
    </p>
    <p>
      
    </p>
    <p>
      &lt;/class&gt;
    </p>
    <p>
      
    </p>
    <p>
      &lt;/hibernate-mapping&gt;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491273467541" FOLDED="true" ID="ID_1424841923" MODIFIED="1491284971155" TEXT="2&#x3001;&#x6ce8;&#x89e3;">
<node CREATED="1491273489416" ID="ID_1477846728" MODIFIED="1491273497890">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      /*
    </p>
    <p>
      &#160;* Hibernate, Relational Persistence for Idiomatic Java
    </p>
    <p>
      &#160;*
    </p>
    <p>
      &#160;* Copyright (c) 2010, Red Hat Inc. or third-party contributors as
    </p>
    <p>
      &#160;* indicated by the @author tags or express copyright attribution
    </p>
    <p>
      &#160;* statements applied by the authors.&#160;&#160;All third-party contributions are
    </p>
    <p>
      &#160;* distributed under license by Red Hat Inc.
    </p>
    <p>
      &#160;*
    </p>
    <p>
      &#160;* This copyrighted material is made available to anyone wishing to use, modify,
    </p>
    <p>
      &#160;* copy, or redistribute it subject to the terms and conditions of the GNU
    </p>
    <p>
      &#160;* Lesser General Public License, as published by the Free Software Foundation.
    </p>
    <p>
      &#160;*
    </p>
    <p>
      &#160;* This program is distributed in the hope that it will be useful,
    </p>
    <p>
      &#160;* but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
    </p>
    <p>
      &#160;* or FITNESS FOR A PARTICULAR PURPOSE.&#160;&#160;See the GNU Lesser General Public License
    </p>
    <p>
      &#160;* for more details.
    </p>
    <p>
      &#160;*
    </p>
    <p>
      &#160;* You should have received a copy of the GNU Lesser General Public License
    </p>
    <p>
      &#160;* along with this distribution; if not, write to:
    </p>
    <p>
      &#160;* Free Software Foundation, Inc.
    </p>
    <p>
      &#160;* 51 Franklin Street, Fifth Floor
    </p>
    <p>
      &#160;* Boston, MA&#160;&#160;02110-1301&#160;&#160;USA
    </p>
    <p>
      &#160;*/
    </p>
    <p>
      package org.hibernate.tutorial.annotations;
    </p>
    <p>
      
    </p>
    <p>
      import java.util.Date;
    </p>
    <p>
      import javax.persistence.Column;
    </p>
    <p>
      import javax.persistence.Entity;
    </p>
    <p>
      import javax.persistence.GeneratedValue;
    </p>
    <p>
      import javax.persistence.Id;
    </p>
    <p>
      import javax.persistence.Table;
    </p>
    <p>
      import javax.persistence.Temporal;
    </p>
    <p>
      import javax.persistence.TemporalType;
    </p>
    <p>
      
    </p>
    <p>
      import org.hibernate.annotations.GenericGenerator;
    </p>
    <p>
      
    </p>
    <p>
      @Entity
    </p>
    <p>
      @Table( name = &quot;EVENTS&quot; )
    </p>
    <p>
      public class Event {
    </p>
    <p>
      &#160;&#160;&#160;&#160;private Long id;
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;private String title;
    </p>
    <p>
      &#160;&#160;&#160;&#160;private Date date;
    </p>
    <p>
      
    </p>
    <p>
      public Event() {
    </p>
    <p>
      // this form used by Hibernate
    </p>
    <p>
      }
    </p>
    <p>
      
    </p>
    <p>
      public Event(String title, Date date) {
    </p>
    <p>
      // for application use, to create new events
    </p>
    <p>
      this.title = title;
    </p>
    <p>
      this.date = date;
    </p>
    <p>
      }
    </p>
    <p>
      
    </p>
    <p>
      @Id
    </p>
    <p>
      @GeneratedValue(generator=&quot;increment&quot;)
    </p>
    <p>
      @GenericGenerator(name=&quot;increment&quot;, strategy = &quot;increment&quot;)
    </p>
    <p>
      &#160;&#160;&#160;&#160;public Long getId() {
    </p>
    <p>
      return id;
    </p>
    <p>
      &#160;&#160;&#160;&#160;}
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;private void setId(Long id) {
    </p>
    <p>
      this.id = id;
    </p>
    <p>
      &#160;&#160;&#160;&#160;}
    </p>
    <p>
      
    </p>
    <p>
      @Temporal(TemporalType.TIMESTAMP)
    </p>
    <p>
      @Column(name = &quot;EVENT_DATE&quot;)
    </p>
    <p>
      &#160;&#160;&#160;&#160;public Date getDate() {
    </p>
    <p>
      return date;
    </p>
    <p>
      &#160;&#160;&#160;&#160;}
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;public void setDate(Date date) {
    </p>
    <p>
      this.date = date;
    </p>
    <p>
      &#160;&#160;&#160;&#160;}
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;public String getTitle() {
    </p>
    <p>
      return title;
    </p>
    <p>
      &#160;&#160;&#160;&#160;}
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;public void setTitle(String title) {
    </p>
    <p>
      this.title = title;
    </p>
    <p>
      &#160;&#160;&#160;&#160;}
    </p>
    <p>
      }
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1491267347241" FOLDED="true" HGAP="50" ID="ID_1356736120" MODIFIED="1491284975324" TEXT="6&#x3001;&#x6d4b;&#x8bd5;" VSHIFT="-39">
<node CREATED="1491267416009" ID="ID_582456360" MODIFIED="1491267422062">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      package com.southbook.www.hibernate.test;
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      import org.hibernate.HibernateException;
    </p>
    <p>
      import org.hibernate.Query;
    </p>
    <p>
      import org.hibernate.Session;
    </p>
    <p>
      import org.hibernate.SessionFactory;
    </p>
    <p>
      import org.hibernate.Transaction;
    </p>
    <p>
      import org.hibernate.cfg.Configuration;
    </p>
    <p>
      
    </p>
    <p>
      import com.southbook.www.hibernate.entity.Student;
    </p>
    <p>
      import com.southbook.www.hibernate.entity.Teacher;
    </p>
    <p>
      
    </p>
    <p>
      public class TestHibernte {
    </p>
    <p>
      
    </p>
    <p>
      private static final SessionFactory sessionFactory;
    </p>
    <p>
      static {
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;try {
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;// Create the SessionFactory from hibernate.cfg.xml
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;sessionFactory = new Configuration().configure().buildSessionFactory();
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;} catch (Throwable ex) {
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;// Make sure you log the exception, as it might be swallowed
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;System.err.println(&quot;Initial SessionFactory creation failed.&quot; + ex);
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;throw new ExceptionInInitializerError(ex);
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;}
    </p>
    <p>
      &#160;&#160;&#160;&#160;}
    </p>
    <p>
      &#160;&#160;&#160;&#160;public static SessionFactory getSessionFactory() {
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;return sessionFactory;
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;}
    </p>
    <p>
      public static void main(String[] args) {
    </p>
    <p>
      
    </p>
    <p>
      // save();
    </p>
    <p>
      // delete();
    </p>
    <p>
      // otherDeleteBySql();
    </p>
    <p>
      
    </p>
    <p>
      update();
    </p>
    <p>
      
    </p>
    <p>
      // queryObject();
    </p>
    <p>
      }
    </p>
    <p>
      
    </p>
    <p>
      /**
    </p>
    <p>
      &#160;&#160;* @Title&#160;&#160;&#160;&#160;&#160;&#160;: queryObject
    </p>
    <p>
      * @Description: &#26597;&#35810; &#19968;&#20010;&#23545;&#35937;
    </p>
    <p>
      * @author&#160;&#160;&#160;&#160;&#160;:stbook
    </p>
    <p>
      * Create Date : 2017&#24180;3&#26376;19&#26085; &#19978;&#21320;9:30:14
    </p>
    <p>
      * @throws
    </p>
    <p>
      */
    </p>
    <p>
      private static void queryObject() {
    </p>
    <p>
      Session session=sessionFactory.openSession();
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;session.beginTransaction();
    </p>
    <p>
      // &#160;&#160;&#160;&#160;&#160;Query q = session.getNamedQuery(&quot;teacher_custom&quot;);
    </p>
    <p>
      &#160;&#160;&#160;&#160;
    </p>
    <p>
      // &#160;&#160;&#160;&#160;&#160;System.out.println(q.getQueryString());
    </p>
    <p>
      &#160;&#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;Query namedQuery = session.getNamedQuery(&quot;count_row&quot;);
    </p>
    <p>
      &#160;&#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;String name=&quot;%t%&quot;;
    </p>
    <p>
      namedQuery.setParameter(0, name);
    </p>
    <p>
      System.out.println(namedQuery.getQueryString());
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;Object uniqueResult = namedQuery.uniqueResult();
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;System.out.println(uniqueResult);
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;session.beginTransaction().commit();
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;session.close();
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;sessionFactory.close();
    </p>
    <p>
      
    </p>
    <p>
      }
    </p>
    <p>
      /**
    </p>
    <p>
      &#160;&#160;* @Title&#160;&#160;&#160;&#160;&#160;&#160;: update
    </p>
    </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1491279469804" FOLDED="true" ID="ID_1232983792" MODIFIED="1491285149979" TEXT="&#x65b9;&#x8a00;&#x914d;&#x7f6e;">
<node CREATED="1491279477608" ID="ID_391479475" MODIFIED="1491285005468">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="RichOle/&#x6570;&#x636e;&#x5e93;&#x914d;&#x7f6e;&#x65b9;&#x8a00;.png" />
  </body>
</html></richcontent>
<arrowlink DESTINATION="ID_391479475" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_779874293" STARTARROW="None" STARTINCLINATION="0;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_391479475" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_779874293" SOURCE="ID_391479475" STARTARROW="None" STARTINCLINATION="0;0;"/>
</node>
</node>
<node CREATED="1491285224413" FOLDED="true" ID="ID_1398098774" MODIFIED="1491305353076" TEXT="&#x6570;&#x636e;&#x5e93;&#x914d;&#x7f6e;">
<node CREATED="1491285231947" FOLDED="true" ID="ID_1186998394" MODIFIED="1491305351372" TEXT="1&#x3001;JDBC">
<node CREATED="1491285238676" ID="ID_1615891514" MODIFIED="1491285330774">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#31034;&#20363;&#65306;
    </p>
    <p>
      &lt;property
    </p>
    <p>
      name=&quot;connection.driver_class&quot;&gt;oracle.jdbc.driver.OracleDriver&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;connection.url&quot;&gt;jdbc:oracle:thin:@localhost:1521:orcl&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;connection.username&quot;&gt;javass&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;connection.password&quot;&gt;javass&lt;/property&gt;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1491285340443" ID="ID_1516906542" MODIFIED="1491285348560">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="RichOle/HibernateJDBC.png" />
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491285353226" FOLDED="true" ID="ID_661901850" MODIFIED="1491285437329" TEXT="2.DataSource">
<node CREATED="1491285371498" ID="ID_1223818020" MODIFIED="1491285433700">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#31034;&#20363;&#22914;&#19979;&#65306;
    </p>
    <p>
      &lt;property name=&quot;connection.datasource&quot;&gt;java:/javassDs&lt;/property&gt;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1491285389985" ID="ID_1038070475" MODIFIED="1491285398608">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="RichOle/HibernateDataSource.png" />
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491285456162" FOLDED="true" ID="ID_823150527" MODIFIED="1491285474202" TEXT=" &#x8fde;&#x63a5;&#x6c60;c3p0">
<node CREATED="1491285458625" ID="ID_1492295748" MODIFIED="1491285472992">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;&#36830;&#25509;&#27744;c3p0&#30340;&#37197;&#32622;
    </p>
    <p>
      &#30001;&#20110;Hibernate&#33258;&#24049;&#23454;&#29616;&#30340;&#36830;&#25509;&#27744;&#19981;&#22826;&#22909;&#65292;&#22312;&#39033;&#30446;&#20013;&#65292;&#24314;&#35758;&#20351;&#29992;&#24037;&#19994;&#32423;&#30340;&#36830;&#25509;
    </p>
    <p>
      &#27744;&#65292;&#27604;&#22914;&#65306;c3p0&#65292;Hibernate&#21457;&#34892;&#21253;&#20013;&#24102;&#26377;c3p0&#65292;&#19979;&#38754;&#23601;&#26159;&#20854;&#22522;&#26412;&#37197;&#32622;&#31034;&#20363;&#65306;
    </p>
    <p>
      &lt;property
    </p>
    <p>
      name=&quot;connection.driver_class&quot;&gt;oracle.jdbc.driver.OracleDriver&lt;/proper
    </p>
    <p>
      ty&gt;
    </p>
    <p>
      &lt;property
    </p>
    <p>
      name=&quot;connection.url&quot;&gt;jdbc:oracle:thin:@localhost:1521:orcl&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;connection.username&quot;&gt;javass&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;connection.password&quot;&gt;javass&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;c3p0.min_size&quot;&gt;5&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;c3p0.max_size&quot;&gt;20&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;c3p0.timeout&quot;&gt;180&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;c3p0.max_statements&quot;&gt;50&lt;/property&gt;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1491302785615" FOLDED="true" ID="ID_1085896219" MODIFIED="1491305340533" TEXT="xxx.hbm.xml&#x5b57;&#x6bb5;&#x914d;&#x7f6e;">
<node CREATED="1491302417833" FOLDED="true" ID="ID_197254586" MODIFIED="1491302754975" TEXT="version&#x5b57;&#x6bb5;&#x53ca;&#x4e50;&#x89c2;&#x9501;&#x793a;&#x4f8b;">
<node CREATED="1491302603546" FOLDED="true" ID="ID_1450927170" MODIFIED="1491302674488" TEXT="xxx.hbm.xml&#x914d;&#x7f6e;-version&#x5143;&#x7d20;">
<node CREATED="1491302651104" ID="ID_698490736" MODIFIED="1491302672280">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &lt;version&gt;&#20803;&#32032;
    </p>
    <p>
      &lt;version&gt; &#20803;&#32032;&#26159;&#21487;&#36873;&#30340;&#65292;&#34920;&#26126;&#34920;&#20013;&#21253;&#21547;&#38468;&#24102;&#29256;&#26412;&#20449;&#24687;&#30340;&#25968;&#25454;&#12290;
    </p>
    <p>
      &lt;version
    </p>
    <p>
      column=&quot;version_column&quot;(1)
    </p>
    <p>
      name=&quot;propertyName&quot;(2)
    </p>
    <p>
      type=&quot;typename&quot;(3)
    </p>
    <p>
      access=&quot;field|property|ClassName&quot;(4)
    </p>
    <p>
      unsaved-value=&quot;null|negative|undefined&quot;(5)
    </p>
    <p>
      generated=&quot;never|always&quot;(6)
    </p>
    <p>
      insert=&quot;true|false&quot;(7)
    </p>
    <p>
      /&gt;
    </p>
    <p>
      (1)column&#65288;&#21487;&#36873; &#8212; &#40664;&#35748;&#20026;&#23646;&#24615;&#21517;&#65289;&#65306;&#25351;&#23450;&#25345;&#26377;&#29256;&#26412;&#21495;&#30340;&#23383;&#27573;&#21517;&#12290;
    </p>
    <p>
      (2)name&#65306;&#25345;&#20037;&#21270;&#31867;&#30340;&#23646;&#24615;&#21517;&#12290;
    </p>
    <p>
      (3)type&#65288;&#21487;&#36873; &#8212; &#40664;&#35748;&#26159; integer&#65289;&#65306;&#29256;&#26412;&#21495;&#30340;&#31867;&#22411;&#12290;
    </p>
    <p>
      (4)access&#65288;&#21487;&#36873; &#8212; &#40664;&#35748;&#20026; property&#65289;&#65306;Hibernate &#29992;&#26469;&#35775;&#38382;&#23646;&#24615;&#20540;&#30340;&#31574;&#30053;&#12290;
    </p>
    <p>
      (5)unsaved-value&#65288;&#21487;&#36873; &#8212; &#40664;&#35748;&#26159; undefined&#65289;&#65306;&#29992;&#20110;&#26631;&#26126;&#26576;&#20010;&#23454;&#20363;&#26159;&#21018;&#21018;&#34987;&#23454;
    </p>
    <p>
      &#20363;&#21270;&#30340;&#65288;&#23578;&#26410;&#20445;&#23384;&#65289;&#29256;&#26412;&#23646;&#24615;&#20540;&#65292;&#20381;&#38752;&#36825;&#20010;&#20540;&#23601;&#21487;&#20197;&#25226;&#36825;&#31181;&#24773;&#20917; &#21644;&#24050;&#32463;&#22312;&#20808;&#21069;
    </p>
    <p>
      &#30340; session &#20013;&#20445;&#23384;&#25110;&#35013;&#36733;&#30340;&#33073;&#31649;&#65288;detached&#65289;&#23454;&#20363;&#21306;&#20998;&#24320;&#26469;&#12290;&#65288;undefined &#25351;
    </p>
    <p>
      &#26126;&#24212;&#34987;&#20351;&#29992;&#30340;&#26631;&#35782;&#23646;&#24615;&#20540;&#12290;&#65289;
    </p>
    <p>
      (6)generated&#65288;&#21487;&#36873; &#8212; &#40664;&#35748;&#26159; never&#65289;&#65306;&#34920;&#26126;&#27492;&#29256;&#26412;&#23646;&#24615;&#20540;&#26159;&#21542;&#23454;&#38469;&#19978;&#26159;&#30001;&#25968;&#25454;
    </p>
    <p>
      &#24211;&#29983;&#25104;&#30340;&#12290;
    </p>
    <p>
      (7)insert&#65288;&#21487;&#36873; &#8212; &#40664;&#35748;&#26159; true&#65289;&#65306;&#34920;&#26126;&#27492;&#29256;&#26412;&#21015;&#24212;&#35813;&#21253;&#21547;&#22312; SQL &#25554;&#20837;&#35821;&#21477;&#20013;&#12290;
    </p>
    <p>
      &#21482;&#26377;&#24403;&#25968;&#25454;&#24211;&#23383;&#27573;&#26377;&#40664;&#35748;&#20540; 0 &#30340;&#26102;&#20505;&#65292;&#25165;&#21487;&#20197;&#35774;&#32622;&#20026; false&#12290;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491302630288" FOLDED="true" ID="ID_446646103" MODIFIED="1491302646943" TEXT="&#x793a;&#x4f8b;">
<node CREATED="1491302425738" ID="ID_797737682" MODIFIED="1491302510288">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      1&#65306;&#39318;&#20808;&#22312;&#25968;&#25454;&#24211;&#34920;&#20013;&#28155;&#21152;&#19968;&#20010;&#23383;&#27573;&#65306;version &#65292;&#31867;&#22411;&#20026;number
    </p>
    <p>
      2&#65306;&#22312;UserModel&#37324;&#38754;&#28155;&#21152;&#19968;&#20010;&#23383;&#27573;&#65306;version&#65292;&#31867;&#22411;&#20026;int&#65292;&#20063;&#35201;&#23545;&#24212;&#30340;getter&#21644;
    </p>
    <p>
      setter&#26041;&#27861;
    </p>
    <p>
      3&#65306;&#22312;UserModel.hbm.xml&#20013;&#28155;&#21152;&#37197;&#32622;&#22914;&#19979;&#65306;
    </p>
    <p>
      &lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;
    </p>
    <p>
      &lt;!DOCTYPE hibernate-mapping PUBLIC
    </p>
    <p>
      '-//Hibernate/Hibernate Mapping DTD 3.0//EN'
    </p>
    <p>
      'http://hibernate.sourceforge.net/hibernate-mapping-3.0.dtd'&gt;
    </p>
    <p>
      &lt;hibernate-mapping&gt;
    </p>
    <p>
      &lt;class name=&quot;cn.javass.h3.hello.UserModel&quot; table=&quot;tbl_user&quot; optimistic-lock=&quot;version&quot;&gt;
    </p>
    <p>
      &lt;id name=&quot;uuid&quot;&gt;
    </p>
    <p>
      &lt;generator class=&quot;assigned&quot;/&gt;
    </p>
    <p>
      &lt;/id&gt;
    </p>
    <p>
      &lt;version name=&quot;version&quot;/&gt;
    </p>
    <p>
      &lt;property name=&quot;userId&quot;&gt;&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;name&quot;&gt;&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;age&quot;&gt;&lt;/property&gt;
    </p>
    <p>
      &lt;/class&gt;
    </p>
    <p>
      &lt;/hibernate-mapping&gt;
    </p>
    <p>
      4&#65306;&#28982;&#21518;&#25226;&#25968;&#25454;&#24211;tbl_user&#20013;&#30340;&#25968;&#25454;&#20840;&#37096;&#28165;&#38500;&#25481;&#65292;&#36825;&#26679;&#22909;&#35266;&#23519;&#25968;&#25454;&#21464;&#21270;
    </p>
    <p>
      5&#65306;&#36816;&#34892;&#21407;&#26469;&#30340;client&#65292;&#22312;&#25968;&#25454;&#24211;&#20013;&#29983;&#25104;&#19968;&#26465;&#25968;&#25454;&#65292;&#20540;&#26159;&#65306;uuid=1&#65292;userId=id1&#65292;
    </p>
    <p>
      name=name1&#65292;age=1&#65292;version=0
    </p>
    <p>
      6&#65306;&#27880;&#24847;&#65306;version&#23383;&#27573;&#20026;Hibernate&#33258;&#24049;&#32500;&#25252;&#65292;&#31243;&#24207;&#20013;&#19981;&#38656;&#35201;&#25805;&#20316;&#36825;&#20010;&#23383;&#27573;
    </p>
    <p>
      7&#65306;&#28982;&#21518;&#20889;&#26032;&#30340;&#23458;&#25143;&#31471;&#36827;&#34892;&#27979;&#35797;&#65292;&#22914;&#19979;&#65306;
    </p>
    <p>
      import org.hibernate.Session;
    </p>
    <p>
      import org.hibernate.SessionFactory;
    </p>
    <p>
      import org.hibernate.Transaction;
    </p>
    <p>
      import org.hibernate.cfg.Configuration;
    </p>
    <p>
      public class Client {
    </p>
    <p>
      public static void main(String[] args) {
    </p>
    <p>
      SessionFactory sf = new Configuration().configure().buildSessionFactory();
    </p>
    <p>
      Session session1 = null;
    </p>
    <p>
      Session session2 = null;
    </p>
    <p>
      try{
    </p>
    <p>
      
    </p>
    <p>
      // &#26377;&#20351;&#29992;&#32773;1&#24320;&#21551;&#20102;&#19968;&#20010;session1
    </p>
    <p>
      session1 = sf.openSession();
    </p>
    <p>
      // &#22312;&#36825;&#20043;&#21518;&#65292;&#39532;&#19978;&#26377;&#21478;&#19968;&#20010;&#20351;&#29992;&#32773;2&#24320;&#21551;&#20102;session2
    </p>
    <p>
      session2 = sf.openSession();
    </p>
    <p>
      // &#20351;&#29992;&#32773;1&#26597;&#35810;&#25968;&#25454;
    </p>
    <p>
      UserModel userV1 = (UserModel) session1.load(UserModel.class, &quot;1&quot;);
    </p>
    <p>
      // &#20351;&#29992;&#32773;2&#26597;&#35810;&#21516;&#19968;&#26465;&#25968;&#25454;
    </p>
    <p>
      UserModel userV2 = (UserModel) session2.load(UserModel.class, &quot;1&quot;);
    </p>
    <p>
      // &#27492;&#26102;&#20004;&#20010;&#29256;&#26412;&#21495;&#26159;&#30456;&#21516;&#30340;
    </p>
    <p>
      System.out.println(&quot;v1=&quot;+ userV1.getVersion() + &quot;,v2=&quot;+ userV2.getVersion());
    </p>
    <p>
      Transaction tx1 = session1.beginTransaction();
    </p>
    <p>
      Transaction tx2 = session2.beginTransaction();
    </p>
    <p>
      // &#20351;&#29992;&#32773;1&#26356;&#26032;&#25968;&#25454;
    </p>
    <p>
      userV1.setAge(111);
    </p>
    <p>
      tx1.commit();
    </p>
    <p>
      // &#27492;&#26102;&#30001;&#20110;&#25968;&#25454;&#26356;&#26032;&#65292;&#25968;&#25454;&#24211;&#20013;&#30340;&#29256;&#26412;&#21495;&#36882;&#22686;&#20102;
    </p>
    <p>
      // &#20004;&#31508;&#25968;&#25454;&#29256;&#26412;&#21495;&#19981;&#19968;&#26679;&#20102;
    </p>
    <p>
      System.out.println(&quot;v1=&quot;+userV1.getVersion()+&quot;,v2=&quot;+
    </p>
    <p>
      userV2.getVersion());
    </p>
    <p>
      
    </p>
    <p>
      // userV2 &#30340; age &#25968;&#25454;&#36824;&#26159;&#26087;&#30340;
    </p>
    <p>
      // &#25968;&#25454;&#26356;&#26032;
    </p>
    <p>
      userV2.setName(&quot;version test&quot;);
    </p>
    <p>
      // &#22240;&#29256;&#26412;&#21495;&#27604;&#25968;&#25454;&#24211;&#20013;&#30340;&#26087;
    </p>
    <p>
      // &#20462;&#25913;&#20250;&#22833;&#36133;&#65292;&#25243;&#20986;StableObjectStateException&#20363;&#22806;
    </p>
    <p>
      tx2.commit();
    </p>
    <p>
      }catch(Exception err){
    </p>
    <p>
      err.printStackTrace();
    </p>
    <p>
      }finally{
    </p>
    <p>
      session1.close();
    </p>
    <p>
      session2.close();
    </p>
    <p>
      }
    </p>
    <p>
      }
    </p>
    <p>
      }
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1491302808256" FOLDED="true" ID="ID_958381061" MODIFIED="1491302880254" TEXT="hibernate-mapping&#x5143;&#x7d20;">
<node CREATED="1491302834495" ID="ID_650328665" MODIFIED="1491302879106">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &lt;hibernate-mapping&gt;&#20803;&#32032;
    </p>
    <p>
      &#36825;&#20010;&#20803;&#32032;&#26159;xxx.hbm.xml&#37197;&#32622;&#30340;&#26681;&#20803;&#32032;&#65292;&#23450;&#20041;&#22914;&#19979;&#65306;
    </p>
    <p>
      &lt;hibernate-mapping
    </p>
    <p>
      schema=&quot;schemaName&quot; (1)
    </p>
    <p>
      catalog=&quot;catalogName&quot; (2)
    </p>
    <p>
      default-cascade=&quot;cascade_style&quot; (3)
    </p>
    <p>
      default-access=&quot;field|property|ClassName&quot; (4)
    </p>
    <p>
      default-lazy=&quot;true|false&quot; (5)
    </p>
    <p>
      auto-import=&quot;true|false&quot; (6)
    </p>
    <p>
      package=&quot;package.name&quot; (7) /&gt;
    </p>
    <p>
      (1)schema (&#21487;&#36873;): &#25968;&#25454;&#24211;schema&#30340;&#21517;&#31216;&#65292;&#34920;&#21517;&#20250;&#21152;&#19978;&#25152;&#25351;&#23450;&#30340;schema&#30340;&#21517;&#23383;&#25193;&#23637;
    </p>
    <p>
      &#20026;&#34920;&#30340;&#20840;&#38480;&#23450;&#21517;&#12290;
    </p>
    <p>
      (2) catalog (&#21487;&#36873;): &#25968;&#25454;&#24211;catalog&#30340;&#21517;&#31216;&#65292;&#34920;&#21517;&#20250;&#21152;&#19978;&#25152;&#25351;&#23450;&#30340;catalog&#30340;&#21517;&#23383;
    </p>
    <p>
      &#25193;&#23637;&#20026;&#34920;&#30340;&#20840;&#38480;&#23450;&#21517;&#12290;
    </p>
    <p>
      (3) default-cascade (&#21487;&#36873; - &#40664;&#35748;&#20026; none): &#40664;&#35748;&#30340;&#32423;&#32852;&#39118;&#26684;&#12290;&#25351;&#23450;&#20102;&#26410;&#26126;&#30830;&#27880;
    </p>
    <p>
      &#26126;cascade&#23646;&#24615;&#30340;Java&#23646;&#24615;&#21644;&#38598;&#21512;&#31867;&#65292;Hibernate&#20250;&#37319;&#21462;&#20160;&#20040;&#26679;&#30340;&#40664;&#35748;&#32423;&#32852;&#39118;&#26684;&#12290;
    </p>
    <p>
      auto-import&#23646;&#24615;&#40664;&#35748;&#35753;&#25105;&#20204;&#22312;&#26597;&#35810;&#35821;&#35328;&#20013;&#21487;&#20197;&#20351;&#29992;&#38750;&#20840;&#38480;&#23450;&#21517;&#30340;&#31867;&#21517;&#12290;
    </p>
    <p>
      (4) default-access (&#21487;&#36873; - &#40664;&#35748;&#20026; property): Hibernate&#29992;&#26469;&#35775;&#38382;&#25152;&#26377;&#23646;&#24615;&#30340;
    </p>
    <p>
      &#31574;&#30053;&#12290;&#21487;&#20197;&#36890;&#36807;&#23454;&#29616;PropertyAccessor&#25509;&#21475;&#33258;&#23450;&#20041;&#12290;
    </p>
    <p>
      (5) default-lazy (&#21487;&#36873; - &#40664;&#35748;&#20026; true): &#25351;&#23450;&#20102;&#26410;&#26126;&#30830;&#27880;&#26126;lazy&#23646;&#24615;&#30340;Java&#23646;&#24615;
    </p>
    <p>
      &#21644;&#38598;&#21512;&#31867;&#65292; Hibernate&#20250;&#37319;&#21462;&#20160;&#20040;&#26679;&#30340;&#40664;&#35748;&#21152;&#36733;&#39118;&#26684;&#12290;
    </p>
    <p>
      (6) auto-import (&#21487;&#36873; - &#40664;&#35748;&#20026; true): &#25351;&#23450;&#25105;&#20204;&#26159;&#21542;&#21487;&#20197;&#22312;&#26597;&#35810;&#35821;&#35328;&#20013;&#20351;&#29992;&#38750;
    </p>
    <p>
      &#20840;&#38480;&#23450;&#30340;&#31867;&#21517;&#65288;&#20165;&#38480;&#20110;&#26412;&#26144;&#23556;&#25991;&#20214;&#20013;&#30340;&#31867;&#65289;&#12290;
    </p>
    <p>
      (7) package (&#21487;&#36873;): &#25351;&#23450;&#19968;&#20010;&#21253;&#21069;&#32512;&#65292;&#22914;&#26524;&#22312;&#26144;&#23556;&#25991;&#26723;&#20013;&#27809;&#26377;&#25351;&#23450;&#20840;&#38480;&#23450;&#30340;&#31867;
    </p>
    <p>
      &#21517;&#65292; &#23601;&#20351;&#29992;&#36825;&#20010;&#20316;&#20026;&#21253;&#21517;&#12290;
    </p>
    <p>
      &#20551;&#33509;&#20320;&#26377;&#20004;&#20010;&#25345;&#20037;&#21270;&#31867;&#65292;&#23427;&#20204;&#30340;&#38750;&#20840;&#38480;&#23450;&#21517;&#26159;&#19968;&#26679;&#30340;&#65288;&#23601;&#26159;&#20004;&#20010;&#31867;&#30340;&#21517;&#23383;
    </p>
    <p>
      &#19968;&#26679;&#65292;&#25152;&#22312;&#30340;&#21253;&#19981;&#19968;&#26679;&#65289;&#65292; &#20320;&#24212;&#35813;&#35774;&#32622;auto-import=&quot;false&quot;&#12290;&#22914;&#26524;&#20320;&#25226;&#19968;&#20010;
    </p>
    <p>
      &#8220;import&#36807;&#8221;&#30340;&#21517;&#23383;&#21516;&#26102;&#23545;&#24212;&#20004;&#20010;&#31867;&#65292; Hibernate&#20250;&#25243;&#20986;&#19968;&#20010;&#24322;&#24120;&#12290;
    </p>
    <p>
      &#160;1+N&#27425;&#26597;&#35810;&#30340;&#38382;&#39064;
    </p>
    <p>
      &#22914;&#26524;&#35774;&#32622;&#20102;&#35013;&#36733;&#31574;&#30053;&#20026;lazy&#65292;&#37027;&#20040;&#21487;&#33021;&#20250;&#24102;&#26469;&#26377;&#21517;&#30340;1+N&#27425;&#26597;&#35810;&#30340;&#38382;&#39064;&#65292;
    </p>
    <p>
      1+N&#26377;&#20004;&#31181;&#20856;&#22411;&#30340;&#20307;&#29616;&#65292;&#19968;&#20010;&#26159;&#20197;Iterator&#20026;&#20195;&#34920;&#65292;&#19968;&#20010;&#26159;&#20197;&#20851;&#31995;&#26144;&#23556;&#20026;&#20195;&#34920;&#12290;
    </p>
    <p>
      ? &#20197;Iterator&#20026;&#20195;&#34920;&#30340;1+N&#27425;&#26597;&#35810;
    </p>
    <p>
      1&#65306;&#31532;&#19968;&#27425;&#26597;&#35810;&#30340;&#26102;&#20505;&#65306;&#22914;&#26524;&#26159;&#35774;&#32622;&#20102;lazy&#30340;&#23545;&#35937;&#65292;Hibernate&#20250;&#21482;&#35013;&#36733;&#20027;&#38190;&#30340;&#20540;
    </p>
    <p>
      2&#65306;&#37027;&#20040;&#20197;&#21518;&#27599;&#27425;&#30495;&#27491;&#35843;&#29992;&#19968;&#20010;&#23545;&#35937;&#30340;&#26102;&#20505;&#65292;Hibernate&#21457;&#29616;&#36825;&#20010;&#23545;&#35937;&#27809;&#26377;&#20540;&#65292;&#21482;&#26377;
    </p>
    <p>
      &#20027;&#38190;&#65292;&#37027;&#20040;Hibernate&#20250;&#29992;&#20027;&#38190;&#20570;&#26465;&#20214;&#37325;&#26032;&#26597;&#35810;&#19968;&#27425;&#12290;
    </p>
    <p>
      3&#65306;&#35774;&#33509;N&#26465;&#35760;&#24405;&#21518;&#26469;&#37117;&#35775;&#38382;&#20102;&#65292;&#37027;&#20040;&#24635;&#30340;&#26597;&#35810;&#27425;&#25968;&#23601;&#26159;1+N&#27425;
    </p>
    <p>
      ? &#20197;&#20851;&#31995;&#26144;&#23556;&#20026;&#20195;&#34920;&#30340;1+N&#27425;&#26597;&#35810;
    </p>
    <p>
      1&#65306;&#31532;&#19968;&#27425;&#26597;&#35810;&#20986;&#26377;N&#26465;Parnet&#23545;&#35937;
    </p>
    <p>
      2&#65306;&#24403;&#35775;&#38382;&#27599;&#20010;Parent&#23545;&#35937;&#37324;&#38754;&#30340;Child&#23545;&#35937;&#25110;Child&#23545;&#35937;&#38598;&#21512;&#30340;&#26102;&#20505;&#65292;&#20250;&#37325;&#26032;&#29992;&#19968;&#26465;
    </p>
    <p>
      sql&#21435;&#35775;&#38382;Child&#23545;&#35937;
    </p>
    <p>
      3&#65306;&#35774;&#33509;N&#26465;Parent&#23545;&#35937;&#37117;&#35775;&#38382;&#20102;&#37324;&#38754;&#30340;Child&#65292;&#37027;&#20040;&#24635;&#30340;&#26597;&#35810;&#27425;&#25968;&#23601;&#26159;1+N&#27425;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491302882375" FOLDED="true" ID="ID_1712391446" MODIFIED="1491302956229" TEXT="class&#x5143;&#x7d20;">
<node CREATED="1491302899495" ID="ID_1484595716" MODIFIED="1491302955079">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &lt;class&gt;&#20803;&#32032;
    </p>
    <p>
      &#20351;&#29992;class&#20803;&#32032;&#26469;&#23450;&#20041;&#19968;&#20010;&#25345;&#20037;&#21270;&#31867;&#65306;
    </p>
    <p>
      &lt;class
    </p>
    <p>
      name=&quot;ClassName&quot; (1)
    </p>
    <p>
      table=&quot;tableName&quot; (2)
    </p>
    <p>
      discriminator-value=&quot;discriminator_value&quot; (3)
    </p>
    <p>
      mutable=&quot;true|false&quot; (4)
    </p>
    <p>
      schema=&quot;owner&quot; (5)
    </p>
    <p>
      catalog=&quot;catalog&quot; (6)
    </p>
    <p>
      proxy=&quot;ProxyInterface&quot; (7)
    </p>
    <p>
      dynamic-update=&quot;true|false&quot; (8)
    </p>
    <p>
      dynamic-insert=&quot;true|false&quot; (9)
    </p>
    <p>
      select-before-update=&quot;true|false&quot; (10)
    </p>
    <p>
      polymorphism=&quot;implicit|explicit&quot; (11)
    </p>
    <p>
      where=&quot;arbitrary sql where condition&quot; (12)
    </p>
    <p>
      persister=&quot;PersisterClass&quot; (13)
    </p>
    <p>
      batch-size=&quot;N&quot; (14)
    </p>
    <p>
      optimistic-lock=&quot;none|version|dirty|all&quot; (15)
    </p>
    <p>
      lazy=&quot;true|false&quot; (16)
    </p>
    <p>
      entity-name=&quot;EntityName&quot; (17)
    </p>
    <p>
      check=&quot;arbitrary sql check condition&quot; (18)
    </p>
    <p>
      rowid=&quot;rowid&quot; (19)
    </p>
    <p>
      subselect=&quot;SQL expression&quot; (20)
    </p>
    <p>
      abstract=&quot;true|false&quot; (21)
    </p>
    <p>
      /&gt;
    </p>
    <p>
      (1)name (&#21487;&#36873;): &#25345;&#20037;&#21270;&#31867;&#65288;&#25110;&#32773;&#25509;&#21475;&#65289;&#30340;Java&#20840;&#38480;&#23450;&#21517;&#12290;&#22914;&#26524;&#36825;&#20010;&#23646;&#24615;&#19981;&#23384;&#22312;&#65292;
    </p>
    <p>
      Hibernate&#23558;&#20551;&#23450;&#36825;&#26159;&#19968;&#20010;&#38750; POJO&#30340;&#23454;&#20307;&#26144;&#23556;&#12290;&#33509;&#25351;&#26126;&#30340;&#25345;&#20037;&#21270;&#31867;&#23454;&#38469;&#19978;&#26159;&#19968;&#20010;
    </p>
    <p>
      &#25509;&#21475;&#65292;&#36825;&#20063;&#26159;&#21487;&#20197;&#30340;&#65292;&#21487;&#20197;&#29992;&#20803;&#32032;&lt;subclass&gt;&#26469;&#25351;&#23450;&#35813;&#25509;&#21475;&#30340;&#23454;&#38469;&#23454;&#29616;&#31867;&#12290;
    </p>
    <p>
      (2) table (&#21487;&#36873; - &#40664;&#35748;&#26159;&#31867;&#30340;&#38750;&#20840;&#38480;&#23450;&#21517;): &#23545;&#24212;&#30340;&#25968;&#25454;&#24211;&#34920;&#21517;
    </p>
    <p>
      (3) discriminator-value (&#21487;&#36873; - &#40664;&#35748;&#21644;&#31867;&#21517;&#19968;&#26679;): &#19968;&#20010;&#29992;&#20110;&#21306;&#20998;&#19981;&#21516;&#30340;&#23376;&#31867;&#30340;
    </p>
    <p>
      &#20540;&#65292;&#22312;&#22810;&#24577;&#34892;&#20026;&#26102;&#20351;&#29992;&#12290;&#23427;&#21487;&#20197;&#25509;&#21463;&#30340;&#20540;&#21253;&#25324; null &#21644; not null
    </p>
    <p>
      (4) mutable (&#21487;&#36873;&#65292;&#40664;&#35748;&#20540;&#20026;true): &#34920;&#26126;&#35813;&#31867;&#30340;&#23454;&#20363;&#26159;&#21487;&#21464;&#30340;&#25110;&#32773;&#19981;&#21487;&#21464;&#30340;&#12290;
    </p>
    <p>
      &#19981;&#21487;&#21464;&#31867;&#65292;mutable=&quot;false&quot;&#19981;&#21487;&#20197;&#34987;&#24212;&#29992;&#31243;&#24207;&#26356;&#26032;&#25110;&#32773;&#21024;&#38500;&#12290;
    </p>
    <p>
      (5) schema (optional): &#35206;&#30422;&#22312;&#26681;&#20803;&#32032;&lt;hibernate-mapping&gt;&#20013;&#25351;&#23450;&#30340;schema
    </p>
    <p>
      (6) catalog (optional):&#35206;&#30422;&#22312;&#26681;&#20803;&#32032;&lt;hibernate-mapping&gt;&#20013;&#25351;&#23450;&#30340;catalog
    </p>
    <p>
      (7) proxy (&#21487;&#36873;): &#25351;&#23450;&#19968;&#20010;&#25509;&#21475;&#65292;&#22312;&#24310;&#36831;&#35013;&#36733;&#26102;&#20316;&#20026;&#20195;&#29702;&#20351;&#29992;&#12290;
    </p>
    <p>
      &#21487;&#36873;&#30340;proxy&#23646;&#24615;&#20801;&#35768;&#24310;&#36831;&#21152;&#36733;&#31867;&#30340;&#25345;&#20037;&#21270;&#23454;&#20363;&#12290; Hibernate&#24320;&#22987;&#20250;&#36820;&#22238;&#23454;
    </p>
    <p>
      &#29616;&#20102;&#36825;&#20010;&#21629;&#21517;&#25509;&#21475;&#30340;CGLIB&#20195;&#29702;&#12290;&#24403;&#20195;&#29702;&#30340;&#26576;&#20010;&#26041;&#27861;&#34987;&#23454;&#38469;&#35843;&#29992;&#30340;&#26102;&#20505;&#65292; &#30495;&#23454;&#30340;
    </p>
    <p>
      &#25345;&#20037;&#21270;&#23545;&#35937;&#25165;&#20250;&#34987;&#35013;&#36733;&#12290;
    </p>
    <p>
      (8) dynamic-update (&#21487;&#36873;, &#40664;&#35748;&#20026; false): &#25351;&#23450;&#29992;&#20110;UPDATE &#30340;SQL&#23558;&#20250;&#22312;&#36816;&#34892;&#26102;&#21160;&#24577;
    </p>
    <p>
      &#29983;&#25104;&#65292;&#24182;&#19988;&#21482;&#26356;&#26032;&#37027;&#20123;&#25913;&#21464;&#36807;&#30340;&#23383;&#27573;&#12290;
    </p>
    <p>
      (9) dynamic-insert (&#21487;&#36873;, &#40664;&#35748;&#20026; false): &#25351;&#23450;&#29992;&#20110;INSERT&#30340; SQL &#23558;&#20250;&#22312;&#36816;&#34892;&#26102;&#21160;
    </p>
    <p>
      &#24577;&#29983;&#25104;&#65292;&#24182;&#19988;&#21482;&#21253;&#21547;&#37027;&#20123;&#38750;&#31354;&#20540;&#23383;&#27573;
    </p>
    <p>
      (10) select-before-update (&#21487;&#36873;, &#40664;&#35748;&#20026; false): &#25351;&#23450;Hibernate&#38500;&#38750;&#30830;&#23450;&#23545;&#35937;&#30495;&#27491;
    </p>
    <p>
      &#34987;&#20462;&#25913;&#20102;&#65292;&#21542;&#21017;&#19981;&#20250;&#25191;&#34892;SQL UPDATE&#25805;&#20316;&#12290;&#22312;&#29305;&#23450;&#22330;&#21512;&#65288;&#23454;&#38469;&#19978;&#65292;&#23427;&#21482;&#22312;&#19968;&#20010;&#30636;&#26102;&#23545;
    </p>
    <p>
      &#35937;&#65288;transient object&#65289;&#20851;&#32852;&#21040;&#19968;&#20010; &#26032;&#30340;session&#20013;&#26102;&#25191;&#34892;&#30340;update()&#20013;&#29983;&#25928;&#65289;&#65292;&#36825;
    </p>
    <p>
      &#35828;&#26126;Hibernate&#20250;&#22312;UPDATE &#20043;&#21069;&#25191;&#34892;&#19968;&#27425;&#39069;&#22806;&#30340;SQL SELECT&#25805;&#20316;&#65292;&#26469;&#20915;&#23450;&#26159;&#21542;&#24212;&#35813;&#25191;
    </p>
    <p>
      &#34892; UPDATE&#12290;&#20351;&#29992;select-before-update&#36890;&#24120;&#20250;&#38477;&#20302;&#24615;&#33021;&#12290;
    </p>
    <p>
      (11) polymorphism&#65288;&#22810;&#24577;&#65289; (&#21487;&#36873;, &#40664;&#35748;&#20540;&#20026; implicit (&#38544;&#24335;) ): &#30028;&#23450;&#26159;&#38544;&#24335;&#36824;&#26159;&#26174;
    </p>
    <p>
      &#24335;&#30340;&#20351;&#29992;&#22810;&#24577;&#26597;&#35810;&#65292;&#36825;&#21482;&#22312;Hibernate&#30340;&#20855;&#20307;&#34920;&#32487;&#25215;&#31574;&#30053;&#20013;&#29992;&#21040;&#12290;
    </p>
    <p>
      Implicit&#38544;&#24335;&#22810;&#24577;&#26159;&#25351;&#65306;&#22914;&#26524;&#26597;&#35810;&#26102;&#32473;&#20986;&#30340;&#26159;&#20219;&#20309;&#36229;&#31867;&#12289;&#35813;&#31867;&#23454;&#29616;&#30340;&#25509;&#21475;&#25110;&#32773;&#35813;&#31867;&#30340;
    </p>
    <p>
      &#21517;&#23383;&#65292;&#37117;&#20250;&#36820;&#22238;&#36825;&#20010;&#31867;&#30340;&#23454;&#20363;&#65307;&#22914;&#26524;&#26597;&#35810;&#20013;&#32473;&#20986;&#30340;&#26159;&#23376;&#31867;&#30340;&#21517;&#23383;&#65292;&#21017;&#20250;&#36820;&#22238;&#23376;&#31867;&#30340;&#23454;
    </p>
    <p>
      &#20363;&#12290;Explicit&#26174;&#24335;&#22810;&#24577;&#26159;&#25351;&#65306;&#21482;&#26377;&#22312;&#26597;&#35810;&#26102;&#32473;&#20986;&#26126;&#30830;&#30340;&#35813;&#31867;&#21517;&#23383;&#26102;&#25165;&#20250;&#36820;&#22238;&#36825;&#20010;&#31867;&#30340;
    </p>
    <p>
      &#23454;&#20363;&#65307;&#21516;&#26102;&#21482;&#26377;&#22312;&#36825;&#20010;&lt;class&gt;&#30340;&#23450;&#20041;&#20013;&#20316;&#20026;&lt;subclass&gt; &#25110;&#32773;&lt;joined-subclass&gt;&#20986;
    </p>
    <p>
      &#29616;&#30340;&#23376;&#31867;&#65292;&#25165;&#21487;&#33021;&#34987;&#36820;&#22238;&#12290;&#22312;&#22823;&#22810;&#25968;&#24773;&#20917;&#19979;&#65292;&#40664;&#35748;&#30340;polymorphism=&quot;implicit&quot;&#37117;&#26159;
    </p>
    <p>
      &#21512;&#36866;&#30340;&#12290;
    </p>
    <p>
      (12) where (&#21487;&#36873;) &#25351;&#23450;&#19968;&#20010;&#38468;&#21152;&#30340;SQLWHERE &#26465;&#20214;&#65292; &#22312;&#25235;&#21462;&#36825;&#20010;&#31867;&#30340;&#23545;&#35937;&#26102;&#20250;&#19968;
    </p>
    <p>
      &#30452;&#22686;&#21152;&#36825;&#20010;&#26465;&#20214;
    </p>
    <p>
      (13) persister (&#21487;&#36873;): &#25351;&#23450;&#19968;&#20010;&#23450;&#21046;&#30340;ClassPersister
    </p>
    <p>
      (14) batch-size (&#21487;&#36873;,&#40664;&#35748;&#26159;1) &#25351;&#23450;&#19968;&#20010;&#29992;&#20110; &#26681;&#25454;&#26631;&#35782;&#31526;&#65288;identifier&#65289;&#25235;&#21462;
    </p>
    <p>
      &#23454;&#20363;&#26102;&#20351;&#29992;&#30340;&#8220;batch size&#8221;&#65288;&#25209;&#27425;&#25235;&#21462;&#25968;&#37327;&#65289;
    </p>
    <p>
      (15) optimistic-lock&#65288;&#20048;&#35266;&#38145;&#23450;&#65289;(&#21487;&#36873;&#65292;&#40664;&#35748;version): &#20915;&#23450;&#20048;&#35266;&#38145;&#23450;&#30340;&#31574;&#30053;&#12290;
    </p>
    <p>
      &#22914;&#26524;&#20320;&#25171;&#24320;&#20102;dynamic-update&#65292;&#20320;&#21487;&#20197;&#36873;&#25321;&#20960;&#31181;&#20048;&#35266;&#38145;&#23450;&#30340;&#31574;&#30053;&#65306;
    </p>
    <p>
      1&#65289;version&#65288;&#29256;&#26412;&#26816;&#26597;&#65289; &#26816;&#26597;version/timestamp&#23383;&#27573;
    </p>
    <p>
      2&#65289;all&#65288;&#20840;&#37096;&#65289; &#26816;&#26597;&#20840;&#37096;&#23383;&#27573;
    </p>
    <p>
      3&#65289;dirty&#65288;&#33039;&#26816;&#26597;&#65289;&#21482;&#26816;&#23519;&#20462;&#25913;&#36807;&#30340;&#23383;&#27573;
    </p>
    <p>
      4&#65289;none&#65288;&#19981;&#26816;&#26597;&#65289;&#19981;&#20351;&#29992;&#20048;&#35266;&#38145;&#23450;
    </p>
    <p>
      &#38750;&#24120;&#24378;&#28872;&#24314;&#35758;&#20320;&#22312;Hibernate&#20013;&#20351;&#29992;version/timestamp&#23383;&#27573;&#26469;&#36827;&#34892;&#20048;&#35266;&#38145;
    </p>
    <p>
      &#23450;&#12290; &#23545;&#24615;&#33021;&#26469;&#35828;&#65292;&#36825;&#26159;&#26368;&#22909;&#30340;&#36873;&#25321;&#65292;&#24182;&#19988;&#36825;&#20063;&#26159;&#21807;&#19968;&#33021;&#22815;&#22788;&#29702;&#22312;session&#22806;&#36827;&#34892;
    </p>
    <p>
      &#25805;&#20316;&#30340;&#31574;&#30053;
    </p>
    <p>
      (16) lazy (&#21487;&#36873;): &#24310;&#36831;&#21152;&#36733;&#65288;Lazy fetching&#65289;
    </p>
    <p>
      (17) entity-name (&#21487;&#36873;&#65292;&#40664;&#35748;&#20026;&#31867;&#21517;): Hibernate4&#20801;&#35768;&#19968;&#20010;&#31867;&#36827;&#34892;&#22810;&#27425;&#26144;&#23556;&#65288;&#21069;
    </p>
    <p>
      &#25552;&#26159;&#26144;&#23556;&#21040;&#19981;&#21516;&#30340;&#34920;&#65289;&#65292;&#24182;&#19988;&#20801;&#35768;&#20351;&#29992;Maps&#25110;XML&#20195;&#26367;Java&#23618;&#27425;&#30340;&#23454;&#20307;&#26144;&#23556;&#65288;&#20063;
    </p>
    <p>
      &#23601;&#26159;&#23454;&#29616;&#21160;&#24577;&#39046;&#22495;&#27169;&#22411;&#65292;&#19981;&#29992;&#20889;&#25345;&#20037;&#21270;&#31867;&#65289;
    </p>
    <p>
      (18) check (&#21487;&#36873;): &#36825;&#26159;&#19968;&#20010;SQL&#34920;&#36798;&#24335;&#65292;&#29992;&#20110;&#20026;&#33258;&#21160;&#29983;&#25104;&#30340;schema&#28155;&#21152;&#22810;&#34892;&#32422;&#26463;
    </p>
    <p>
      &#26816;&#26597;
    </p>
    <p>
      (19) rowid (&#21487;&#36873;): Hibernate&#21487;&#20197;&#20351;&#29992;&#25968;&#25454;&#24211;&#25903;&#25345;&#30340;&#25152;&#35859;&#30340;ROWIDs&#65292;&#20363;&#22914;&#65306;
    </p>
    <p>
      Oracle&#25968;&#25454;&#24211;&#65292;&#22914;&#26524;&#20320;&#35774;&#32622;&#36825;&#20010;&#21487;&#36873;&#30340;rowid&#65292; Hibernate&#21487;&#20197;&#20351;&#29992;&#39069;&#22806;&#30340;&#23383;&#27573;
    </p>
    <p>
      rowid&#23454;&#29616;&#24555;&#36895;&#26356;&#26032;&#12290;
    </p>
    <p>
      (20) subselect (&#21487;&#36873;): &#23427;&#23558;&#19968;&#20010;&#19981;&#21487;&#21464;&#65288;immutable&#65289;&#24182;&#19988;&#21482;&#35835;&#30340;&#23454;&#20307;&#26144;&#23556;&#21040;&#19968;
    </p>
    <p>
      &#20010;&#25968;&#25454;&#24211;&#30340; &#23376;&#26597;&#35810;&#20013;&#12290;&#24403;&#20320;&#24819;&#29992;&#35270;&#22270;&#20195;&#26367;&#19968;&#24352;&#22522;&#26412;&#34920;&#30340;&#26102;&#20505;&#65292;&#36825;&#26159;&#26377;&#29992;&#30340;&#65292;&#20294;
    </p>
    <p>
      &#26368;&#22909;&#19981;&#35201;&#36825;&#26679;&#20570;
    </p>
    <p>
      (21) abstract (&#21487;&#36873;): &#29992;&#20110;&#22312;&lt;union-subclass&gt;&#30340;&#32487;&#25215;&#32467;&#26500;&#20013;&#26631;&#35782;&#25277;&#35937;&#36229;&#31867;
    </p>
    <p>
      &#22914;&#26524;&#24819;&#35201;&#22810;&#27425;&#26144;&#23556;&#21516;&#19968;&#20010;&#31867;&#65292;&#21487;&#20197;&#37319;&#29992;&#22914;&#19979;&#30340;&#26041;&#24335;&#65306;
    </p>
    <p>
      &#23545;&#29305;&#23450;&#30340;&#25345;&#20037;&#21270;&#31867;&#65292;&#26144;&#23556;&#22810;&#27425;&#26159;&#20801;&#35768;&#30340;&#12290;&#36825;&#31181;&#24773;&#24418;&#19979;&#65292;&#20320;&#24517;&#39035;&#25351;&#23450; entity
    </p>
    <p>
      name &#26469;&#21306;&#21035;&#19981;&#21516;&#26144;&#23556;&#23454;&#20307;&#30340;&#23545;&#35937;&#23454;&#20363;&#12290;&#40664;&#35748;&#24773;&#20917;&#19979;&#65292;&#23454;&#20307;&#21517;&#23383;&#21644;&#31867;&#21517;&#26159;&#30456;&#21516;
    </p>
    <p>
      &#30340;&#12290; Hibernate &#22312;&#25805;&#20316;&#25345;&#20037;&#21270;&#23545;&#35937;&#12289;&#32534;&#20889;&#26597;&#35810;&#26465;&#20214;&#65292;&#25110;&#32773;&#25226;&#20851;&#32852;&#26144;&#23556;&#21040;&#25351;&#23450;&#23454;
    </p>
    <p>
      &#20307;&#26102;&#65292;&#20801;&#35768;&#20320;&#25351;&#23450;&#36825;&#20010; entity name&#65288;&#23454;&#20307;&#21517;&#23383;&#65289;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491303848480" FOLDED="true" ID="ID_240460939" MODIFIED="1491303902823" TEXT="id&#x5143;&#x7d20;">
<node CREATED="1491303853456" ID="ID_1276378200" MODIFIED="1491303901587">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#34987;&#26144;&#23556;&#30340;&#31867;&#24517;&#39035;&#23450;&#20041;&#23545;&#24212;&#25968;&#25454;&#24211;&#34920;&#20027;&#38190;&#23383;&#27573;&#12290;&#22823;&#22810;&#25968;&#31867;&#26377;&#19968;&#20010;JavaBeans&#39118;&#26684;&#30340;&#23646;&#24615;&#65292; &#20026;
    </p>
    <p>
      &#27599;&#19968;&#20010;&#23454;&#20363;&#21253;&#21547;&#21807;&#19968;&#30340;&#26631;&#35782;&#12290;&lt;id&gt; &#20803;&#32032;&#23450;&#20041;&#20102;&#35813;&#23646;&#24615;&#21040;&#25968;&#25454;&#24211;&#34920;&#20027;&#38190;&#23383;&#27573;&#30340;&#26144;&#23556;&#12290;
    </p>
    <p>
      &lt;id
    </p>
    <p>
      name=&quot;propertyName&quot; (1)
    </p>
    <p>
      type=&quot;typename&quot; (2)
    </p>
    <p>
      column=&quot;column_name&quot; (3)
    </p>
    <p>
      unsaved-value=&quot;null|any|none|undefined|id_value&quot; (4)
    </p>
    <p>
      access=&quot;field|property|ClassName&quot;&gt; (5)
    </p>
    <p>
      &lt;generator class=&quot;generatorClass&quot;/&gt;
    </p>
    <p>
      &lt;/id&gt;
    </p>
    <p>
      (1) name (&#21487;&#36873;): &#26631;&#35782;&#23646;&#24615;&#30340;&#21517;&#23383;
    </p>
    <p>
      (2) type (&#21487;&#36873;): &#26631;&#35782;Hibernate&#31867;&#22411;&#30340;&#21517;&#23383;
    </p>
    <p>
      (3) column (&#21487;&#36873; - &#40664;&#35748;&#20026;&#23646;&#24615;&#21517;): &#20027;&#38190;&#23383;&#27573;&#30340;&#21517;&#23383;
    </p>
    <p>
      (4) unsaved-value (&#21487;&#36873; - &#40664;&#35748;&#20026;&#19968;&#20010;&#20999;&#21512;&#23454;&#38469;&#65288;sensible&#65289;&#30340;&#20540;): &#19968;&#20010;&#29305;&#23450;&#30340;&#26631;&#35782;&#23646;&#24615;
    </p>
    <p>
      &#20540;&#65292;&#29992;&#26469;&#26631;&#24535;&#35813;&#23454;&#20363;&#26159;&#21018;&#21018;&#21019;&#24314;&#30340;&#65292;&#23578;&#26410;&#20445;&#23384;&#12290; unsaved-value &#23646;&#24615;&#22312;Hibernate4&#20013;&#20960;&#20046;
    </p>
    <p>
      &#19981;&#20877;&#38656;&#35201;&#12290;
    </p>
    <p>
      (5) access (&#21487;&#36873; - &#40664;&#35748;&#20026;property)&#65306;Hibernate&#29992;&#26469;&#35775;&#38382;&#23646;&#24615;&#20540;&#24471;&#31574;&#30053;
    </p>
    <p>
      Hibernate&#30340;&#31867;&#22411;
    </p>
    <p>
      Hibernate&#22312;&#36827;&#34892;&#26144;&#23556;&#30340;&#26102;&#20505;&#65292;&#26082;&#19981;&#20351;&#29992;Java&#30340;&#31867;&#22411;&#65292;&#20063;&#19981;&#20351;&#29992;&#25968;&#25454;&#24211;&#30340;&#31867;&#22411;&#65292;&#32780;&#26159;&#20351;&#29992;&#33258;
    </p>
    <p>
      &#24049;&#25552;&#20379;&#30340;&#31867;&#22411;&#65292; Hibernate&#25552;&#20379;&#22823;&#37327;&#30340;&#20869;&#24314;&#31867;&#22411;&#65292;&#20063;&#25903;&#25345;&#33258;&#23450;&#20041;&#31867;&#22411;&#12290;
    </p>
    <p>
      ? Hibernate&#30340;&#20869;&#24314;&#31867;&#22411;
    </p>
    <p>
      &#20869;&#32622;&#30340; basic mapping types &#21487;&#20197;&#22823;&#33268;&#22320;&#20998;&#31867;&#20026;&#65306;
    </p>
    <p>
      1&#65306;integer, long, short, float, double, character, byte, boolean, yes_no,
    </p>
    <p>
      true_false
    </p>
    <p>
      &#36825;&#20123;&#31867;&#22411;&#37117;&#23545;&#24212;Java&#30340;&#21407;&#22987;&#31867;&#22411;&#25110;&#20854;&#23553;&#35013;&#31867;&#65292;&#26469;&#31526;&#21512;&#29305;&#23450;&#21378;&#21830;&#30340;SQL &#23383;&#27573;&#31867;&#22411;&#12290;
    </p>
    <p>
      2&#65306;boolean,yes_no&#21644;true_false
    </p>
    <p>
      &#26159;Java&#20013;boolean&#25110;&#32773;Boolean&#30340;&#21478;&#22806;&#35828;&#27861;&#12290;
    </p>
    <p>
      3&#65306;string
    </p>
    <p>
      &#20174; java.lang.String &#21040; VARCHAR&#65288;&#25110;&#32773; Oracle &#30340; VARCHAR2&#65289;&#30340;&#26144;&#23556;&#12290;
    </p>
    <p>
      4&#65306;date, time, timestamp
    </p>
    <p>
      &#20174;java.util.Date&#21644;&#20854;&#23376;&#31867;&#21040;SQL&#31867;&#22411; DATE&#65292;TIME &#21644; TIMESTAMP&#65288;&#25110;&#31561;&#20215;&#31867;&#22411;&#65289;&#30340;&#26144;&#23556;&#12290;
    </p>
    <p>
      5&#65306;calendar, calendar_date
    </p>
    <p>
      &#20174;java.util.Calendar&#21040;SQL&#31867;&#22411;TIMESTAMP&#21644;DATE&#65288;&#25110;&#31561;&#20215;&#31867;&#22411;&#65289;&#30340;&#26144;&#23556;&#12290;
    </p>
    <p>
      6&#65306;big_decimal, big_integer
    </p>
    <p>
      &#20174; java.math.BigDecimal &#21644; java.math.BigInteger &#21040; NUMERIC&#65288;&#25110;&#32773; Oracle &#30340;
    </p>
    <p>
      NUMBER&#31867;&#22411;&#65289;&#30340;&#26144;&#23556;&#12290;
    </p>
    <p>
      7&#65306;locale, timezone, currency
    </p>
    <p>
      &#20174; java.util.Locale&#65292;java.util.TimeZone &#21644; java.util.Currency &#21040; VARCHAR&#65288;&#25110;&#32773;
    </p>
    <p>
      Oracle &#30340;VARCHAR2 &#31867;&#22411;&#65289;&#30340;&#26144;&#23556;&#12290;Locale &#21644; Currency &#30340;&#23454;&#20363;&#34987;&#26144;&#23556;&#20026;&#23427;&#20204;&#30340; ISO &#20195;
    </p>
    <p>
      &#30721;&#12290;TimeZone &#30340;&#23454;&#20363;&#34987;&#24433;&#23556;&#20026;&#23427;&#30340; ID&#12290;
    </p>
    <p>
      8&#65306;class
    </p>
    <p>
      &#20174;java.lang.Class &#21040; VARCHAR&#65288;&#25110;&#32773; Oracle &#30340; VARCHAR2 &#31867;&#22411;&#65289;&#30340;&#26144;&#23556;&#12290;Class &#34987;&#26144;
    </p>
    <p>
      &#23556;&#20026;&#23427;&#30340;&#20840;&#38480;&#23450;&#21517;&#12290;
    </p>
    <p>
      9&#65306;binary
    </p>
    <p>
      &#25226;&#23383;&#33410;&#25968;&#32452;&#65288;byte arrays&#65289;&#26144;&#23556;&#20026;&#23545;&#24212;&#30340; SQL &#20108;&#36827;&#21046;&#31867;&#22411;&#12290;
    </p>
    <p>
      10&#65306;text
    </p>
    <p>
      &#25226;&#38271; Java &#23383;&#31526;&#20018;&#26144;&#23556;&#20026; SQL &#30340; CLOB &#25110;&#32773; TEXT &#31867;&#22411;&#12290;
    </p>
    <p>
      11&#65306;serializable
    </p>
    <p>
      &#25226;&#21487;&#24207;&#21015;&#21270;&#30340; Java &#31867;&#22411;&#26144;&#23556;&#21040;&#23545;&#24212;&#30340; SQL &#20108;&#36827;&#21046;&#31867;&#22411;&#12290;&#20320;&#20063;&#21487;&#20197;&#20026;&#19968;&#20010;&#24182;&#38750;&#40664;&#35748;&#20026;&#22522;&#26412;
    </p>
    <p>
      &#31867;&#22411;&#30340;&#21487;&#24207;&#21015;&#21270; Java &#31867;&#25110;&#32773;&#25509;&#21475;&#25351;&#23450; Hibernate &#31867;&#22411; serializable&#12290;
    </p>
    <p>
      12&#65306;clob, blob
    </p>
    <p>
      JDBC &#31867; java.sql.Clob &#21644; java.sql.Blob&#30340;&#26144;&#23556;&#12290;&#26576;&#20123;&#31243;&#24207;&#21487;&#33021;&#19981;&#36866;&#21512;&#20351;&#29992;&#36825;&#20010;&#31867;&#22411;&#65292;
    </p>
    <p>
      &#22240;&#20026;blob &#21644; clob &#23545;&#35937;&#21487;&#33021;&#22312;&#19968;&#20010;&#20107;&#21153;&#20043;&#22806;&#26159;&#26080;&#27861;&#37325;&#29992;&#30340;&#12290;&#65288;&#32780;&#19988;, &#39537;&#21160;&#31243;&#24207;&#23545;&#36825;&#31181;&#31867;&#22411;
    </p>
    <p>
      &#30340;&#25903;&#25345;&#20805;&#28385;&#30528;&#34917;&#19969;&#21644;&#21069;&#21518;&#30683;&#30462;&#12290;&#65289;
    </p>
    <p>
      13&#65306;imm_date, imm_time, imm_timestamp, imm_calendar, imm_calendar_date,
    </p>
    <p>
      imm_serializable, imm_binary
    </p>
    <p>
      &#19968;&#33324;&#26469;&#35828;&#65292;&#26144;&#23556;&#31867;&#22411;&#34987;&#20551;&#23450;&#20026;&#26159;&#21487;&#21464;&#30340; Java &#31867;&#22411;&#65292;&#21482;&#26377;&#23545;&#19981;&#21487;&#21464; Java &#31867;&#22411;&#65292;Hibernate
    </p>
    <p>
      &#20250;&#37319;&#21462;&#29305;&#23450;&#30340;&#20248;&#21270;&#25514;&#26045;&#65292;&#24212;&#29992;&#31243;&#24207;&#20250;&#25226;&#36825;&#20123;&#23545;&#35937;&#20316;&#20026;&#19981;&#21487;&#21464;&#23545;&#35937;&#22788;&#29702;&#12290;&#27604;&#22914;&#65292;&#20320;&#19981;&#24212;&#35813;&#23545;
    </p>
    <p>
      &#20316;&#20026; imm_timestamp &#26144;&#23556;&#30340; Date &#25191;&#34892; Date.setTime()&#12290;&#35201;&#25913;&#21464;&#23646;&#24615;&#30340;&#20540;&#65292;&#24182;&#19988;&#20445;&#23384;&#36825;
    </p>
    <p>
      &#19968;&#25913;&#21464;&#65292;&#24212;&#29992;&#31243;&#24207;&#24517;&#39035;&#23545;&#36825;&#19968;&#23646;&#24615;&#37325;&#26032;&#35774;&#32622;&#19968;&#20010;&#26032;&#30340;&#65288;&#19981;&#19968;&#26679;&#30340;&#65289;&#23545;&#35937;&#12290;
    </p>
    <p>
      &#22312; org.hibernate.Hibernate &#20013;&#65292;&#23450;&#20041;&#20102;&#22522;&#30784;&#31867;&#22411;&#23545;&#24212;&#30340; Type &#24120;&#37327;&#12290;&#27604;&#22914;&#65292;
    </p>
    <p>
      Hibernate.STRING &#20195;&#34920; string &#31867;&#22411;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491303905143" FOLDED="true" ID="ID_1402618351" MODIFIED="1491303970519" TEXT="composite-id&#x5143;&#x7d20;">
<node CREATED="1491303921655" ID="ID_1422340994" MODIFIED="1491303969354">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;composite-id&#20803;&#32032;
    </p>
    <p>
      &#22914;&#26524;&#34920;&#20351;&#29992;&#32852;&#21512;&#20027;&#38190;&#65292;&#20320;&#21487;&#20197;&#26144;&#23556;&#31867;&#30340;&#22810;&#20010;&#23646;&#24615;&#20026;&#26631;&#35782;&#31526;&#23646;&#24615;&#12290;&#36825;&#31181;&#20570;&#27861;
    </p>
    <p>
      &#29616;&#22312;&#26159;&#38750;&#24120;&#19981;&#25512;&#33616;&#30340;&#65292;&#20294;&#21487;&#33021;&#26377;&#20123;&#36951;&#30041;&#31995;&#32479;&#20351;&#29992;&#20102;&#21452;&#20027;&#38190;&#25110;&#22810;&#20027;&#38190;&#12290;
    </p>
    <p>
      &#37197;&#32622;&#22914;&#19979;&#31034;&#20363;&#65306;
    </p>
    <p>
      &lt;composite-id&gt;
    </p>
    <p>
      &lt;key-property name=&#8220;name&quot;/&gt;
    </p>
    <p>
      &lt;key-property name=&quot;deptment&quot;/&gt;
    </p>
    <p>
      &lt;/composite-id&gt;
    </p>
    <p>
      &#23601;&#34920;&#31034;&#26159;&#19968;&#20010;&#21452;&#20027;&#38190;&#65292;&#30001;name&#21644;deptment&#32852;&#21512;&#26469;&#20570;&#20027;&#38190;
    </p>
    <p>
      &#20351;&#29992;Composite-id&#20803;&#32032;&#30340;&#26102;&#20505;&#65292;&#20320;&#30340;&#25345;&#20037;&#21270;&#31867;&#24517;&#39035;&#35206;&#30422; equals() &#21644; hashCode()
    </p>
    <p>
      &#26041;&#27861;&#65292;&#26469;&#23454;&#29616;&#32452;&#21512;&#30340;&#26631;&#35782;&#31526;&#30340;&#30456;&#31561;&#21028;&#26029;&#12290;&#23454;&#29616;Serializable &#25509;&#21475;&#20063;&#26159;&#24517;&#39035;&#30340;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491303972983" FOLDED="true" ID="ID_921996575" MODIFIED="1491304007958" TEXT="generator&#x5143;&#x7d20;">
<node CREATED="1491303981967" ID="ID_1218562068" MODIFIED="1491304007063">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21487;&#36873;&#30340;&lt;generator&gt;&#23376;&#20803;&#32032;&#26159;&#19968;&#20010;Java&#31867;&#30340;&#21517;&#23383;&#65292;&#29992;&#26469;&#20026;&#35813;&#25345;&#20037;&#21270;&#31867;&#30340;&#23454;&#20363;
    </p>
    <p>
      &#29983;&#25104;&#21807;&#19968;&#30340;&#26631;&#35782;&#12290;&#22914;&#26524;&#36825;&#20010;&#29983;&#25104;&#22120;&#23454;&#20363;&#38656;&#35201;&#26576;&#20123;&#37197;&#32622;&#20540;&#25110;&#32773;&#21021;&#22987;&#21270;&#21442;&#25968;&#65292; &#29992;
    </p>
    <p>
      &lt;param&gt;&#20803;&#32032;&#26469;&#20256;&#36882;&#12290;&#22914;&#19979;&#31034;&#20363;&#65306;
    </p>
    <p>
      &lt;id name=&quot;id&quot; type=&quot;long&quot; column=&quot;person_id&quot;&gt;
    </p>
    <p>
      &lt;generator class=&quot;sequence&quot;&gt;
    </p>
    <p>
      &lt;param name=&quot;sequence&quot;&gt;person_id_sequence&lt;/param&gt;
    </p>
    <p>
      &lt;/generator&gt;
    </p>
    <p>
      &lt;/id&gt;
    </p>
    <p>
      &#19979;&#38754;&#26159;&#19968;&#20123;Hibernate&#20869;&#32622;&#29983;&#25104;&#22120;&#65306;
    </p>
    <p>
      ? increment
    </p>
    <p>
      &#29992;&#20110;&#20026;long, short&#25110;&#32773;int&#31867;&#22411;&#29983;&#25104; &#21807;&#19968;&#26631;&#35782;&#12290;&#21482;&#26377;&#22312;&#27809;&#26377;&#20854;&#20182;&#36827;&#31243;&#24448;&#21516;
    </p>
    <p>
      &#19968;&#24352;&#34920;&#20013;&#25554;&#20837;&#25968;&#25454;&#26102;&#25165;&#33021;&#20351;&#29992;&#12290; &#22312;&#38598;&#32676;&#19979;&#19981;&#35201;&#20351;&#29992;&#12290;
    </p>
    <p>
      ? identity
    </p>
    <p>
      &#23545;DB2,MySQL, MS SQL Server, Sybase&#21644;HypersonicSQL&#30340;&#20869;&#32622;&#26631;&#35782;&#23383;&#27573;&#25552;
    </p>
    <p>
      &#20379;&#25903;&#25345;&#12290; &#36820;&#22238;&#30340;&#26631;&#35782;&#31526;&#26159;long, short &#25110;&#32773;int&#31867;&#22411;&#30340;&#12290;
    </p>
    <p>
      &#160;Sequence
    </p>
    <p>
      &#22312;DB2,PostgreSQL, Oracle, SAP DB, McKoi&#20013;&#20351;&#29992;sequence&#65292; &#32780;&#22312;
    </p>
    <p>
      Interbase&#20013;&#20351;&#29992;&#29983;&#25104;&#22120;(generator)&#12290;&#36820;&#22238;&#30340;&#26631;&#35782;&#31526;&#26159;long, short&#25110;int&#31867;&#22411;&#30340;
    </p>
    <p>
      ? hilo
    </p>
    <p>
      &#20351;&#29992;&#19968;&#20010;&#39640;/&#20302;&#20301;&#31639;&#27861;&#39640;&#25928;&#30340;&#29983;&#25104;long, short &#25110;&#32773; int&#31867;&#22411;&#30340;&#26631;&#35782;&#31526;&#12290;&#32473;
    </p>
    <p>
      &#23450;&#19968;&#20010;&#34920;&#21644;&#23383;&#27573;&#65288;&#40664;&#35748;&#20998;&#21035;&#26159; hibernate_unique_key &#21644;next_hi&#65289;&#20316;&#20026;&#39640;&#20301;&#20540;
    </p>
    <p>
      &#30340;&#26469;&#28304;&#12290; &#39640;/&#20302;&#20301;&#31639;&#27861;&#29983;&#25104;&#30340;&#26631;&#35782;&#31526;&#21482;&#22312;&#19968;&#20010;&#29305;&#23450;&#30340;&#25968;&#25454;&#24211;&#20013;&#26159;&#21807;&#19968;&#30340;&#12290;
    </p>
    <p>
      ? Seqhilo
    </p>
    <p>
      &#20351;&#29992;&#19968;&#20010;&#39640;/&#20302;&#20301;&#31639;&#27861;&#26469;&#39640;&#25928;&#30340;&#29983;&#25104;long, short &#25110;&#32773; int&#31867;&#22411;&#30340;&#26631;&#35782;&#31526;&#65292;
    </p>
    <p>
      &#32473;&#23450;&#19968;&#20010;&#25968;&#25454;&#24211;&#24207;&#21015;&#65288;sequence)&#30340;&#21517;&#23383;&#12290;
    </p>
    <p>
      ? Uuid
    </p>
    <p>
      &#29992;&#19968;&#20010;128-bit&#30340;UUID&#31639;&#27861;&#29983;&#25104;&#23383;&#31526;&#20018;&#31867;&#22411;&#30340;&#26631;&#35782;&#31526;&#65292; &#36825;&#22312;&#19968;&#20010;&#32593;&#32476;&#20013;&#26159;
    </p>
    <p>
      &#21807;&#19968;&#30340;&#65288;&#20351;&#29992;&#20102;IP&#22320;&#22336;&#65289;&#12290;UUID&#34987;&#32534;&#30721;&#20026;&#19968;&#20010;32&#20301;16&#36827;&#21046;&#25968;&#23383;&#30340;&#23383;&#31526;&#20018;&#12290;
    </p>
    <p>
      ? guid
    </p>
    <p>
      &#22312;MS SQL Server &#21644; MySQL &#20013;&#20351;&#29992;&#25968;&#25454;&#24211;&#29983;&#25104;&#30340;GUID&#23383;&#31526;&#20018;
    </p>
    <p>
      native
    </p>
    <p>
      &#26681;&#25454;&#24213;&#23618;&#25968;&#25454;&#24211;&#30340;&#33021;&#21147;&#36873;&#25321;identity, sequence &#25110;&#32773;hilo&#20013;&#30340;&#19968;&#20010;&#12290;
    </p>
    <p>
      ? Assigned
    </p>
    <p>
      &#35753;&#24212;&#29992;&#31243;&#24207;&#22312;save()&#20043;&#21069;&#20026;&#23545;&#35937;&#20998;&#37197;&#19968;&#20010;&#26631;&#31034;&#31526;&#12290;&#36825;&#26159; &lt;generator&gt;&#20803;&#32032;
    </p>
    <p>
      &#27809;&#26377;&#25351;&#23450;&#26102;&#30340;&#40664;&#35748;&#29983;&#25104;&#31574;&#30053;&#12290;
    </p>
    <p>
      ? select
    </p>
    <p>
      &#36890;&#36807;&#25968;&#25454;&#24211;&#35302;&#21457;&#22120;&#36873;&#25321;&#19968;&#20123;&#21807;&#19968;&#20027;&#38190;&#30340;&#34892;&#24182;&#36820;&#22238;&#20027;&#38190;&#20540;&#26469;&#20998;&#37197;&#19968;&#20010;&#20027;&#38190;&#12290;
    </p>
    <p>
      ? foreign
    </p>
    <p>
      &#20351;&#29992;&#21478;&#22806;&#19968;&#20010;&#30456;&#20851;&#32852;&#30340;&#23545;&#35937;&#30340;&#26631;&#35782;&#31526;&#12290;&#36890;&#24120;&#21644;&lt;one-to-one&gt;&#32852;&#21512;&#36215;&#26469;&#20351;&#29992;
    </p>
    <p>
      ? &#25512;&#33616;&#20351;&#29992;UUID
    </p>
    <p>
      UUID &#21253;&#21547;&#65306;IP &#22320;&#22336;&#12289;JVM &#30340;&#21551;&#21160;&#26102;&#38388;&#65288;&#31934;&#30830;&#21040; 1/4 &#31186;&#65289;&#12289;&#31995;&#32479;&#26102;&#38388;&#21644;&#19968;
    </p>
    <p>
      &#20010;&#35745;&#25968;&#22120;&#20540;&#65288;&#22312; JVM &#20013;&#21807;&#19968;&#65289;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491304014935" FOLDED="true" ID="ID_593671477" MODIFIED="1491304692561" TEXT="property&#x5143;&#x7d20;">
<node CREATED="1491304018103" ID="ID_1046094668" MODIFIED="1491304080800">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &lt;property&gt;&#20803;&#32032;&#20026;&#31867;&#23450;&#20041;&#20102;&#19968;&#20010;&#25345;&#20037;&#21270;&#30340;,JavaBean&#39118;&#26684;&#30340;&#23646;&#24615;&#12290;
    </p>
    <p>
      &lt;property
    </p>
    <p>
      name=&quot;propertyName&quot; (1)
    </p>
    <p>
      column=&quot;column_name&quot; (2)
    </p>
    <p>
      type=&quot;typename&quot; (3)
    </p>
    <p>
      update=&quot;true|false&quot; (4)
    </p>
    <p>
      insert=&quot;true|false&quot; (5)
    </p>
    <p>
      formula=&quot;arbitrary SQL expression&quot; (6)
    </p>
    <p>
      access=&quot;field|property|ClassName&quot; (7)
    </p>
    <p>
      lazy=&quot;true|false&quot; (8)
    </p>
    <p>
      unique=&quot;true|false&quot; (9)
    </p>
    <p>
      not-null=&quot;true|false&quot; (10)
    </p>
    <p>
      optimistic-lock=&quot;true|false&quot; (11)
    </p>
    <p>
      generated=&quot;never|insert|always&quot; (12)
    </p>
    <p>
      /&gt;
    </p>
    <p>
      (1) name: &#23646;&#24615;&#30340;&#21517;&#23383;,&#20197;&#23567;&#20889;&#23383;&#27597;&#24320;&#22836;
    </p>
    <p>
      (2) column (&#21487;&#36873; - &#40664;&#35748;&#20026;&#23646;&#24615;&#21517;&#23383;): &#23545;&#24212;&#30340;&#25968;&#25454;&#24211;&#23383;&#27573;&#21517;&#12290;&#20063;&#21487;&#20197;&#36890;&#36807;&#23884;&#22871;&#30340;
    </p>
    <p>
      &lt;column&gt;&#20803;&#32032;&#25351;&#23450;&#12290;
    </p>
    <p>
      (3) type (&#21487;&#36873;): &#19968;&#20010;Hibernate&#31867;&#22411;&#30340;&#21517;&#23383;&#12290;
    </p>
    <p>
      typename&#21487;&#20197;&#26159;&#22914;&#19979;&#20960;&#31181;&#65306;
    </p>
    <p>
      A&#65306;Hibernate&#22522;&#26412;&#31867;&#22411;&#21517;&#65288;&#27604;&#22914;&#65306;integer, string, character&#65292;date, timestamp,
    </p>
    <p>
      float, binary, serializable, object, blob&#65289;&#12290;
    </p>
    <p>
      B&#65306;&#19968;&#20010;Java&#31867;&#30340;&#21517;&#23383;&#65292;&#36825;&#20010;&#31867;&#23646;&#20110;&#19968;&#31181;&#40664;&#35748;&#22522;&#30784;&#31867;&#22411; (&#27604;&#22914;&#65306; int, float,char,
    </p>
    <p>
      java.lang.String, java.util.Date, java.lang.Integer, java.sql.Clob)&#12290;
    </p>
    <p>
      C&#65306;&#19968;&#20010;&#21487;&#20197;&#24207;&#21015;&#21270;&#30340;Java&#31867;&#30340;&#21517;&#23383;&#12290;
    </p>
    <p>
      D&#65306;&#19968;&#20010;&#33258;&#23450;&#20041;&#31867;&#22411;&#30340;&#31867;&#30340;&#21517;&#23383;&#12290;&#65288;&#27604;&#22914;&#65306;cn.javass.type.MyCustomType)&#12290;
    </p>
    <p>
      &#22914;&#26524;&#20320;&#27809;&#26377;&#25351;&#23450;&#31867;&#22411;&#65292;Hibernarte&#20250;&#20351;&#29992;&#21453;&#23556;&#26469;&#24471;&#21040;&#36825;&#20010;&#21517;&#23383;&#30340;&#23646;&#24615;&#65292;&#20197;&#27492;&#26469;&#29468;
    </p>
    <p>
      &#27979;&#27491;&#30830;&#30340;Hibernate&#31867;&#22411;&#12290; Hibernate&#20250;&#25353;&#29031;&#35268;&#21017;B,C,D&#30340;&#39034;&#24207;&#23545;&#23646;&#24615;&#35835;&#21462;&#22120;
    </p>
    <p>
      (getter&#26041;&#27861;&#65289;&#30340;&#36820;&#22238;&#31867;&#36827;&#34892;&#35299;&#37322;&#12290;&#28982;&#32780;&#65292;&#36825;&#36824;&#19981;&#22815;&#12290; &#22312;&#26576;&#20123;&#24773;&#20917;&#19979;&#20320;&#20173;&#28982;&#38656;&#35201;
    </p>
    <p>
      type&#23646;&#24615;&#12290;&#65288;&#27604;&#22914;&#65292;&#20026;&#20102;&#21306;&#21035;Hibernate.DATE &#21644;Hibernate.TIMESTAMP,&#25110;&#32773;&#20026;
    </p>
    <p>
      &#20102;&#25351;&#23450;&#19968;&#20010;&#33258;&#23450;&#20041;&#31867;&#22411;&#12290;&#65289;
    </p>
    <p>
      (4) update, insert (&#21487;&#36873; - &#40664;&#35748;&#20026; true) : &#34920;&#26126;&#29992;&#20110;UPDATE &#21644;/&#25110; INSERT &#30340;
    </p>
    <p>
      SQL&#35821;&#21477;&#20013;&#26159;&#21542;&#21253;&#21547;&#36825;&#20010;&#34987;&#26144;&#23556;&#20102;&#30340;&#23383;&#27573;&#12290;&#36825;&#20108;&#32773;&#22914;&#26524;&#37117;&#35774;&#32622;&#20026;false &#21017;&#34920;&#26126;&#36825;
    </p>
    <p>
      &#26159;&#19968;&#20010;&#8220;&#22806;&#28304;&#24615;&#65288;derived&#65289;&#8221;&#30340;&#23646;&#24615;&#65292;&#23427;&#30340;&#20540;&#26469;&#28304;&#20110;&#26144;&#23556;&#21040;&#21516;&#19968;&#20010;&#65288;&#25110;&#22810;&#20010;&#65289;
    </p>
    <p>
      &#23383;&#27573;&#30340;&#26576;&#20123;&#20854;&#20182;&#23646;&#24615;&#65292;&#25110;&#32773;&#36890;&#36807;&#19968;&#20010;trigger(&#35302;&#21457;&#22120;&#65289;&#25110;&#20854;&#20182;&#31243;&#24207;&#29983;&#25104;&#12290;
    </p>
    <p>
      (5) formula (&#21487;&#36873;): &#19968;&#20010;SQL&#34920;&#36798;&#24335;&#65292;&#23450;&#20041;&#20102;&#36825;&#20010;&#35745;&#31639;&#23646;&#24615;&#30340;&#20540;&#12290;&#35745;&#31639;&#23646;&#24615;&#27809;&#26377;&#21644;
    </p>
    <p>
      &#23427;&#23545;&#24212;&#30340;&#25968;&#25454;&#24211;&#23383;&#27573;&#65292;&#30456;&#24403;&#20110;&#26159;&#19968;&#20010;&#23376;&#26597;&#35810;&#12290;
    </p>
    <p>
      (6) access (&#21487;&#36873; &#8211; &#40664;&#35748;&#20540;property): Hibernate&#35775;&#38382;&#23646;&#24615;&#20540;&#30340;&#31574;&#30053;
    </p>
    <p>
      access&#23646;&#24615;&#29992;&#26469;&#35753;&#20320;&#25511;&#21046;Hibernate&#22914;&#20309;&#22312;&#36816;&#34892;&#26102;&#35775;&#38382;&#23646;&#24615;&#12290;&#22312;&#40664;&#35748;&#24773;&#20917;&#19979;&#65292;
    </p>
    <p>
      Hibernate&#20250;&#20351;&#29992;&#23646;&#24615;&#30340;get/set&#26041;&#27861;&#23545;&#12290;&#22914;&#26524;&#20320;&#25351;&#26126;access=&quot;field&quot;,
    </p>
    <p>
      Hibernate&#20250;&#24573;&#30053;get/set&#26041;&#27861;&#23545;&#65292;&#30452;&#25509;&#20351;&#29992;&#21453;&#23556;&#26469;&#35775;&#38382;&#25104;&#21592;&#21464;&#37327;&#12290;&#20320;&#20063;&#21487;&#20197;&#25351;&#23450;
    </p>
    <p>
      &#20320;&#33258;&#24049;&#30340;&#31574;&#30053;&#65292; &#36825;&#23601;&#38656;&#35201;&#20320;&#33258;&#24049;&#23454;&#29616;
    </p>
    <p>
      org.hibernate.property.PropertyAccessor&#25509;&#21475;&#65292; &#20877;&#22312;access&#20013;&#35774;&#32622;&#20320;&#33258;&#23450;&#20041;
    </p>
    <p>
      &#31574;&#30053;&#31867;&#30340;&#21517;&#23383;&#12290;
    </p>
    <p>
      (7) lazy (&#21487;&#36873; - &#40664;&#35748;&#20026; false): &#25351;&#23450; &#25351;&#23450;&#23454;&#20363;&#21464;&#37327;&#31532;&#19968;&#27425;&#34987;&#35775;&#38382;&#26102;&#65292;&#36825;&#20010;&#23646;&#24615;
    </p>
    <p>
      &#26159;&#21542;&#24310;&#36831;&#25235;&#21462;&#65288;fetched lazily&#65289;&#65288; &#38656;&#35201;&#36816;&#34892;&#26102;&#23383;&#33410;&#30721;&#22686;&#24378;&#65289;&#12290;
    </p>
    <p>
      (8) unique (&#21487;&#36873;): &#20351;&#29992;DDL&#20026;&#35813;&#23383;&#27573;&#28155;&#21152;&#21807;&#19968;&#30340;&#32422;&#26463;&#12290; &#21516;&#26679;&#65292;&#20801;&#35768;&#23427;&#20316;&#20026;
    </p>
    <p>
      property-ref&#24341;&#29992;&#30340;&#30446;&#26631;&#12290;
    </p>
    <p>
      (9) not-null (&#21487;&#36873;): &#20351;&#29992;DDL&#20026;&#35813;&#23383;&#27573;&#28155;&#21152;&#21487;&#21542;&#20026;&#31354;&#65288;nullability&#65289;&#30340;&#32422;&#26463;&#12290;
    </p>
    <p>
      (10) optimistic-lock (&#21487;&#36873; - &#40664;&#35748;&#20026; true): &#25351;&#23450;&#36825;&#20010;&#23646;&#24615;&#22312;&#20570;&#26356;&#26032;&#26102;&#26159;&#21542;&#38656;&#35201;
    </p>
    <p>
      &#33719;&#24471;&#20048;&#35266;&#38145;&#23450;&#65288;optimistic lock&#65289;&#12290; &#25442;&#21477;&#35805;&#35828;&#65292;&#23427;&#20915;&#23450;&#36825;&#20010;&#23646;&#24615;&#21457;&#29983;&#33039;&#25968;&#25454;&#26102;
    </p>
    <p>
      &#29256;&#26412;&#65288;version&#65289;&#30340;&#20540;&#26159;&#21542;&#22686;&#38271;&#12290;
    </p>
    <p>
      (11) generated (&#21487;&#36873; &#8211; &#40664;&#35748;&#20540;never): &#34920;&#26126;&#27492;&#23646;&#24615;&#20540;&#26159;&#21542;&#30001;&#25968;&#25454;&#24211;&#29983;&#25104;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491304798520" FOLDED="true" ID="ID_22908790" MODIFIED="1491304958304" TEXT="component&#x5143;&#x7d20;">
<node CREATED="1491304804978" ID="ID_238288946" MODIFIED="1491304955091">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &lt;component&gt; &#20803;&#32032;&#25226;&#23376;&#23545;&#35937;&#30340;&#19968;&#20123;&#20803;&#32032;&#19982;&#29238;&#31867;&#23545;&#24212;&#30340;&#34920;&#30340;&#19968;&#20123;&#23383;&#27573;&#26144;&#23556;&#36215;
    </p>
    <p>
      &#26469;&#12290;&#28982;&#21518;&#32452;&#20214;&#21487;&#20197;&#23450;&#20041;&#23427;&#20204;&#33258;&#24049;&#30340;&#23646;&#24615;&#12289;&#32452;&#20214;&#25110;&#32773;&#38598;&#21512;&#12290;
    </p>
    <p>
      &lt;component
    </p>
    <p>
      name=&quot;propertyName&quot;(1)
    </p>
    <p>
      class=&quot;className&quot;(2)
    </p>
    <p>
      insert=&quot;true|false&quot;(3)
    </p>
    <p>
      update=&quot;true|false&quot;(4)
    </p>
    <p>
      access=&quot;field|property|ClassName&quot;(5)
    </p>
    <p>
      lazy=&quot;true|false&quot;(6)
    </p>
    <p>
      optimistic-lock=&quot;true|false&quot;(7)
    </p>
    <p>
      unique=&quot;true|false&quot;(8)
    </p>
    <p>
      &gt;
    </p>
    <p>
      &lt;property ...../&gt;
    </p>
    <p>
      &lt;many-to-one .... /&gt;
    </p>
    <p>
      &lt;/component&gt;
    </p>
    <p>
      (1)name&#65306;&#23646;&#24615;&#21517;&#12290;
    </p>
    <p>
      (2)class&#65288;&#21487;&#36873; &#8212; &#40664;&#35748;&#20026;&#36890;&#36807;&#21453;&#23556;&#24471;&#21040;&#30340;&#23646;&#24615;&#31867;&#22411;&#65289;&#65306;&#32452;&#20214;&#65288;&#23376;&#65289;&#31867;&#30340;&#21517;&#23383;&#12290;
    </p>
    <p>
      (3)insert&#65306;&#34987;&#26144;&#23556;&#30340;&#23383;&#27573;&#26159;&#21542;&#20986;&#29616;&#22312; SQL &#30340; INSERT &#35821;&#21477;&#20013;&#65311;
    </p>
    <p>
      (4)update&#65306;&#34987;&#26144;&#23556;&#30340;&#23383;&#27573;&#26159;&#21542;&#20986;&#29616;&#22312; SQL &#30340; UPDATE &#35821;&#21477;&#20013;&#65311;
    </p>
    <p>
      (5)access&#65288;&#21487;&#36873; &#8212; &#40664;&#35748;&#20026; property&#65289;&#65306;Hibernate &#29992;&#26469;&#35775;&#38382;&#23646;&#24615;&#20540;&#30340;&#31574;&#30053;&#12290;
    </p>
    <p>
      (6)lazy&#65288;&#21487;&#36873; &#8212; &#40664;&#35748;&#26159; false&#65289;&#65306;&#34920;&#26126;&#27492;&#32452;&#20214;&#24212;&#22312;&#23454;&#20363;&#21464;&#37327;&#31532;&#19968;&#27425;&#34987;&#35775;&#38382;&#30340;&#26102;&#20505;
    </p>
    <p>
      &#24310;&#36831;&#21152;&#36733;&#65288;&#38656;&#35201;&#32534;&#35793;&#26102;&#23383;&#33410;&#30721;&#35013;&#32622;&#22120;&#65289;&#12290;
    </p>
    <p>
      (7)optimistic-lock&#65288;&#21487;&#36873; &#8212; &#40664;&#35748;&#26159; true&#65289;&#65306;&#34920;&#26126;&#26356;&#26032;&#27492;&#32452;&#20214;&#26159;&#21542;&#38656;&#35201;&#33719;&#21462;&#20048;&#35266;
    </p>
    <p>
      &#38145;&#12290;&#25442;&#21477;&#35805;&#35828;&#65292;&#24403;&#36825;&#20010;&#23646;&#24615;&#21464;&#33039;&#26102;&#65292;&#26159;&#21542;&#22686;&#21152;&#29256;&#26412;&#21495;&#65288;Version&#65289;&#12290;
    </p>
    <p>
      (8)unique&#65288;&#21487;&#36873; &#8212; &#40664;&#35748;&#26159; false&#65289;&#65306;&#34920;&#26126;&#32452;&#20214;&#26144;&#23556;&#30340;&#25152;&#26377;&#23383;&#27573;&#19978;&#37117;&#26377;&#21807;&#19968;&#24615;&#32422;
    </p>
    <p>
      &#26463;&#12290;
    </p>
    <p>
      &#20854; &lt;property&gt; &#23376;&#26631;&#31614;&#20026;&#23376;&#31867;&#30340;&#19968;&#20123;&#23646;&#24615;&#19982;&#34920;&#23383;&#27573;&#20043;&#38388;&#24314;&#31435;&#26144;&#23556;&#12290;
    </p>
    <p>
      &#32452;&#20214;(Component) &#26159;&#19968;&#20010;&#34987;&#21253;&#21547;&#30340;&#23545;&#35937;&#65292;&#22312;&#25345;&#20037;&#21270;&#30340;&#36807;&#31243;&#20013;&#65292;&#23427;&#34987;&#24403;&#20316;&#20540;&#31867;&#22411;&#65292;
    </p>
    <p>
      &#32780;&#24182;&#38750;&#19968;&#20010;&#23454;&#20307;&#30340;&#24341;&#29992;&#65292;&#25351;&#30340;&#26159;&#23545;&#35937;&#30340;&#21512;&#25104;&#12290;&#20351;&#29992;&#31034;&#20363;&#22914;&#19979;&#65306;
    </p>
    <p>
      1&#65306;&#26032;&#24314;&#19968;&#20010;PersonModel&#65292;&#21253;&#21547;&#23383;&#27573;&#65306;userId&#21644;name
    </p>
    <p>
      2&#65306;&#20462;&#25913;UserModel&#65292;&#22312;&#37324;&#38754;&#21435;&#25481;userId&#21644;name&#65292;&#28982;&#21518;&#28155;&#21152;&#19968;&#20010;&#23383;&#27573;&#65306;p&#65292;&#31867;&#22411;&#20026;PersonModel&#65292;
    </p>
    <p>
      &#20063;&#35201;&#23545;&#24212;&#30340;getter&#21644;setter&#26041;&#27861;
    </p>
    <p>
      3&#65306;&#22312;UserModel.hbm.xml&#20013;&#20462;&#25913;&#37197;&#32622;&#22914;&#19979;&#65306;
    </p>
    <p>
      &lt;hibernate-mapping&gt;
    </p>
    <p>
      &lt;class name=&quot;cn.javass.h3.hello.UserModel&quot; table=&quot;tbl_user&quot;&gt;
    </p>
    <p>
      &lt;id name=&quot;uuid&quot;&gt;
    </p>
    <p>
      &lt;generator class=&quot;assigned&quot;/&gt;
    </p>
    <p>
      &lt;/id&gt;
    </p>
    <p>
      &lt;component name=&quot;p&quot; class=&quot;cn.javass.h3.hello.PersonModel&quot;&gt;
    </p>
    <p>
      &lt;property name=&quot;userId&quot;&gt;&lt;/property&gt;
    </p>
    <p>
      &lt;property name=&quot;name&quot;&gt;&lt;/property&gt;
    </p>
    <p>
      &lt;/component&gt;
    </p>
    <p>
      &lt;property name=&quot;age&quot;&gt;&lt;/property&gt;
    </p>
    <p>
      &lt;/class&gt;
    </p>
    <p>
      &lt;/hibernate-mapping&gt;
    </p>
    <p>
      4&#65306;&#30456;&#24212;&#30340;&#20462;&#25913;Client&#25991;&#20214;&#22914;&#19979;&#65306;
    </p>
    <p>
      //&#20934;&#22791;&#25968;&#25454;
    </p>
    <p>
      UserModel um = new UserModel();
    </p>
    <p>
      um.setUuid(&quot;13&quot;);
    </p>
    <p>
      um.setAge(1);
    </p>
    <p>
      PersonModel pm = new PersonModel();
    </p>
    <p>
      pm.setUserId(&quot;id1&quot;);
    </p>
    <p>
      pm.setName(&quot;name1&quot;);
    </p>
    <p>
      um.setP(pm);
    </p>
    <p>
      5&#65306;&#36816;&#34892;&#27979;&#35797;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491305083199" FOLDED="true" ID="ID_1372748763" MODIFIED="1491305122487" TEXT="join&#x5143;&#x7d20;">
<node CREATED="1491305088455" ID="ID_1347226245" MODIFIED="1491305121342">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;&lt;join&gt;&#20803;&#32032;
    </p>
    <p>
      &#20351;&#29992; &lt;join&gt; &#20803;&#32032;&#65292;&#20551;&#33509;&#22312;&#34920;&#20043;&#38388;&#23384;&#22312;&#19968;&#23545;&#19968;&#20851;&#32852;,&#21487;&#20197;&#23558;&#19968;&#20010;&#31867;&#30340;&#23646;&#24615;&#26144;&#23556;&#21040;
    </p>
    <p>
      &#22810;&#24352;&#34920;&#20013;&#12290;
    </p>
    <p>
      &lt;join
    </p>
    <p>
      table=&quot;tablename&quot;(1)
    </p>
    <p>
      schema=&quot;owner&quot;(2)
    </p>
    <p>
      catalog=&quot;catalog&quot;(3)
    </p>
    <p>
      fetch=&quot;join|select&quot;(4)
    </p>
    <p>
      inverse=&quot;true|false&quot;(5)
    </p>
    <p>
      optional=&quot;true|false&quot;(6)
    </p>
    <p>
      &gt;
    </p>
    <p>
      &lt;key ... /&gt;
    </p>
    <p>
      &lt;property ... /&gt;
    </p>
    <p>
      &lt;/join&gt;
    </p>
    <p>
      (1)table&#65306;&#34987;&#36830;&#25509;&#34920;&#30340;&#21517;&#31216;&#12290;
    </p>
    <p>
      (2)schema&#65288;&#21487;&#36873;&#65289;&#65306;&#35206;&#30422;&#22312;&#26681; &lt;hibernate-mapping&gt; &#20803;&#32032;&#20013;&#25351;&#23450;&#30340;schema&#21517;&#23383;&#12290;
    </p>
    <p>
      (3)catalog&#65288;&#21487;&#36873;&#65289;&#65306;&#35206;&#30422;&#22312;&#26681;&lt;hibernate-mapping&gt; &#20803;&#32032;&#20013;&#25351;&#23450;&#30340;catalog&#21517;&#23383;&#12290;
    </p>
    <p>
      (4)fetch&#65288;&#21487;&#36873; &#8212; &#40664;&#35748;&#26159; join&#65289;&#65306;&#22914;&#26524;&#35774;&#32622;&#20026;&#40664;&#35748;&#20540; join&#65292;Hibernate &#23558;&#20351;&#29992;
    </p>
    <p>
      &#19968;&#20010;&#20869;&#36830;&#25509;&#26469;&#24471;&#21040;&#36825;&#20010;&#31867;&#25110;&#20854;&#36229;&#31867;&#23450;&#20041;&#30340; &lt;join&gt;&#65292;&#32780;&#20351;&#29992;&#19968;&#20010;&#22806;&#36830;&#25509;&#26469;&#24471;&#21040;&#20854;
    </p>
    <p>
      &#23376;&#31867;&#23450;&#20041;&#30340; &lt;join&gt;&#12290;&#22914;&#26524;&#35774;&#32622;&#20026; select&#65292;&#21017; Hibernate &#23558;&#20026;&#23376;&#31867;&#23450;&#20041;&#30340;
    </p>
    <p>
      &lt;join&gt; &#20351;&#29992;&#39034;&#24207;&#36873;&#25321;&#12290;&#36825;&#20165;&#22312;&#19968;&#34892;&#25968;&#25454;&#34920;&#31034;&#19968;&#20010;&#23376;&#31867;&#30340;&#23545;&#35937;&#30340;&#26102;&#20505;&#25165;&#20250;&#21457;&#29983;&#12290;
    </p>
    <p>
      &#23545;&#36825;&#20010;&#31867;&#21644;&#20854;&#36229;&#31867;&#23450;&#20041;&#30340; &lt;join&gt;&#65292;&#20381;&#28982;&#20250;&#20351;&#29992;&#20869;&#36830;&#25509;&#24471;&#21040;&#12290;
    </p>
    <p>
      (5)inverse&#65288;&#21487;&#36873; &#8212; &#40664;&#35748;&#26159; false&#65289;&#65306;&#22914;&#26524;&#25171;&#24320;&#65292;Hibernate &#19981;&#20250;&#25554;&#20837;&#25110;&#32773;&#26356;&#26032;
    </p>
    <p>
      &#27492;&#36830;&#25509;&#23450;&#20041;&#30340;&#23646;&#24615;&#12290;
    </p>
    <p>
      (6)optional&#65288;&#21487;&#36873; &#8212; &#40664;&#35748;&#26159; false&#65289;&#65306;&#22914;&#26524;&#25171;&#24320;&#65292;Hibernate &#21482;&#20250;&#22312;&#27492;&#36830;&#25509;&#23450;&#20041;
    </p>
    <p>
      &#30340;&#23646;&#24615;&#38750;&#31354;&#26102;&#25554;&#20837;&#19968;&#34892;&#25968;&#25454;&#65292;&#24182;&#19988;&#24635;&#26159;&#20351;&#29992;&#19968;&#20010;&#22806;&#36830;&#25509;&#26469;&#24471;&#21040;&#36825;&#20123;&#23646;&#24615;&#12290;
    </p>
    <p>
      
    </p>
    <p>
      &#20363;&#22914;&#65292;&#19968;&#20010;&#20154;&#65288;person&#65289;&#30340;&#22320;&#22336;&#65288;address&#65289;&#20449;&#24687;&#21487;&#20197;&#34987;&#26144;&#23556;&#21040;&#21333;&#29420;&#30340;&#34920;&#20013;&#65288;&#24182;&#20445;&#30041;
    </p>
    <p>
      &#25152;&#26377;&#23646;&#24615;&#30340;&#20540;&#31867;&#22411;&#35821;&#20041;&#65289;&#65306;
    </p>
    <p>
      &lt;class name=&quot;Person&quot;
    </p>
    <p>
      table=&quot;PERSON&quot;&gt;
    </p>
    <p>
      &lt;id name=&quot;id&quot; column=&quot;PERSON_ID&quot;
    </p>
    <p>
      &gt;...&lt;/id&gt;
    </p>
    <p>
      &lt;join table=&quot;ADDRESS&quot;&gt;
    </p>
    <p>
      &lt;key column=&quot;ADDRESS_ID&quot;/&gt;
    </p>
    <p>
      &lt;property name=&quot;address&quot;/&gt;
    </p>
    <p>
      &lt;property name=&quot;zip&quot;/&gt;
    </p>
    <p>
      &lt;property name=&quot;country&quot;/&gt;
    </p>
    <p>
      &lt;/join&gt;
    </p>
    <p>
      ...
    </p>
    <p>
      &#27492;&#29305;&#24615;&#24120;&#24120;&#23545;&#36951;&#30041;&#25968;&#25454;&#27169;&#22411;&#26377;&#29992;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491305129006" FOLDED="true" ID="ID_1740700164" MODIFIED="1491305176103" TEXT="properties&#x6620;&#x5c04;">
<node CREATED="1491305140047" ID="ID_324433700" MODIFIED="1491305175212">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &lt;properties&gt;&#20803;&#32032;
    </p>
    <p>
      &lt;properties&gt; &#20803;&#32032;&#20801;&#35768;&#23450;&#20041;&#19968;&#20010;&#21629;&#21517;&#30340;&#36923;&#36753;&#20998;&#32452;&#65288;grouping&#65289;&#21253;&#21547;&#19968;&#20010;&#31867;
    </p>
    <p>
      &#20013;&#30340;&#22810;&#20010;&#23646;&#24615;&#12290;&#36825;&#20010;&#20803;&#32032;&#26368;&#37325;&#35201;&#30340;&#29992;&#22788;&#26159;&#20801;&#35768;&#22810;&#20010;&#23646;&#24615;&#30340;&#32452;&#21512;&#20316;&#20026; property-
    </p>
    <p>
      ref &#30340;&#30446;&#26631;&#65288;target&#65289;&#12290;&#36825;&#20063;&#26159;&#23450;&#20041;&#22810;&#23383;&#27573;&#21807;&#19968;&#32422;&#26463;&#30340;&#19968;&#31181;&#26041;&#20415;&#36884;&#24452;&#12290;
    </p>
    <p>
      ? &#22522;&#26412;&#23450;&#20041;&#22914;&#19979;&#65306;
    </p>
    <p>
      &lt;properties
    </p>
    <p>
      name=&quot;logicalName&quot; (1)
    </p>
    <p>
      insert=&quot;true|false&quot; (2)
    </p>
    <p>
      update=&quot;true|false&quot; (3)
    </p>
    <p>
      optimistic-lock=&quot;true|false&quot; (4)
    </p>
    <p>
      unique=&quot;true|false&quot; (5)
    </p>
    <p>
      &gt;
    </p>
    <p>
      &lt;property ...../&gt;
    </p>
    <p>
      &lt;many-to-one .... /&gt;
    </p>
    <p>
      &lt;/properties&gt;
    </p>
    <p>
      (1)name&#65306;&#20998;&#32452;&#30340;&#36923;&#36753;&#21517;&#31216; &#8212; &#19981;&#26159;&#23454;&#38469;&#23646;&#24615;&#30340;&#21517;&#31216;&#12290;
    </p>
    <p>
      (2)insert&#65306;&#34987;&#26144;&#23556;&#30340;&#23383;&#27573;&#26159;&#21542;&#20986;&#29616;&#22312;SQL&#30340;INSERT&#35821;&#21477;&#20013;
    </p>
    <p>
      (3)update&#65306;&#34987;&#26144;&#23556;&#30340;&#23383;&#27573;&#26159;&#21542;&#20986;&#29616;&#22312;SQL&#30340;UPDATE&#35821;&#21477;&#20013;
    </p>
    <p>
      (4)optimistic-lock&#65288;&#21487;&#36873; &#8212; &#40664;&#35748;&#26159; true&#65289;&#65306;&#34920;&#26126;&#26356;&#26032;&#27492;&#32452;&#20214;&#26159;&#21542;&#38656;&#35201;&#33719;&#21462;&#20048;&#35266;
    </p>
    <p>
      &#38145;&#12290;&#25442;&#21477;&#35805;&#35828;&#65292;&#24403;&#36825;&#20010;&#23646;&#24615;&#21464;&#33039;&#26102;&#65292;&#26159;&#21542;&#22686;&#21152;&#29256;&#26412;&#21495;&#65288;Version&#65289;&#12290;
    </p>
    <p>
      (5)unique&#65288;&#21487;&#36873;&#8212;&#40664;&#35748; false&#65289;&#65306;&#34920;&#26126;&#32452;&#20214;&#26144;&#23556;&#30340;&#25152;&#26377;&#23383;&#27573;&#19978;&#37117;&#26377;&#21807;&#19968;&#24615;&#32422;&#26463;&#12290;
    </p>
    <p>
      ? &lt;properties&gt;&#20803;&#32032;&#30340;&#31616;&#21333;&#31034;&#20363;
    </p>
    <p>
      &lt;properties name=&quot;name&quot;
    </p>
    <p>
      unique=&quot;true&quot; update=&quot;false&quot;&gt;
    </p>
    <p>
      &lt;property name=&quot;firstName&quot;/&gt;
    </p>
    <p>
      &lt;property name=&quot;initial&quot;/&gt;
    </p>
    <p>
      &lt;property name=&quot;lastName&quot;/&gt;
    </p>
    <p>
      &lt;/properties&gt;
    </p>
    <p>
      &#22312;&#20854;&#20182;&#20803;&#32032;&#37324;&#38754;&#65292;&#23601;&#21487;&#20197;&#20351;&#29992;&#23646;&#24615;&#21442;&#29031;&#26469;&#24341;&#29992;&#20102;&#65292;&#22914;property-ref=&quot;name&quot;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491305285269" FOLDED="true" ID="ID_1114979730" MODIFIED="1491305300797" TEXT="&#x5176;&#x4ed6;">
<node CREATED="1491305291494" ID="ID_1175212285" MODIFIED="1491305299808">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#19982;&#23545;&#35937;&#32487;&#25215;&#30456;&#20851;&#30340;&#37197;&#32622;
    </p>
    <p>
      &#37492;&#21035;&#22120;(discriminator)&#12289;&#23376;&#31867;&#12289;&#36830;&#25509;&#30340;&#23376;&#31867;&#12289;&#32852;&#21512;&#23376;&#31867;&#12289;&#36830;&#25509; &#12289;Any&#20803;&#32032;
    </p>
    <p>
      ? &#19982;&#20851;&#31995;&#30456;&#20851;&#30340;&#37197;&#32622;
    </p>
    <p>
      &#22810;&#23545;&#19968;(many-to-one)&#12289;&#19968;&#23545;&#19968;(one-to-one)&#12289;key&#26144;&#23556;
    </p>
    <p>
      ? &#19982;version&#31867;&#20284;&#30340;timestamp
    </p>
    <p>
      &#21516;&#26679;&#29992;&#22312;&#20048;&#35266;&#38145;&#30340;&#37197;&#32622;&#19978;&#65292;&#20316;&#20026;&#29256;&#26412;&#30340;&#26367;&#20195;&#12290;&#26102;&#38388;&#25139;&#26412;&#36136;&#19978;&#26159;&#19968;&#31181;&#23545;&#20048;&#35266;&#38145;&#23450;&#30340;&#19968;&#31181;
    </p>
    <p>
      &#19981;&#26159;&#29305;&#21035;&#23433;&#20840;&#30340;&#23454;&#29616;&#65292;&#24182;&#19981;&#25512;&#33616;&#20351;&#29992;&#12290;
    </p>
    <p>
      ? &#33258;&#28982;ID(natural-id)
    </p>
    <p>
      &#22312;&lt;natural-id&gt;&#20803;&#32032;&#20013;&#21015;&#20986;&#33258;&#28982;&#38190;&#30340;&#23646;&#24615;&#12290;Hibernate&#20250;&#24110;&#20320;&#29983;&#25104;&#24517;&#39035;&#30340;&#21807;&#19968;&#38190;&#20540;&#21644;
    </p>
    <p>
      &#38750;&#31354;&#32422;&#26463;&#65292;&#20294;&#36825;&#19968;&#26144;&#23556;&#19981;&#26159;&#20026;&#20102;&#25226;&#33258;&#28982;&#38190;&#20316;&#20026;&#20027;&#38190;&#32780;&#20934;&#22791;&#30340;&#12290;
    </p>
    <p>
      ? &#21160;&#24577;&#32452;&#20214;&#65288;dynamic-component&#65289;
    </p>
    <p>
      &#31867;&#20284;&#20110;Component&#20803;&#32032;&#65292;&#30001;Hibernate&#26681;&#25454;&#37197;&#32622;&#36827;&#34892;&#21160;&#24577;&#26144;&#23556;Map&#31867;&#22411;&#65292;&#19981;&#25512;&#33616;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1491306810452" ID="ID_1690198913" MODIFIED="1491306812272" TEXT="&#x57fa;&#x672c;&#x5f00;&#x53d1;">
<node CREATED="1491306827564" FOLDED="true" ID="ID_309076556" MODIFIED="1491306842178" TEXT="Hibernate&#x5bf9;&#x8c61;&#x72b6;&#x6001;">
<node CREATED="1491306837275" ID="ID_1155867384" MODIFIED="1491306841086">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      1 &#65306;&#30636;&#26102;(Transient) - &#30001;new&#25805;&#20316;&#31526;&#21019;&#24314;&#65292;&#19988;&#23578;&#26410;&#19982;Hibernate Session &#20851;&#32852;&#30340;&#23545;&#35937;&#34987;
    </p>
    <p>
      &#35748;&#23450;&#20026;&#30636;&#26102;&#30340;&#12290;&#30636;&#26102;&#23545;&#35937;&#19981;&#20250;&#34987;&#25345;&#20037;&#21270;&#21040;&#25968;&#25454;&#24211;&#20013;&#65292;&#20063;&#19981;&#20250;&#34987;&#36171;&#20104;&#25345;&#20037;&#21270;&#26631;&#35782;
    </p>
    <p>
      (identifier)&#12290; &#22914;&#26524;&#30636;&#26102;&#23545;&#35937;&#22312;&#31243;&#24207;&#20013;&#27809;&#26377;&#34987;&#24341;&#29992;&#65292;&#23427;&#20250;&#34987;&#22403;&#22334;&#22238;&#25910;&#22120;&#38144;&#27585;&#12290; &#20351;&#29992;
    </p>
    <p>
      Hibernate Session&#21487;&#20197;&#23558;&#20854;&#21464;&#20026;&#25345;&#20037;&#29366;&#24577;&#65292;Hibernate&#20250;&#33258;&#21160;&#25191;&#34892;&#24517;&#35201;&#30340;SQL&#35821;&#21477;&#12290;
    </p>
    <p>
      2 &#65306;&#25345;&#20037;(Persistent) - &#25345;&#20037;&#30340;&#23454;&#20363;&#22312;&#25968;&#25454;&#24211;&#20013;&#26377;&#23545;&#24212;&#30340;&#35760;&#24405;&#65292;&#24182;&#25317;&#26377;&#19968;&#20010;&#25345;&#20037;&#21270;&#26631;
    </p>
    <p>
      &#35782;&#12290; &#25345;&#20037;&#30340;&#23454;&#20363;&#21487;&#33021;&#26159;&#21018;&#34987;&#20445;&#23384;&#30340;&#65292;&#25110;&#21018;&#34987;&#21152;&#36733;&#30340;&#65292;&#26080;&#35770;&#21738;&#19968;&#31181;&#65292;&#25353;&#23450;&#20041;&#65292;&#23427;&#23384;&#22312;
    </p>
    <p>
      &#20110;&#30456;&#20851;&#32852;&#30340;Session&#20316;&#29992;&#33539;&#22260;&#20869;&#12290; Hibernate&#20250;&#26816;&#27979;&#21040;&#22788;&#20110;&#25345;&#20037;&#29366;&#24577;&#30340;&#23545;&#35937;&#30340;&#20219;&#20309;&#25913;
    </p>
    <p>
      &#21160;&#65292;&#22312;&#24403;&#21069;&#25805;&#20316;&#21333;&#20803;&#25191;&#34892;&#23436;&#27605;&#26102;&#23558;&#23545;&#35937;&#25968;&#25454;&#19982;&#25968;&#25454;&#24211;&#21516;&#27493;&#12290;&#24320;&#21457;&#32773;&#19981;&#38656;&#35201;&#25163;&#21160;&#25191;&#34892;
    </p>
    <p>
      UPDATE&#12290;&#23558;&#23545;&#35937;&#20174;&#25345;&#20037;&#29366;&#24577;&#21464;&#25104;&#30636;&#26102;&#29366;&#24577;&#21516;&#26679;&#20063;&#19981;&#38656;&#35201;&#25163;&#21160;&#25191;&#34892;DELETE&#35821;&#21477;&#12290;
    </p>
    <p>
      3 &#65306;&#33073;&#31649;(Detached) - &#19982;&#25345;&#20037;&#23545;&#35937;&#20851;&#32852;&#30340;Session&#34987;&#20851;&#38381;&#21518;&#65292;&#23545;&#35937;&#23601;&#21464;&#20026;&#33073;&#31649;&#30340;&#12290; &#23545;&#33073;
    </p>
    <p>
      &#31649;&#23545;&#35937;&#30340;&#24341;&#29992;&#20381;&#28982;&#26377;&#25928;&#65292;&#23545;&#35937;&#21487;&#32487;&#32493;&#34987;&#20462;&#25913;&#12290;&#33073;&#31649;&#23545;&#35937;&#22914;&#26524;&#37325;&#26032;&#20851;&#32852;&#21040;&#26576;&#20010;&#26032;&#30340;
    </p>
    <p>
      Session&#19978;&#65292; &#20250;&#20877;&#27425;&#36716;&#21464;&#20026;&#25345;&#20037;&#30340;&#65292;&#22312;&#33073;&#31649;&#26399;&#38388;&#30340;&#25913;&#21160;&#23558;&#34987;&#25345;&#20037;&#21270;&#21040;&#25968;&#25454;&#24211;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491306875899" ID="ID_1472890213" MODIFIED="1491306876576" TEXT="&#x5bf9;&#x8c61;&#x64cd;&#x4f5c;CRUD">
<node CREATED="1491306918963" FOLDED="true" ID="ID_1390728788" MODIFIED="1491306940209" TEXT="&#x65b0;&#x589e;">
<node CREATED="1491306928003" ID="ID_880827288" MODIFIED="1491306934477">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;&#26032;&#22686;&#8212;&#8212;save&#26041;&#27861;&#12289;persist&#26041;&#27861;
    </p>
    <p>
      1&#65306;persist() &#20351;&#19968;&#20010;&#20020;&#26102;&#23454;&#20363;&#25345;&#20037;&#21270;&#12290;&#28982;&#32780;&#65292;&#23427;&#19981;&#20445;&#35777;&#31435;&#21363;&#25226;&#26631;&#35782;&#31526;&#20540;&#20998;&#37197;&#32473;
    </p>
    <p>
      &#25345;&#20037;&#24615;&#23454;&#20363;&#65292;&#36825;&#20250;&#21457;&#29983;&#22312;flush&#30340;&#26102;&#20505;&#12290;persist() &#20063;&#20445;&#35777;&#23427;&#22312;&#20107;&#21153;&#36793;&#30028;&#22806;&#35843;&#29992;
    </p>
    <p>
      &#26102;&#19981;&#20250;&#25191;&#34892; INSERT &#35821;&#21477;&#12290;&#36825;&#23545;&#20110;&#38271;&#26399;&#36816;&#34892;&#30340;&#24102;&#26377;&#25193;&#23637;&#20250;&#35805;/&#25345;&#20037;&#21270;&#19978;&#19979;&#25991;&#30340;&#20250;
    </p>
    <p>
      &#35805;&#26159;&#24456;&#26377;&#29992;&#30340;&#12290;
    </p>
    <p>
      2&#65306;save() &#20445;&#35777;&#36820;&#22238;&#19968;&#20010;&#26631;&#35782;&#31526;&#12290;&#22914;&#26524;&#38656;&#35201;&#36816;&#34892; INSERT &#26469;&#33719;&#21462;&#26631;&#35782;&#31526;&#65288;&#22914;
    </p>
    <p>
      &quot;identity&quot; &#32780;&#38750;&quot;sequence&quot; &#29983;&#25104;&#22120;&#65289;&#65292;&#36825;&#20010; INSERT &#23558;&#31435;&#21363;&#25191;&#34892;&#65292;&#19981;&#31649;&#20320;&#26159;&#21542;
    </p>
    <p>
      &#22312;&#20107;&#21153;&#20869;&#37096;&#36824;&#26159;&#22806;&#37096;&#12290;&#36825;&#23545;&#20110;&#38271;&#26399;&#36816;&#34892;&#30340;&#24102;&#26377;&#25193;&#23637;&#20250;&#35805;/&#25345;&#20037;&#21270;&#19978;&#19979;&#25991;&#30340;&#20250;&#35805;&#26469;
    </p>
    <p>
      &#35828;&#20250;&#20986;&#29616;&#38382;&#39064;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491306942370" ID="ID_1926801184" MODIFIED="1491306951983" TEXT=" delete&#x65b9;&#x6cd5;"/>
<node CREATED="1491306958722" FOLDED="true" ID="ID_707878354" MODIFIED="1491307259623" TEXT="&#x4fee;&#x6539;">
<node CREATED="1491307238512" ID="ID_215501328" MODIFIED="1491307251692">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20462;&#25913;&#8212;&#8212;&#26377;&#22235;&#31181;&#26041;&#27861;&#26469;&#20570;&#65292;&#20998;&#21035;&#26159;&#65306;
    </p>
    <p>
      1&#65306;&#30452;&#25509;&#22312;Session&#25171;&#24320;&#30340;&#26102;&#20505;load&#23545;&#35937;&#65292;&#28982;&#21518;&#20462;&#25913;&#36825;&#20010;&#25345;&#20037;&#23545;&#35937;&#65292;&#22312;&#20107;&#21153;&#25552;&#20132;&#30340;&#26102;&#20505;&#65292;&#20250;&#33258;&#21160;
    </p>
    <p>
      flush&#21040;&#25968;&#25454;&#24211;&#20013;&#12290;
    </p>
    <p>
      2&#65306;&#20462;&#25913;&#25176;&#31649;&#23545;&#35937;&#65292;&#21487;&#29992;update&#25110;merge&#26041;&#27861;
    </p>
    <p>
      3&#65306;&#33258;&#21160;&#29366;&#24577;&#26816;&#27979;&#65306;saveOrUpdate&#26041;&#27861;
    </p>
    <p>
      ? update&#21644;merge&#26041;&#27861;
    </p>
    <p>
      1&#65306;&#22914;&#26524;&#25968;&#25454;&#24211;&#37324;&#38754;&#23384;&#22312;&#20320;&#35201;&#20462;&#25913;&#30340;&#35760;&#24405;&#65292;update&#27599;&#27425;&#26159;&#30452;&#25509;&#25191;&#34892;&#20462;&#25913;&#35821;&#21477;&#65307;&#32780;merge&#26159;&#20808;&#22312;&#32531;
    </p>
    <p>
      &#23384;&#20013;&#26597;&#25214;&#65292;&#32531;&#23384;&#20013;&#27809;&#26377;&#30456;&#24212;&#25968;&#25454;&#65292;&#23601;&#21040;&#25968;&#25454;&#24211;&#21435;&#26597;&#35810;&#65292;&#28982;&#21518;&#20877;&#21512;&#24182;&#25968;&#25454;&#65292;&#22914;&#26524;&#25968;&#25454;&#26159;&#19968;&#26679;
    </p>
    <p>
      &#30340;&#65292;&#37027;&#20040;merge&#26041;&#27861;&#19981;&#20250;&#21435;&#20570;&#20462;&#25913;&#65292;&#22914;&#26524;&#25968;&#25454;&#26377;&#19981;&#19968;&#26679;&#30340;&#22320;&#26041;&#65292;merge&#25165;&#30495;&#27491;&#20462;&#25913;&#25968;&#25454;&#24211;&#12290;
    </p>
    <p>
      2&#65306;&#22914;&#26524;&#25968;&#25454;&#24211;&#20013;&#19981;&#23384;&#22312;&#20320;&#35201;&#20462;&#25913;&#30340;&#35760;&#24405;&#65292;update&#26159;&#25253;&#38169;&#65307;&#32780;merge&#26041;&#27861;&#26159;&#24403;&#20316;&#19968;&#26465;&#26032;&#22686;&#30340;&#20540;&#65292;
    </p>
    <p>
      &#21521;&#25968;&#25454;&#24211;&#20013;&#26032;&#22686;&#19968;&#26465;&#25968;&#25454;&#12290;
    </p>
    <p>
      3&#65306;update&#21518;&#65292;&#20256;&#20837;&#30340;TO&#23545;&#35937;&#23601;&#26159;PO&#30340;&#20102;&#65292;&#32780;merge&#36824;&#26159;TO&#30340;&#12290;
    </p>
    <p>
      4&#65306;&#22914;&#26524;&#20320;&#30830;&#23450;&#24403;&#21069;session&#27809;&#26377;&#21253;&#21547;&#19982;&#20043;&#20855;&#26377;&#30456;&#21516;&#25345;&#20037;&#21270;&#26631;&#35782;&#30340;&#25345;&#20037;&#23454;&#20363;&#65292;&#20351;&#29992;update()&#12290;&#22914;
    </p>
    <p>
      &#26524;&#24819;&#38543;&#26102;&#21512;&#24182;&#25913;&#21160;&#32780;&#19981;&#32771;&#34385;session&#30340;&#29366;&#24577;&#65292;&#20351;&#29992; merge()&#12290;&#25442;&#21477;&#35805;&#35828;&#65292;&#22312;&#19968;&#20010;&#26032; session
    </p>
    <p>
      &#20013;&#36890;&#24120;&#31532;&#19968;&#20010;&#35843;&#29992;&#30340;&#26159;update()&#26041;&#27861;&#65292;&#20197;&#20445;&#35777;&#37325;&#26032;&#20851;&#32852;&#33073;&#31649;&#23545;&#35937;&#30340;&#25805;&#20316;&#39318;&#20808;&#34987;&#25191;&#34892;&#12290;
    </p>
    <p>
      5&#65306;&#35831;&#27880;&#24847;&#65306;&#20351;&#29992;update&#26469;&#25226;&#19968;&#20010;TO&#21464;&#25104;PO&#65292;&#37027;&#20040;&#19981;&#31649;&#26159;&#21542;&#20462;&#25913;&#20102;&#23545;&#35937;&#65292;&#37117;&#26159;&#35201;&#25191;&#34892;update
    </p>
    <p>
      sql&#35821;&#21477;&#30340;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1491307263120" FOLDED="true" ID="ID_1298755688" MODIFIED="1491307370270" TEXT="&#x4f7f;&#x7528;&#x573a;&#x666f;">
<node CREATED="1491307316287" ID="ID_493277226" MODIFIED="1491307357996">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;&#36890;&#24120;&#19979;&#38754;&#30340;&#22330;&#26223;&#20250;&#20351;&#29992; update() &#25110; saveOrUpdate()
    </p>
    <p>
      1&#65306;&#31243;&#24207;&#22312;&#31532;&#19968;&#20010; session &#20013;&#21152;&#36733;&#23545;&#35937;
    </p>
    <p>
      2&#65306;&#35813;&#23545;&#35937;&#34987;&#20256;&#36882;&#21040;&#34920;&#29616;&#23618;
    </p>
    <p>
      3&#65306;&#23545;&#35937;&#21457;&#29983;&#20102;&#19968;&#20123;&#25913;&#21160;
    </p>
    <p>
      4&#65306;&#35813;&#23545;&#35937;&#34987;&#36820;&#22238;&#21040;&#19994;&#21153;&#36923;&#36753;&#23618;
    </p>
    <p>
      5&#65306;&#31243;&#24207;&#35843;&#29992;&#31532;&#20108;&#20010;session&#30340;update()&#26041;&#27861;&#25345;&#20037;&#36825;&#20123;&#25913;&#21160;
    </p>
    <p>
      ? saveOrUpdate&#26041;&#27861;&#20570;&#19979;&#38754;&#30340;&#20107;&#65306;
    </p>
    <p>
      1&#65306;&#22914;&#26524;&#23545;&#35937;&#24050;&#32463;&#22312;&#26412;session&#20013;&#25345;&#20037;&#21270;&#20102;&#65292;&#19981;&#20570;&#20219;&#20309;&#20107;
    </p>
    <p>
      2&#65306;&#22914;&#26524;&#21478;&#19968;&#20010;&#19982;&#26412;session&#20851;&#32852;&#30340;&#23545;&#35937;&#25317;&#26377;&#30456;&#21516;&#30340;&#25345;&#20037;&#21270;&#26631;&#35782;&#65292;&#25243;&#20986;&#19968;&#20010;&#24322;&#24120;
    </p>
    <p>
      3&#65306;&#22914;&#26524;&#23545;&#35937;&#27809;&#26377;&#25345;&#20037;&#21270;&#26631;&#35782;&#23646;&#24615;&#65292;&#23545;&#20854;&#35843;&#29992; save()
    </p>
    <p>
      4&#65306;&#22914;&#26524;&#23545;&#35937;&#30340;&#25345;&#20037;&#26631;&#35782;&#34920;&#26126;&#20854;&#26159;&#19968;&#20010;&#26032;&#23454;&#20363;&#21270;&#30340;&#23545;&#35937;&#65292;&#23545;&#20854;&#35843;&#29992; save()&#12290;
    </p>
    <p>
      5&#65306;&#22914;&#26524;&#23545;&#35937;&#26159;&#38468;&#24102;&#29256;&#26412;&#20449;&#24687;&#30340;&#65288;&#36890;&#36807; &lt;version&gt; &#25110; &lt;timestamp&gt;&#65289;&#24182;&#19988;&#29256;&#26412;&#23646;&#24615;
    </p>
    <p>
      &#30340;&#20540;&#34920;&#26126;&#20854;&#26159;&#19968;&#20010;&#26032;&#23454;&#20363;&#21270;&#30340;&#23545;&#35937;&#65292;save() &#23427;&#12290;
    </p>
    <p>
      6&#65306;&#21542;&#21017;update()&#36825;&#20010;&#23545;&#35937;
    </p>
    <p>
      merge&#20570;&#22914;&#19979;&#30340;&#20107;&#24773;
    </p>
    <p>
      1&#65306;&#22914;&#26524;session&#20013;&#23384;&#22312;&#30456;&#21516;&#25345;&#20037;&#21270;&#26631;&#35782;&#30340;&#23454;&#20363;&#65292;&#29992;&#29992;&#25143;&#32473;&#20986;&#30340;&#23545;&#35937;&#30340;&#29366;&#24577;&#35206;&#30422;&#26087;&#26377;
    </p>
    <p>
      &#30340;&#25345;&#20037;&#23454;&#20363;
    </p>
    <p>
      2&#65306;&#22914;&#26524;session&#20013;&#27809;&#26377;&#30456;&#24212;&#30340;&#25345;&#20037;&#23454;&#20363;&#65292;&#21017;&#23581;&#35797;&#20174;&#25968;&#25454;&#24211;&#20013;&#21152;&#36733;&#65292;&#25110;&#21019;&#24314;&#26032;&#30340;&#25345;&#20037;
    </p>
    <p>
      &#21270;&#23454;&#20363;
    </p>
    <p>
      3&#65306;&#26368;&#21518;&#36820;&#22238;&#35813;&#25345;&#20037;&#23454;&#20363;
    </p>
    <p>
      4&#65306;&#29992;&#25143;&#32473;&#20986;&#30340;&#36825;&#20010;&#23545;&#35937;&#27809;&#26377;&#34987;&#20851;&#32852;&#21040; session &#19978;&#65292;&#23427;&#20381;&#26087;&#26159;&#33073;&#31649;&#30340;
    </p>
    <p>
      ? &#25353;&#20027;&#38190;&#26597;&#35810;
    </p>
    <p>
      1&#65306;load&#26041;&#27861;&#65306;load&#30340;&#26102;&#20505;&#39318;&#20808;&#26597;&#35810;&#19968;&#32423;&#32531;&#23384;&#65292;&#27809;&#26377;&#23601;&#21019;&#24314;&#24182;&#36820;&#22238;&#19968;&#20010;&#20195;&#29702;&#23545;&#35937;&#65292;&#31561;
    </p>
    <p>
      &#21040;&#20351;&#29992;&#30340;&#26102;&#20505;&#65292;&#25165;&#26597;&#20108;&#32423;&#32531;&#23384;&#65292;&#22914;&#26524;&#20108;&#32423;&#32531;&#23384;&#20013;&#27809;&#26377;&#25968;&#25454;&#23601;&#26597;&#25968;&#25454;&#24211;&#65292;&#22914;&#26524;&#25968;&#25454;
    </p>
    <p>
      &#24211;&#20013;&#27809;&#26377;&#65292;&#23601;&#25243;&#20363;&#22806;
    </p>
    <p>
      2&#65306;get&#26041;&#27861;&#65306;&#20808;&#26597;&#32531;&#23384;&#65292;&#22914;&#26524;&#32531;&#23384;&#20013;&#27809;&#26377;&#36825;&#26465;&#20855;&#20307;&#30340;&#25968;&#25454;&#65292;&#23601;&#26597;&#25968;&#25454;&#24211;&#65292;&#22914;&#26524;&#25968;&#25454;
    </p>
    <p>
      &#24211;&#27809;&#26377;&#20540;&#65292;&#23601;&#36820;&#22238;null&#65292;&#24635;&#20043;get&#26041;&#27861;&#19981;&#31649;&#29992;&#19981;&#29992;&#65292;&#37117;&#35201;&#25343;&#21040;&#30495;&#23454;&#30340;&#25968;&#25454;
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="ID_493277226" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_98576708" STARTARROW="None" STARTINCLINATION="0;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_493277226" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_98576708" SOURCE="ID_493277226" STARTARROW="None" STARTINCLINATION="0;0;"/>
</node>
</node>
<node CREATED="1491307372735" FOLDED="true" ID="ID_340801408" MODIFIED="1491307787820" TEXT="&#x67e5;&#x8be2;">
<node CREATED="1491307378519" ID="ID_617514544" MODIFIED="1491307420396">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Hibernate&#23454;&#29616;&#25353;&#26465;&#20214;&#26597;&#35810;&#30340;&#26041;&#24335;
    </p>
    <p>
      1&#65306;&#26368;&#37325;&#35201;&#30340;&#25353;&#26465;&#20214;&#26597;&#35810;&#30340;&#26041;&#27861;&#26159;&#20351;&#29992;Query&#25509;&#21475;&#65292;&#20351;&#29992;HQL
    </p>
    <p>
      2&#65306;&#26412;&#22320;&#26597;&#35810;&#65288;native sql&#65289;&#65306;&#23601;&#26159;&#20351;&#29992;&#26631;&#20934;&#30340;sql&#65292;&#20063;&#26159;&#36890;&#36807;Query&#25509;&#21475;&#26469;&#23454;&#29616;
    </p>
    <p>
      3&#65306;&#25353;&#26465;&#20214;&#26597;&#35810;&#65288;Query By Criteria&#65292;QBC&#65289;&#65306;&#20351;&#29992;&#21160;&#24577;&#30340;&#65292;&#38754;&#21521;&#23545;&#35937;&#30340;&#26041;&#24335;&#26469;&#21019;&#24314;&#26597;&#35810;
    </p>
    <p>
      4&#65306;&#25353;&#26679;&#20363;&#26597;&#35810;&#65288;Query By Example&#65292;&#31616;&#20889;QBE&#65289;&#65306;&#31867;&#20284;&#25105;&#20204;&#33258;&#24049;&#20889;&#30340;getByCondition
    </p>
    <p>
      5&#65306;&#21629;&#21517;&#26597;&#35810;&#65306;&#22312;hbm.xml&#20013;&#37197;&#32622;hql&#35821;&#21477;&#65292;&#22312;&#31243;&#24207;&#37324;&#38754;&#36890;&#36807;&#21517;&#31216;&#26469;&#21019;&#24314;Query&#25509;&#21475;
    </p>
    <p>
      ? Query&#30340;list&#26041;&#27861;
    </p>
    <p>
      &#19968;&#20010;&#26597;&#35810;&#36890;&#24120;&#22312;&#35843;&#29992; list() &#26102;&#34987;&#25191;&#34892;&#65292;&#25191;&#34892;&#32467;&#26524;&#20250;&#23436;&#20840;&#35013;&#36733;&#36827;&#20869;&#23384;&#20013;&#30340;&#19968;&#20010;&#38598;&#21512;&#65292;
    </p>
    <p>
      &#26597;&#35810;&#36820;&#22238;&#30340;&#23545;&#35937;&#22788;&#20110;&#25345;&#20037;&#29366;&#24577;&#12290;&#22914;&#26524;&#20320;&#30693;&#36947;&#30340;&#26597;&#35810;&#21482;&#20250;&#36820;&#22238;&#19968;&#20010;&#23545;&#35937;&#65292;&#21487;&#20351;&#29992; list()
    </p>
    <p>
      &#30340;&#24555;&#25463;&#26041;&#24335; uniqueResult()&#12290;
    </p>
    <p>
      ? Iterator&#21644;List
    </p>
    <p>
      &#26576;&#20123;&#24773;&#20917;&#19979;&#65292;&#20320;&#21487;&#20197;&#20351;&#29992;iterate()&#26041;&#27861;&#24471;&#21040;&#26356;&#22909;&#30340;&#24615;&#33021;&#12290; &#36825;&#36890;&#24120;&#26159;&#20320;&#39044;&#26399;&#36820;
    </p>
    <p>
      &#22238;&#30340;&#32467;&#26524;&#22312;session&#65292;&#25110;&#20108;&#32423;&#32531;&#23384;(second-level cache)&#20013;&#24050;&#32463;&#23384;&#22312;&#26102;&#30340;&#24773;&#20917;&#12290; &#22914;&#33509;
    </p>
    <p>
      &#19981;&#28982;&#65292;iterate()&#20250;&#27604;list()&#24930;&#65292;&#32780;&#19988;&#21487;&#33021;&#31616;&#21333;&#26597;&#35810;&#20063;&#38656;&#35201;&#36827;&#34892;&#22810;&#27425;&#25968;&#25454;&#24211;&#35775;&#38382;&#65306;
    </p>
    <p>
      iterate()&#20250;&#39318;&#20808;&#20351;&#29992;1&#26465;&#35821;&#21477;&#24471;&#21040;&#25152;&#26377;&#23545;&#35937;&#30340;&#25345;&#20037;&#21270;&#26631;&#35782;(identifiers)&#65292;&#20877;&#26681;&#25454;&#25345;
    </p>
    <p>
      &#20037;&#21270;&#26631;&#35782;&#25191;&#34892;n&#26465;&#38468;&#21152;&#30340;select&#35821;&#21477;&#23454;&#20363;&#21270;&#23454;&#38469;&#30340;&#23545;&#35937;&#12290;
    </p>
    <p>
      &#22806;&#32622;&#21629;&#21517;&#26597;&#35810;
    </p>
    <p>
      &#21487;&#20197;&#22312;&#26144;&#23556;&#25991;&#20214;&#20013;&#23450;&#20041;&#21629;&#21517;&#26597;&#35810;(named queries)&#12290;
    </p>
    <p>
      &lt;query name=&quot;javass&quot;&gt;
    </p>
    <p>
      &lt;![CDATA[select Object(o) from UserModel o]]&gt;
    </p>
    <p>
      &lt;/query&gt;
    </p>
    <p>
      &#21442;&#25968;&#32465;&#23450;&#21450;&#25191;&#34892;&#20197;&#32534;&#31243;&#26041;&#24335;&#23436;&#25104;&#65306;
    </p>
    <p>
      List list = s.getNamedQuery(&quot;cn.javass.h3.hello.UserModel.javass&quot;).list();
    </p>
    <p>
      &#27880;&#24847;&#35201;&#29992;&#20840;&#38480;&#23450;&#21517;&#21152;&#21517;&#31216;&#30340;&#26041;&#24335;&#36827;&#34892;&#35775;&#38382;
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      flush&#26041;&#27861;
    </p>
    <p>
      &#27599;&#38388;&#38548;&#19968;&#27573;&#26102;&#38388;&#65292;Session&#20250;&#25191;&#34892;&#19968;&#20123;&#24517;&#38656;&#30340;SQL&#35821;&#21477;&#26469;&#25226;&#20869;&#23384;&#20013;&#23545;&#35937;&#30340;&#29366;&#24577;&#21516;&#27493;&#21040;
    </p>
    <p>
      JDBC&#36830;&#25509;&#20013;&#12290;&#36825;&#20010;&#36807;&#31243;&#34987;&#31216;&#20026;&#21047;&#20986;(flush)&#65292;&#40664;&#35748;&#20250;&#22312;&#19979;&#38754;&#30340;&#26102;&#38388;&#28857;&#25191;&#34892;&#65306;
    </p>
    <p>
      1&#65306;&#22312;&#26576;&#20123;&#26597;&#35810;&#25191;&#34892;&#20043;&#21069;
    </p>
    <p>
      2&#65306;&#22312;&#35843;&#29992;org.hibernate.Transaction.commit()&#30340;&#26102;&#20505;
    </p>
    <p>
      3&#65306;&#22312;&#35843;&#29992;Session.flush()&#30340;&#26102;&#20505;
    </p>
    <p>
      &#28041;&#21450;&#30340; SQL &#35821;&#21477;&#20250;&#25353;&#29031;&#19979;&#38754;&#30340;&#39034;&#24207;&#21457;&#20986;&#25191;&#34892;&#65306;
    </p>
    <p>
      1. &#25152;&#26377;&#23545;&#23454;&#20307;&#36827;&#34892;&#25554;&#20837;&#30340;&#35821;&#21477;&#65292;&#20854;&#39034;&#24207;&#25353;&#29031;&#23545;&#35937;&#25191;&#34892;save() &#30340;&#26102;&#38388;&#39034;&#24207;
    </p>
    <p>
      2. &#25152;&#26377;&#23545;&#23454;&#20307;&#36827;&#34892;&#26356;&#26032;&#30340;&#35821;&#21477;
    </p>
    <p>
      3. &#25152;&#26377;&#36827;&#34892;&#38598;&#21512;&#21024;&#38500;&#30340;&#35821;&#21477;
    </p>
    <p>
      4. &#25152;&#26377;&#23545;&#38598;&#21512;&#20803;&#32032;&#36827;&#34892;&#21024;&#38500;&#65292;&#26356;&#26032;&#25110;&#32773;&#25554;&#20837;&#30340;&#35821;&#21477;
    </p>
    <p>
      5. &#25152;&#26377;&#36827;&#34892;&#38598;&#21512;&#25554;&#20837;&#30340;&#35821;&#21477;
    </p>
    <p>
      6. &#25152;&#26377;&#23545;&#23454;&#20307;&#36827;&#34892;&#21024;&#38500;&#30340;&#35821;&#21477;&#65292;&#20854;&#39034;&#24207;&#25353;&#29031;&#23545;&#35937;&#25191;&#34892; delete() &#30340;&#26102;&#38388;&#39034;&#24207;
    </p>
    <p>
      &#38500;&#38750;&#20320;&#26126;&#30830;&#22320;&#21457;&#20986;&#20102;flush()&#25351;&#20196;&#65292;&#20851;&#20110;Session&#20309;&#26102;&#20250;&#25191;&#34892;&#36825;&#20123;JDBC&#35843;&#29992;&#26159;&#23436;
    </p>
    <p>
      &#20840;&#26080;&#27861;&#20445;&#35777;&#30340;&#65292;&#21482;&#33021;&#20445;&#35777;&#23427;&#20204;&#25191;&#34892;&#30340;&#21069;&#21518;&#39034;&#24207;&#12290; &#24403;&#28982;&#65292;Hibernate&#20445;&#35777;&#65292;
    </p>
    <p>
      Query.list(..)&#32477;&#23545;&#19981;&#20250;&#36820;&#22238;&#24050;&#32463;&#22833;&#25928;&#30340;&#25968;&#25454;&#65292;&#20063;&#19981;&#20250;&#36820;&#22238;&#38169;&#35823;&#25968;&#25454;&#12290;
    </p>
  </body>
</html></richcontent>
<node CREATED="1491307395370" MODIFIED="1491307395370" TEXT="&#x5916;&#x7f6e;&#x547d;&#x540d;&#x67e5;&#x8be2;"/>
<node CREATED="1491307395371" MODIFIED="1491307395371" TEXT="&#x53ef;&#x4ee5;&#x5728;&#x6620;&#x5c04;&#x6587;&#x4ef6;&#x4e2d;&#x5b9a;&#x4e49;&#x547d;&#x540d;&#x67e5;&#x8be2;(named queries)&#x3002;"/>
<node CREATED="1491307395372" MODIFIED="1491307395372" TEXT="&lt;query name=&quot;javass&quot;&gt;"/>
<node CREATED="1491307395372" MODIFIED="1491307395372" TEXT="&lt;![CDATA[select Object(o) from UserModel o]]&gt;"/>
<node CREATED="1491307395372" MODIFIED="1491307395372" TEXT="&lt;/query&gt;"/>
<node CREATED="1491307395373" MODIFIED="1491307395373" TEXT="&#x53c2;&#x6570;&#x7ed1;&#x5b9a;&#x53ca;&#x6267;&#x884c;&#x4ee5;&#x7f16;&#x7a0b;&#x65b9;&#x5f0f;&#x5b8c;&#x6210;&#xff1a;"/>
<node CREATED="1491307395373" MODIFIED="1491307395373" TEXT="List list = s.getNamedQuery(&quot;cn.javass.h3.hello.UserModel.javass&quot;).list();"/>
<node CREATED="1491307395374" MODIFIED="1491307395374" TEXT="&#x6ce8;&#x610f;&#x8981;&#x7528;&#x5168;&#x9650;&#x5b9a;&#x540d;&#x52a0;&#x540d;&#x79f0;&#x7684;&#x65b9;&#x5f0f;&#x8fdb;&#x884c;&#x8bbf;&#x95ee;"/>
</node>
</node>
<node CREATED="1491307791404" FOLDED="true" ID="ID_1677025052" MODIFIED="1491307818339" TEXT="&#x64cd;&#x4f5c;&#x5176;&#x5b83;">
<node CREATED="1491307803748" ID="ID_1593279747" MODIFIED="1491307817206">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      lock&#26041;&#27861;&#65306;&#20063;&#20801;&#35768;&#31243;&#24207;&#37325;&#26032;&#20851;&#32852;&#26576;&#20010;&#23545;&#35937;&#21040;&#19968;&#20010;&#26032; session &#19978;&#12290;&#19981;&#36807;&#65292;&#35813;&#33073;&#31649;
    </p>
    <p>
      &#23545;&#35937;&#24517;&#39035;&#26159;&#27809;&#26377;&#20462;&#25913;&#36807;&#30340;&#12290;&#31034;&#20363;&#22914;&#65306;s.lock(um, LockMode.READ);
    </p>
    <p>
      &#27880;&#24847;&#65306;lock&#20027;&#35201;&#36824;&#26159;&#29992;&#22312;&#20107;&#21153;&#22788;&#29702;&#19978;&#65292;&#20851;&#32852;&#23545;&#35937;&#21482;&#26159;&#19968;&#20010;&#38468;&#24102;&#30340;&#21151;&#33021;
    </p>
    <p>
      ? &#33719;&#21462;&#20803;&#25968;&#25454;
    </p>
    <p>
      Hibernate &#25552;&#20379;&#20102;ClassMetadata&#25509;&#21475;&#21644;Type&#26469;&#35775;&#38382;&#20803;&#25968;&#25454;&#12290;&#31034;&#20363;&#22914;&#19979;&#65306;
    </p>
    <p>
      ClassMetadata catMeta = sf.getClassMetadata(UserModel.class);
    </p>
    <p>
      String[] propertyNames = catMeta.getPropertyNames();
    </p>
    <p>
      Type[] propertyTypes = catMeta.getPropertyTypes();
    </p>
    <p>
      for (int i = 0; i &lt; propertyNames.length; i++) {
    </p>
    <p>
      System.out.println(&quot;name==&quot;+propertyNames[i] + &quot;, type==&#8220;
    </p>
    <p>
      +propertyTypes[i]);
    </p>
    <p>
      }
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1491287678538" FOLDED="true" ID="ID_1036877807" MODIFIED="1497020678429" TEXT="&#x65e5;&#x5fd7;&#x6846;&#x67b6;">
<node CREATED="1491287703194" FOLDED="true" ID="ID_1827571328" MODIFIED="1492909022353" TEXT="LOG4J">
<node CREATED="1491287806266" ID="ID_1032589547" MODIFIED="1491287807339" TEXT="Log4j&#x662f;Apache&#x7684;&#x4e00;&#x4e2a;&#x5f00;&#x6e90;&#x9879;&#x76ee;&#xff0c;&#x901a;&#x8fc7;&#x4f7f;&#x7528;Log4j&#xff0c;&#x6211;&#x4eec;&#x53ef;&#x4ee5;&#x63a7;&#x5236;&#x65e5;&#x5fd7;&#x4fe1;&#x606f;&#x8f93;&#x9001;&#x7684;&#x76ee;&#x7684;&#x5730;&#x662f;&#x63a7;&#x5236;&#x53f0;&#x3001;&#x6587;&#x4ef6;&#x3001;GUI&#x7ec4;&#x4ef6;&#xff0c;&#x751a;&#x81f3;&#x662f;&#x5957;&#x63a5;&#x53e3;&#x670d;&#x52a1;&#x5668;&#x3001;NT&#x7684;&#x4e8b;&#x4ef6;&#x8bb0;&#x5f55;&#x5668;&#x3001;UNIX Syslog&#x5b88;&#x62a4;&#x8fdb;&#x7a0b;&#x7b49;&#xff1b;&#x6211;&#x4eec;&#x4e5f;&#x53ef;&#x4ee5;&#x63a7;&#x5236;&#x6bcf;&#x4e00;&#x6761;&#x65e5;&#x5fd7;&#x7684;&#x8f93;&#x51fa;&#x683c;&#x5f0f;&#xff1b;&#x901a;&#x8fc7;&#x5b9a;&#x4e49;&#x6bcf;&#x4e00;&#x6761;&#x65e5;&#x5fd7;&#x4fe1;&#x606f;&#x7684;&#x7ea7;&#x522b;&#xff0c;&#x6211;&#x4eec;&#x80fd;&#x591f;&#x66f4;&#x52a0;&#x7ec6;&#x81f4;&#x5730;&#x63a7;&#x5236;&#x65e5;&#x5fd7;&#x7684;&#x751f;&#x6210;&#x8fc7;&#x7a0b;&#x3002;&#x6700;&#x4ee4;&#x4eba;&#x611f;&#x5174;&#x8da3;&#x7684;&#x5c31;&#x662f;&#xff0c;&#x8fd9;&#x4e9b;&#x53ef;&#x4ee5;&#x901a;&#x8fc7;&#x4e00;&#x4e2a;&#x914d;&#x7f6e;&#x6587;&#x4ef6;&#x6765;&#x7075;&#x6d3b;&#x5730;&#x8fdb;&#x884c;&#x914d;&#x7f6e;&#xff0c;&#x800c;&#x4e0d;&#x9700;&#x8981;&#x4fee;&#x6539;&#x5e94;&#x7528;&#x7684;&#x4ee3;&#x7801;&#x3002;"/>
</node>
<node CREATED="1491287705554" FOLDED="true" ID="ID_592693211" MODIFIED="1491287840322" TEXT="SLF4J">
<node CREATED="1491287834905" ID="ID_1427394114" MODIFIED="1491287836925" TEXT="SLF4J&#xff0c;&#x5373;&#x7b80;&#x5355;&#x65e5;&#x5fd7;&#x95e8;&#x9762;&#xff08;Simple Logging Facade for Java&#xff09;&#xff0c;&#x4e0d;&#x662f;&#x5177;&#x4f53;&#x7684;&#x65e5;&#x5fd7;&#x89e3;&#x51b3;&#x65b9;&#x6848;&#xff0c;&#x5b83;&#x53ea;&#x670d;&#x52a1;&#x4e8e;&#x5404;&#x79cd;&#x5404;&#x6837;&#x7684;&#x65e5;&#x5fd7;&#x7cfb;&#x7edf;&#x3002;&#x6309;&#x7167;&#x5b98;&#x65b9;&#x7684;&#x8bf4;&#x6cd5;&#xff0c;SLF4J&#x662f;&#x4e00;&#x4e2a;&#x7528;&#x4e8e;&#x65e5;&#x5fd7;&#x7cfb;&#x7edf;&#x7684;&#x7b80;&#x5355;Facade&#xff0c;&#x5141;&#x8bb8;&#x6700;&#x7ec8;&#x7528;&#x6237;&#x5728;&#x90e8;&#x7f72;&#x5176;&#x5e94;&#x7528;&#x65f6;&#x4f7f;&#x7528;&#x5176;&#x6240;&#x5e0c;&#x671b;&#x7684;&#x65e5;&#x5fd7;System"/>
</node>
<node CREATED="1491287707450" FOLDED="true" ID="ID_1374627317" MODIFIED="1491287897512" TEXT="LOG4J2">
<node CREATED="1491287892560" ID="ID_619495151" MODIFIED="1491287893450" TEXT="log4j2&#x53ef;&#x4ee5;&#x6309;&#x7167;&#x5f00;&#x53d1;&#x4eba;&#x5458;&#x9884;&#x5148;&#x7684;&#x8bbe;&#x5b9a;&#xff0c;&#x5728;&#x6307;&#x5b9a;&#x7684;&#x4f4d;&#x7f6e;&#x548c;&#x60c5;&#x51b5;&#x4e0b;&#x6253;&#x5370;log&#x8bed;&#x53e5;&#xff0c;&#x5e76;&#x4e14;&#x53ef;&#x4ee5;&#x914c;&#x60c5;&#x5173;&#x95ed;&#x67d0;&#x4e9b;log&#x8bed;&#x53e5;&#xff0c;&#x5982;&#x5f00;&#x53d1;&#x9636;&#x6bb5;debug&#x7c7b;&#x578b;&#x7684;&#x8bed;&#x53e5;&#x7b49;&#x3002;&#x5e76;&#x4e14;&#xff0c;&#x53ef;&#x4ee5;&#x4f7f;&#x7528;layout&#x6765;&#x5b9a;&#x4e49;&#x8f93;&#x51fa;&#x8bed;&#x53e5;&#x7684;&#x683c;&#x5f0f;&#xff0c;&#x50cf;C&#x8bed;&#x8a00;&#x7684;printf&#x51fd;&#x6570;&#x4e00;&#x6837;&#x3002;"/>
</node>
<node CREATED="1491287778818" FOLDED="true" ID="ID_1754226667" MODIFIED="1491287912064" TEXT="LOGBACK">
<node CREATED="1491287910120" ID="ID_1674959487" MODIFIED="1491287910871" TEXT="Logback&#x662f;&#x7531;log4j&#x521b;&#x59cb;&#x4eba;&#x8bbe;&#x8ba1;&#x7684;&#x53c8;&#x4e00;&#x4e2a;&#x5f00;&#x6e90;&#x65e5;&#x5fd7;&#x7ec4;&#x4ef6;&#x3002;logback&#x5f53;&#x524d;&#x5206;&#x6210;&#x4e09;&#x4e2a;&#x6a21;&#x5757;&#xff1a;logback-core,logback- classic&#x548c;logback-access&#x3002;logback-core&#x662f;&#x5176;&#x5b83;&#x4e24;&#x4e2a;&#x6a21;&#x5757;&#x7684;&#x57fa;&#x7840;&#x6a21;&#x5757;&#x3002;logback-classic&#x662f;log4j&#x7684;&#x4e00;&#x4e2a; &#x6539;&#x826f;&#x7248;&#x672c;&#x3002;&#x6b64;&#x5916;logback-classic&#x5b8c;&#x6574;&#x5b9e;&#x73b0;SLF4J API&#x4f7f;&#x4f60;&#x53ef;&#x4ee5;&#x5f88;&#x65b9;&#x4fbf;&#x5730;&#x66f4;&#x6362;&#x6210;&#x5176;&#x5b83;&#x65e5;&#x5fd7;&#x7cfb;&#x7edf;&#x5982;log4j&#x6216;JDK14 Logging&#x3002;logback-access&#x8bbf;&#x95ee;&#x6a21;&#x5757;&#x4e0e;Servlet&#x5bb9;&#x5668;&#x96c6;&#x6210;&#x63d0;&#x4f9b;&#x901a;&#x8fc7;Http&#x6765;&#x8bbf;&#x95ee;&#x65e5;&#x5fd7;&#x7684;&#x529f;&#x80fd;&#x3002;"/>
</node>
</node>
<node CREATED="1497020682924" ID="ID_263793840" MODIFIED="1497020685316" TEXT="Spring">
<node CREATED="1497020688873" ID="ID_711330823" MODIFIED="1497060739996" TEXT="&#x76f8;&#x5173;&#x8bcd;">
<node CREATED="1497020885696" FOLDED="true" ID="ID_705353845" MODIFIED="1497061954574">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <font color="#ff3333"><b>IOC&#25511;&#21046;&#21453;&#36716;</b></font>
    </p>
    <p>
      ______________
    </p>
    <p>
      &#23454;&#29616;&#25509;&#21475;&#19982;&#23454;&#29616;&#31867;&#35299;&#32806;
    </p>
    <p>
      Spring&#36890;&#36807;setter&#26041;&#27861;&#27880;&#20837;
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1497020932300" ID="ID_272315096" MODIFIED="1497060193563">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24403;&#21069;&#27604;&#36739;&#30693;&#21517;&#30340;IoC&#23481;&#22120;&#26377;&#65306;Pico Container&#12289;Avalon &#12289;Spring&#12289;JBoss&#12289;HiveMind&#12289;EJB&#31561;&#12290;&#160;
    </p>
    <p>
      &#22312;&#19978;&#38754;&#30340;&#20960;&#20010;IoC&#23481;&#22120;&#20013;&#65292;&#36731;&#37327;&#32423;&#30340;&#26377;Pico Container&#12289;Avalon&#12289;Spring&#12289;HiveMind&#31561;&#65292;&#36229;&#37325;&#37327;&#32423;&#30340;&#26377;EJB&#65292;&#32780;&#21322;&#36731;&#21322;&#37325;&#30340;&#26377;&#23481;&#22120;&#26377;JBoss&#65292;Jdon&#31561;&#12290;
    </p>
    <p>
      <b>&#25511;&#21046;&#21453;&#36716;&#23454;&#29616;&#31867;&#22411; </b>
    </p>
    <p>
      &#29616;&#26377;&#30340;&#26694;&#26550;&#23454;&#38469;&#19978;&#20351;&#29992;&#20197;&#19979;&#19977;&#31181;&#22522;&#26412;&#25216;&#26415;&#30340;&#26694;&#26550;&#25191;&#34892;&#26381;&#21153;&#21644;&#37096;&#20214;&#38388;&#30340;&#32465;&#23450;:
    </p>
    <p>
      &#31867;&#22411;1 (&#22522;&#20110;&#25509;&#21475;): &#21487;&#26381;&#21153;&#30340;&#23545;&#35937;&#38656;&#35201;&#23454;&#29616;&#19968;&#20010;&#19987;&#38376;&#30340;&#25509;&#21475;&#65292;&#35813;&#25509;&#21475;&#25552;&#20379;&#20102;&#19968;&#20010;&#23545;&#35937;&#65292;&#21487;&#20197;&#37325;&#29992;&#36825;&#20010;&#23545;&#35937;&#26597;&#25214;&#20381;&#36182;(&#20854;&#23427;&#26381;&#21153;)&#12290;&#26089;&#26399;&#30340;&#23481;&#22120;Excalibur&#20351;&#29992;&#36825;&#31181;&#27169;&#24335;&#12290;
    </p>
    <p>
      &#31867;&#22411;2 (&#22522;&#20110;setter): &#36890;&#36807;JavaBean&#30340;&#23646;&#24615;(setter&#26041;&#27861;)&#20026;&#21487;&#26381;&#21153;&#23545;&#35937;&#25351;&#23450;&#26381;&#21153;&#12290;HiveMind&#21644;Spring&#37319;&#29992;&#36825;&#31181;&#26041;&#24335;&#12290;
    </p>
    <p>
      &#31867;&#22411;3 (&#22522;&#20110;&#26500;&#36896;&#20989;&#25968;): &#36890;&#36807;&#26500;&#36896;&#20989;&#25968;&#30340;&#21442;&#25968;&#20026;&#21487;&#26381;&#21153;&#23545;&#35937;&#25351;&#23450;&#26381;&#21153;&#12290;PicoContainer&#21482;&#20351;&#29992;&#36825;&#31181;&#26041;&#24335;&#12290;HiveMind&#21644;Spring&#20063;&#20351;&#29992;&#36825;&#31181;&#26041;&#24335;&#12290;
    </p>
    <p>
      <b>&#23454;&#29616;&#31574;&#30053; </b>
    </p>
    <p>
      IoC&#26159;&#19968;&#20010;&#24456;&#22823;&#30340;&#27010;&#24565;,&#21487;&#20197;&#29992;&#19981;&#21516;&#30340;&#26041;&#24335;&#23454;&#29616;&#12290;&#20854;&#20027;&#35201;&#24418;&#24335;&#26377;&#20004;&#31181;&#65306;
    </p>
    <p>
      <b>&#9671;&#20381;&#36182;&#26597;&#25214;</b>&#65306;&#23481;&#22120;&#25552;&#20379;&#22238;&#35843;&#25509;&#21475;&#21644;&#19978;&#19979;&#25991;&#26465;&#20214;&#32473;&#32452;&#20214;&#12290;EJB&#21644;Apache Avalon &#37117;&#20351;&#29992;&#36825;&#31181;&#26041;&#24335;&#12290;&#36825;&#26679;&#19968;&#26469;&#65292;&#32452;&#20214;&#23601;&#24517;&#39035;&#20351;&#29992;&#23481;&#22120;&#25552;&#20379;&#30340;API&#26469;&#26597;&#25214;&#36164;&#28304;&#21644;&#21327;&#20316;&#23545;&#35937;&#65292;&#20165;&#26377;&#30340;&#25511;&#21046;&#21453;&#36716;&#21482;&#20307;&#29616;&#22312;&#37027;&#20123;&#22238;&#35843;&#26041;&#27861;&#19978;&#65288;&#20063;&#23601;&#26159;&#19978;&#38754;&#25152;&#35828;&#30340; &#31867;&#22411;1&#65289;&#65306;&#23481;&#22120;&#23558;&#35843;&#29992;&#36825;&#20123;&#22238;&#35843;&#26041;&#27861;&#65292;&#20174;&#32780;&#35753;&#24212;&#29992;&#20195;&#30721;&#33719;&#24471;&#30456;&#20851;&#36164;&#28304;&#12290;
    </p>
    <p>
      <b>&#9671;&#20381;&#36182;&#27880;&#20837;</b>&#65306;&#32452;&#20214;&#19981;&#20570;&#23450;&#20301;&#26597;&#35810;&#65292;&#21482;&#25552;&#20379;&#26222;&#36890;&#30340;Java&#26041;&#27861;&#35753;&#23481;&#22120;&#21435;&#20915;&#23450;&#20381;&#36182;&#20851;&#31995;&#12290;&#23481;&#22120;&#20840;&#26435;&#36127;&#36131;&#30340;&#32452;&#20214;&#30340;&#35013;&#37197;&#65292;&#23427;&#20250;&#25226;&#31526;&#21512;&#20381;&#36182;&#20851;&#31995;&#30340;&#23545;&#35937;&#36890;&#36807;JavaBean&#23646;&#24615;&#25110;&#32773;&#26500;&#36896;&#20989;&#25968;&#20256;&#36882;&#32473;&#38656;&#35201;&#30340;&#23545;&#35937;&#12290;&#36890;&#36807;JavaBean&#23646;&#24615;&#27880;&#23556;&#20381;&#36182;&#20851;&#31995;&#30340;&#20570;&#27861;&#31216;&#20026;&#35774;&#20540;&#26041;&#27861;&#27880;&#20837;(Setter Injection)&#65307;&#23558;&#20381;&#36182;&#20851;&#31995;&#20316;&#20026;&#26500;&#36896;&#20989;&#25968;&#21442;&#25968;&#20256;&#20837;&#30340;&#20570;&#27861;&#31216;&#20026;&#26500;&#36896;&#22120;&#27880;&#20837;&#65288;Constructor Injection&#65289;
    </p>
    <p>
      <b>&#25511;&#21046;&#21453;&#36716;</b>&#65288;Inversion of Control&#65292;&#33521;&#25991;&#32553;&#20889;&#20026;IoC&#65289;&#26159;&#26694;&#26550;&#30340;&#37325;&#35201;&#29305;&#24449;&#65292;&#24182;&#38750;&#38754;&#21521;&#23545;&#35937;&#32534;&#31243;&#30340;&#19987;&#29992;&#26415;&#35821;&#12290;&#23427;&#19982;&#20381;&#36182;&#27880;&#20837;&#65288;Dependency Injection&#65292;&#31616;&#31216;DI&#65289;&#21644;&#20381;&#36182;&#26597;&#25214;&#65288;Dependency Lookup&#65289;&#24182;&#27809;&#26377;&#20851;&#31995;&#12290;
    </p>
    <p>
      <b>&#35774;&#35745;&#27169;&#24335;</b>
    </p>
    <p>
      &#21487;&#20197;&#25226;IoC&#27169;&#24335;&#30475;&#20570;&#26159;&#24037;&#21378;&#27169;&#24335;&#30340;&#21319;&#21326;&#65292;&#21487;&#20197;&#25226;IoC&#30475;&#20316;&#26159;&#19968;&#20010;&#22823;&#24037;&#21378;&#65292;&#21482;&#19981;&#36807;&#36825;&#20010;&#22823;&#24037;&#21378;&#37324;&#35201;&#29983;&#25104;&#30340;&#23545;&#35937;&#37117;&#26159;&#22312;XML&#25991;&#20214;&#20013;&#32473;&#20986;&#23450;&#20041;&#30340;&#65292;&#28982;&#21518;&#21033;&#29992;Java &#30340;&#8220;&#21453;&#23556;&#8221;&#32534;&#31243;&#65292;&#26681;&#25454;XML&#20013;&#32473;&#20986;&#30340;&#31867;&#21517;&#29983;&#25104;&#30456;&#24212;&#30340;&#23545;&#35937;&#12290;&#20174;&#23454;&#29616;&#26469;&#30475;&#65292;IoC&#26159;&#25226;&#20197;&#21069;&#22312;&#24037;&#21378;&#26041;&#27861;&#37324;&#20889;&#27515;&#30340;&#23545;&#35937;&#29983;&#25104;&#20195;&#30721;&#65292;&#25913;&#21464;&#20026;&#30001;XML&#25991;&#20214;&#26469;&#23450;&#20041;&#65292;&#20063;&#23601;&#26159;&#25226;&#24037;&#21378;&#21644;&#23545;&#35937;&#29983;&#25104;&#36825;&#20004;&#32773;&#29420;&#31435;&#20998;&#38548;&#24320;&#26469;&#65292;&#30446;&#30340;&#23601;&#26159;&#25552;&#39640;&#28789;&#27963;&#24615;&#21644;&#21487;&#32500;&#25252;&#24615;&#12290;
    </p>
    <p>
      IoC&#20013;&#26368;&#22522;&#26412;&#30340;Java&#25216;&#26415;&#23601;&#26159;&#8220;&#21453;&#23556;&#8221;&#32534;&#31243;&#12290;&#21453;&#23556;&#21448;&#26159;&#19968;&#20010;&#29983;&#28073;&#30340;&#21517;&#35789;&#65292;&#36890;&#20439;&#30340;&#35828;&#21453;&#23556;&#23601;&#26159;&#26681;&#25454;&#32473;&#20986;&#30340;&#31867;&#21517;&#65288;&#23383;&#31526;&#20018;&#65289;&#26469;&#29983;&#25104;&#23545;&#35937;&#12290;&#36825;&#31181;&#32534;&#31243;&#26041;&#24335;&#21487;&#20197;&#35753;&#23545;&#35937;&#22312;&#29983;&#25104;&#26102;&#25165;&#20915;&#23450;&#35201;&#29983;&#25104;&#21738;&#19968;&#31181;&#23545;&#35937;&#12290;&#21453;&#23556;&#30340;&#24212;&#29992;&#26159;&#24456;&#24191;&#27867;&#30340;&#65292;&#20687;Hibernate&#12289;Spring&#20013;&#37117;&#26159;&#29992;&#8220;&#21453;&#23556;&#8221;&#20570;&#20026;&#26368;&#22522;&#26412;&#30340;&#25216;&#26415;&#25163;&#27573;&#12290;
    </p>
    <p>
      &#22312;&#36807;&#21435;&#65292;&#21453;&#23556;&#32534;&#31243;&#26041;&#24335;&#30456;&#23545;&#20110;&#27491;&#24120;&#30340;&#23545;&#35937;&#29983;&#25104;&#26041;&#24335;&#35201;&#24930;10&#20960;&#20493;&#65292;&#36825;&#20063;&#35768;&#20063;&#26159;&#24403;&#26102;&#20026;&#20160;&#20040;&#21453;&#23556;&#25216;&#26415;&#27809;&#26377;&#26222;&#36941;&#24212;&#29992;&#24320;&#26469;&#30340;&#21407;&#22240;&#12290;&#20294;&#32463;SUN&#25913;&#33391;&#20248;&#21270;&#21518;&#65292;&#21453;&#23556;&#26041;&#24335;&#29983;&#25104;&#23545;&#35937;&#21644;&#36890;&#24120;&#23545;&#35937;&#29983;&#25104;&#26041;&#24335;&#65292;&#36895;&#24230;&#24050;&#32463;&#30456;&#24046;&#19981;&#22823;&#20102;&#65288;&#20294;&#20381;&#28982;&#26377;&#19968;&#20493;&#20197;&#19978;&#30340;&#24046;&#36317;)
    </p>
    <p>
      <b>&#20248;&#32570;&#28857; </b>
    </p>
    <p>
      IoC&#26368;&#22823;&#30340;<b>&#22909;&#22788;</b>&#26159;&#20160;&#20040;&#65311;&#22240;&#20026;&#25226;&#23545;&#35937;&#29983;&#25104;&#25918;&#22312;&#20102;XML&#37324;&#23450;&#20041;&#65292;&#25152;&#20197;&#24403;&#25105;&#20204;&#38656;&#35201;&#25442;&#19968;&#20010;&#23454;&#29616;&#23376;&#31867;&#23558;&#20250;&#21464;&#25104;&#24456;&#31616;&#21333;&#65288;&#19968;&#33324;&#36825;&#26679;&#30340;&#23545;&#35937;&#37117;&#26159;&#23454;&#29616;&#20110;&#26576;&#31181;&#25509;&#21475;&#30340;&#65289;&#65292;&#21482;&#35201;&#20462;&#25913;XML&#23601;&#21487;&#20197;&#20102;&#65292;&#36825;&#26679;&#25105;&#20204;&#29978;&#33267;&#21487;&#20197;&#23454;&#29616;&#23545;&#35937;&#30340;&#28909;&#25554;&#25300;&#65288;&#26377;&#28857;&#20687;USB&#25509;&#21475;&#21644;SCSI&#30828;&#30424;&#20102;&#65289;&#12290;
    </p>
    <p>
      IoC&#26368;&#22823;&#30340;<b>&#32570;&#28857;</b>&#26159;&#20160;&#20040;&#65311;&#65288;1&#65289;&#29983;&#25104;&#19968;&#20010;&#23545;&#35937;&#30340;&#27493;&#39588;&#21464;&#22797;&#26434;&#20102;&#65288;&#20107;&#23454;&#19978;&#25805;&#20316;&#19978;&#36824;&#26159;&#25402;&#31616;&#21333;&#30340;&#65289;&#65292;&#23545;&#20110;&#19981;&#20064;&#24815;&#36825;&#31181;&#26041;&#24335;&#30340;&#20154;&#65292;&#20250;&#35273;&#24471;&#26377;&#20123;&#21035;&#25197;&#21644;&#19981;&#30452;&#35266;&#12290;&#65288;2&#65289;&#23545;&#35937;&#29983;&#25104;&#22240;&#20026;&#26159;&#20351;&#29992;&#21453;&#23556;&#32534;&#31243;&#65292;&#22312;&#25928;&#29575;&#19978;&#26377;&#20123;&#25439;&#32791;&#12290;&#20294;&#30456;&#23545;&#20110;IoC&#25552;&#39640;&#30340;&#32500;&#25252;&#24615;&#21644;&#28789;&#27963;&#24615;&#26469;&#35828;&#65292;&#36825;&#28857;&#25439;&#32791;&#26159;&#24494;&#19981;&#36275;&#36947;&#30340;&#65292;&#38500;&#38750;&#26576;&#23545;&#35937;&#30340;&#29983;&#25104;&#23545;&#25928;&#29575;&#35201;&#27714;&#29305;&#21035;&#39640;&#12290;&#65288;3&#65289;&#32570;&#23569;IDE&#37325;&#26500;&#25805;&#20316;&#30340;&#25903;&#25345;&#65292;&#22914;&#26524;&#22312;Eclipse&#35201;&#23545;&#31867;&#25913;&#21517;&#65292;&#37027;&#20040;&#20320;&#36824;&#38656;&#35201;&#21435;XML&#25991;&#20214;&#37324;&#25163;&#24037;&#21435;&#25913;&#20102;&#65292;&#36825;&#20284;&#20046;&#26159;&#25152;&#26377;XML&#26041;&#24335;&#30340;&#32570;&#38519;&#25152;&#22312;&#12290;
    </p>
  </body>
</html>
</richcontent>
<arrowlink DESTINATION="ID_272315096" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_651151878" STARTARROW="None" STARTINCLINATION="0;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_272315096" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_651151878" SOURCE="ID_272315096" STARTARROW="None" STARTINCLINATION="0;0;"/>
</node>
</node>
<node CREATED="1497024596717" ID="ID_946193165" MODIFIED="1497061950247">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <font color="#ff0000"><b>AOP&#38754;&#21521;&#20999;&#38754;</b></font>
    </p>
    <p>
      ___________
    </p>
    <p>
      &#20004;&#31181;&#23454;&#29616;&#65306;
    </p>
    <p>
      &#19968;&#26159;&#36890;&#36807;&#21160;&#24577;&#20195;&#29702;&#65292;
    </p>
    <p>
      &#20108;&#26159;&#36890;&#36807;&#23454;&#29616;&#31867;&#30340;&#23376;&#31867;&#23454;&#29616; &#65307;
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1497062425809" ID="ID_1888017714" MODIFIED="1497062573980">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22312;&#36719;&#20214;&#19994;&#65292;AOP&#20026;Aspect Oriented Programming&#30340;&#32553;&#20889;&#65292;&#24847;&#20026;&#65306;&#38754;&#21521;&#20999;&#38754;&#32534;&#31243;&#65292;&#36890;&#36807;&#39044;&#32534;&#35793;&#26041;&#24335;&#21644;&#36816;&#34892;&#26399;&#21160;&#24577;&#20195;&#29702;&#23454;&#29616;&#31243;&#24207;&#21151;&#33021;&#30340;&#32479;&#19968;&#32500;&#25252;&#30340;&#19968;&#31181;&#25216;&#26415;&#12290;<font color="#ff0000"><b>AOP&#26159;OOP&#30340;&#24310;&#32493;</b></font>&#65292;&#26159;&#36719;&#20214;&#24320;&#21457;&#20013;&#30340;&#19968;&#20010;&#28909;&#28857;&#65292;&#20063;&#26159;Spring&#26694;&#26550;&#20013;&#30340;&#19968;&#20010;&#37325;&#35201;&#20869;&#23481;&#65292;&#26159;<font color="#ff3333"><b>&#20989;&#25968;&#24335;&#32534;&#31243;&#30340;&#19968;&#31181;&#34893;&#29983;&#33539;&#22411;</b></font>&#12290;&#21033;&#29992;AOP&#21487;&#20197;&#23545;&#19994;&#21153;&#36923;&#36753;&#30340;&#21508;&#20010;&#37096;&#20998;&#36827;&#34892;&#38548;&#31163;&#65292;&#20174;&#32780;&#20351;&#24471;&#19994;&#21153;&#36923;&#36753;&#21508;&#37096;&#20998;&#20043;&#38388;&#30340;<font color="#ff3333">&#32806;&#21512;&#24230;&#38477;&#20302;</font>&#65292;<font color="#ff0000">&#25552;&#39640;&#31243;&#24207;&#30340;&#21487;&#37325;&#29992;&#24615;</font>&#65292;&#21516;&#26102;&#25552;&#39640;&#20102;&#24320;&#21457;&#30340;&#25928;&#29575;&#12290;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1497060752296" FOLDED="true" ID="ID_114089321" MODIFIED="1497061944575">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <font color="#ff0000"><b>&#20381;&#36182;&#27880;&#20837;</b></font>
    </p>
    <p>
      ____________
    </p>
    <p>
      &#29992;setter&#12289;constructor&#26041;&#27861;&#21019;&#24314;&#23545;&#35937;
    </p>
  </body>
</html>
</richcontent>
<arrowlink DESTINATION="ID_114089321" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_117284530" STARTARROW="None" STARTINCLINATION="0;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_114089321" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_117284530" SOURCE="ID_114089321" STARTARROW="None" STARTINCLINATION="0;0;"/>
<node CREATED="1497060760773" ID="ID_1403167205" MODIFIED="1497060826399">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20381;&#36182;&#27880;&#20837;&#65306;
    </p>
    <p>
      <font color="#ff3333"><b>&#32972;&#26223;&#65306;</b></font>
    </p>
    <p>
      public class A{
    </p>
    <p>
      public void aMethod(){
    </p>
    <p>
      B b = //get an instance of B
    </p>
    <p>
      B.bMethod();
    </p>
    <p>
      ...
    </p>
    <p>
      }
    </p>
    <p>
      }
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      <font color="#ff3333"><b>setter&#27880;&#20837;&#26041;&#24335;&#65306;</b></font>
    </p>
    <p>
      public class A{
    </p>
    <p>
      private B b;
    </p>
    <p>
      public void aMethod(){
    </p>
    <p>
      //B b =&#160;&#160;&#19981;&#20877;&#38656;&#35201;&#21019;&#24314;&#26032;&#23545;&#35937;
    </p>
    <p>
      B.bMethod();
    </p>
    <p>
      ...
    </p>
    <p>
      }
    </p>
    <p>
      
    </p>
    <p>
      public void setB(B b){ this.b = b;}
    </p>
    <p>
      }
    </p>
    <p>
      
    </p>
    <p>
      <font color="#ff0000"><b>&#26500;&#36896;&#20989;&#25968;&#27880;&#20837;:</b></font>
    </p>
    <p>
      public class A{
    </p>
    <p>
      private B b;
    </p>
    <p>
      
    </p>
    <p>
      public A(B b){this.b = b ;}
    </p>
    <p>
      public void aMethod(){
    </p>
    <p>
      //B b =&#160;&#160;&#19981;&#20877;&#38656;&#35201;&#21019;&#24314;&#26032;&#23545;&#35937;
    </p>
    <p>
      B.bMethod();
    </p>
    <p>
      ...
    </p>
    <p>
      }
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      }
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1491302205012" FOLDED="true" ID="ID_867519474" MODIFIED="1491302296914" POSITION="right" TEXT="&#x60b2;&#x89c2;&#x9501;&#x548c;&#x4e50;&#x89c2;&#x9501;">
<node CREATED="1491302220163" ID="ID_731100703" MODIFIED="1491302239114" TEXT="&#x60b2;&#x89c2;&#x9501;">
<node CREATED="1491302269851" ID="ID_1242668311" MODIFIED="1491302275830" TEXT="&#x60b2;&#x89c2;&#x9501;(Pessimistic Lock), &#x987e;&#x540d;&#x601d;&#x4e49;&#xff0c;&#x5c31;&#x662f;&#x5f88;&#x60b2;&#x89c2;&#xff0c;&#x6bcf;&#x6b21;&#x53bb;&#x62ff;&#x6570;&#x636e;&#x7684;&#x65f6;&#x5019;&#x90fd;&#x8ba4;&#x4e3a;&#x522b;&#x4eba;&#x4f1a;&#x4fee;&#x6539;&#xff0c;&#x6240;&#x4ee5;&#x6bcf;&#x6b21;&#x5728;&#x62ff;&#x6570;&#x636e;&#x7684;&#x65f6;&#x5019;&#x90fd;&#x4f1a;&#x4e0a;&#x9501;&#xff0c;&#x8fd9;&#x6837;&#x522b;&#x4eba;&#x60f3;&#x62ff;&#x8fd9;&#x4e2a;&#x6570;&#x636e;&#x5c31;&#x4f1a;block&#x76f4;&#x5230;&#x5b83;&#x62ff;&#x5230;&#x9501;&#x3002;&#x4f20;&#x7edf;&#x7684;&#x5173;&#x7cfb;&#x578b;&#x6570;&#x636e;&#x5e93;&#x91cc;&#x8fb9;&#x5c31;&#x7528;&#x5230;&#x4e86;&#x5f88;&#x591a;&#x8fd9;&#x79cd;&#x9501;&#x673a;&#x5236;&#xff0c;&#x6bd4;&#x5982;&#x884c;&#x9501;&#xff0c;&#x8868;&#x9501;&#x7b49;&#xff0c;&#x8bfb;&#x9501;&#xff0c;&#x5199;&#x9501;&#x7b49;&#xff0c;&#x90fd;&#x662f;&#x5728;&#x505a;&#x64cd;&#x4f5c;&#x4e4b;&#x524d;&#x5148;&#x4e0a;&#x9501;&#x3002;"/>
</node>
<node CREATED="1491302222939" ID="ID_724940680" MODIFIED="1491302245585" TEXT="&#x4e50;&#x89c2;&#x9501;">
<node CREATED="1491302285067" ID="ID_1800132388" MODIFIED="1491302286623" TEXT="&#x4e50;&#x89c2;&#x9501;(Optimistic Lock), &#x987e;&#x540d;&#x601d;&#x4e49;&#xff0c;&#x5c31;&#x662f;&#x5f88;&#x4e50;&#x89c2;&#xff0c;&#x6bcf;&#x6b21;&#x53bb;&#x62ff;&#x6570;&#x636e;&#x7684;&#x65f6;&#x5019;&#x90fd;&#x8ba4;&#x4e3a;&#x522b;&#x4eba;&#x4e0d;&#x4f1a;&#x4fee;&#x6539;&#xff0c;&#x6240;&#x4ee5;&#x4e0d;&#x4f1a;&#x4e0a;&#x9501;&#xff0c;&#x4f46;&#x662f;&#x5728;&#x66f4;&#x65b0;&#x7684;&#x65f6;&#x5019;&#x4f1a;&#x5224;&#x65ad;&#x4e00;&#x4e0b;&#x5728;&#x6b64;&#x671f;&#x95f4;&#x522b;&#x4eba;&#x6709;&#x6ca1;&#x6709;&#x53bb;&#x66f4;&#x65b0;&#x8fd9;&#x4e2a;&#x6570;&#x636e;&#xff0c;&#x53ef;&#x4ee5;&#x4f7f;&#x7528;&#x7248;&#x672c;&#x53f7;&#x7b49;&#x673a;&#x5236;&#x3002;&#x4e50;&#x89c2;&#x9501;&#x9002;&#x7528;&#x4e8e;&#x591a;&#x8bfb;&#x7684;&#x5e94;&#x7528;&#x7c7b;&#x578b;&#xff0c;&#x8fd9;&#x6837;&#x53ef;&#x4ee5;&#x63d0;&#x9ad8;&#x541e;&#x5410;&#x91cf;&#xff0c;&#x50cf;&#x6570;&#x636e;&#x5e93;&#x5982;&#x679c;&#x63d0;&#x4f9b;&#x7c7b;&#x4f3c;&#x4e8e;write_condition&#x673a;&#x5236;&#x7684;&#x5176;&#x5b9e;&#x90fd;&#x662f;&#x63d0;&#x4f9b;&#x7684;&#x4e50;&#x89c2;&#x9501;&#x3002;  "/>
</node>
<node CREATED="1491302225355" ID="ID_645483643" MODIFIED="1491302265399" TEXT="&#x60b2;&#x89c2;&#x9501;&#x548c;&#x4e50;&#x89c2;&#x9501;&#x4f18;&#x7f3a;&#x70b9;">
<node CREATED="1491302292811" ID="ID_1639607994" MODIFIED="1491302293509" TEXT="&#x4e24;&#x79cd;&#x9501;&#x5404;&#x6709;&#x4f18;&#x7f3a;&#x70b9;&#xff0c;&#x4e0d;&#x53ef;&#x8ba4;&#x4e3a;&#x4e00;&#x79cd;&#x597d;&#x4e8e;&#x53e6;&#x4e00;&#x79cd;&#xff0c;&#x50cf;&#x4e50;&#x89c2;&#x9501;&#x9002;&#x7528;&#x4e8e;&#x5199;&#x6bd4;&#x8f83;&#x5c11;&#x7684;&#x60c5;&#x51b5;&#x4e0b;&#xff0c;&#x5373;&#x51b2;&#x7a81;&#x771f;&#x7684;&#x5f88;&#x5c11;&#x53d1;&#x751f;&#x7684;&#x65f6;&#x5019;&#xff0c;&#x8fd9;&#x6837;&#x53ef;&#x4ee5;&#x7701;&#x53bb;&#x4e86;&#x9501;&#x7684;&#x5f00;&#x9500;&#xff0c;&#x52a0;&#x5927;&#x4e86;&#x7cfb;&#x7edf;&#x7684;&#x6574;&#x4e2a;&#x541e;&#x5410;&#x91cf;&#x3002;&#x4f46;&#x5982;&#x679c;&#x7ecf;&#x5e38;&#x4ea7;&#x751f;&#x51b2;&#x7a81;&#xff0c;&#x4e0a;&#x5c42;&#x5e94;&#x7528;&#x4f1a;&#x4e0d;&#x65ad;&#x7684;&#x8fdb;&#x884c;retry&#xff0c;&#x8fd9;&#x6837;&#x53cd;&#x5012;&#x662f;&#x964d;&#x4f4e;&#x4e86;&#x6027;&#x80fd;&#xff0c;&#x6240;&#x4ee5;&#x8fd9;&#x79cd;&#x60c5;&#x51b5;&#x4e0b;&#x7528;&#x60b2;&#x89c2;&#x9501;&#x5c31;&#x6bd4;&#x8f83;&#x5408;&#x9002;&#x3002;"/>
</node>
</node>
<node CREATED="1491318029131" ID="ID_251604101" MODIFIED="1491318034520" POSITION="right" TEXT="JAVA&#x57fa;&#x7840;">
<node CREATED="1491318036988" ID="ID_1163412632" MODIFIED="1491318056831" TEXT="&#x6838;&#x5fc3;&#x6982;&#x5ff5;">
<node CREATED="1491318060075" ID="ID_1562477476" MODIFIED="1491318069775" TEXT="&#x5bf9;&#x8c61;&#x6a21;&#x578b;"/>
<node CREATED="1491318070908" ID="ID_423793047" MODIFIED="1491318080327" TEXT="&#x63a5;&#x53e3;&#x8bbe;&#x8ba1;"/>
</node>
<node CREATED="1491318047563" ID="ID_274522296" MODIFIED="1491318088120" TEXT="&#x7c7b;&#x5e93;">
<arrowlink DESTINATION="ID_274522296" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_431462690" STARTARROW="None" STARTINCLINATION="0;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_274522296" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_431462690" SOURCE="ID_274522296" STARTARROW="None" STARTINCLINATION="0;0;"/>
<node CREATED="1491318090163" ID="ID_354020708" MODIFIED="1491318096127" TEXT="lang">
<node CREATED="1491318134714" ID="ID_1512495165" MODIFIED="1491318136558" TEXT="String"/>
</node>
<node CREATED="1491318100003" ID="ID_223785342" MODIFIED="1491318111505" TEXT="collections"/>
<node CREATED="1491318117163" ID="ID_525596258" MODIFIED="1491318127210" TEXT="concurrent"/>
<node CREATED="1491318130747" ID="ID_1675109463" MODIFIED="1491318132014" TEXT="io"/>
</node>
</node>
<node CREATED="1491320445754" FOLDED="true" ID="ID_1284773987" MODIFIED="1497020880886" POSITION="left" TEXT="&#x6742;&#x8c08;">
<node CREATED="1491266120826" ID="ID_183392075" MODIFIED="1491320818474">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      http://www.toutiao.com/a6404656958058397954/?tt_from=mobile_qq&amp;utm_campaign=client_share&amp;app=news_article&amp;utm_source=mobile_qq&amp;iid=6192326572&amp;utm_medium=toutiao_android
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1491320453180" ID="ID_1454094881" MODIFIED="1491320455973" TEXT="JAVA&#x6280;&#x672f;&#x53d1;&#x5c55;&#x4ece;J2EE&#x5bb9;&#x5668;&#x5316;&#x7684;&#x5355;&#x4e00;&#x5e94;&#x7528;&#x5411;SOA&#x548c;&#x5fae;&#x670d;&#x52a1;&#x53d1;&#x5c55;&#x53d8;&#x8fc1;&#x3002;&#x89c4;&#x6a21;&#x5316;&#x7684;&#x5206;&#x5e03;&#x5f0f;&#x7cfb;&#x7edf;&#x6210;&#x4e3a;&#x5e38;&#x6001;"/>
</node>
<node CREATED="1491537440160" HGAP="-24" ID="ID_132291485" MODIFIED="1491537458263" POSITION="left" TEXT="" VSHIFT="-57"/>
</node>
</map>
